"""Recuperação opcional da Camada A, sem inferência nem alteração de fontes.

Uma fonte permanece um leitor validado e seu mmap original. A composição
reúne apenas metadados: não concatena, filtra ou regrava a matriz NPY. A obra
antiga do volume 19 é excluída antes do top 50, da RRF e das âncoras, mesmo
que um registro tenha perdido seu marcador de bloqueio.

Os textos elegíveis compartilham um índice FTS5 temporário em memória. Isso
mantém os scores BM25 comparáveis entre fontes. O FTS5 ordena scores menores
primeiro (inclusive negativos ou zero), diferentemente do BM25 legado.
"""

from copy import deepcopy
import re
import sqlite3
import threading

import numpy as np

from .busca import Buscador, ErroBusca
from .camada_a import CorpusCamadaA, MODELO_E5, REVISAO_E5, OBRA_19_ANTIGA
from .importacao import conferir_compatibilidade


OBRA_19_NOVA = "obra-1b4ea213276f48f7"
SHA256_PDF_19_NOVO = "1b4ea213276f48f77b53349109c9d9a352ade2225de43aa50765225db5c0a3ba"


def _bloqueado(fragmento):
    return (fragmento.get("obra_id") == OBRA_19_ANTIGA
            or fragmento.get("obra") == OBRA_19_ANTIGA
            or fragmento.get("bloqueada_para_busca") is True)


def _contrato_manifesto(manifesto):
    """Identifique o espaço vetorial; contagens/arquivos não o definem."""
    tokenizador = manifesto.get("tokenizador", {
        "identificacao": manifesto.get("modelo"), "revisao": manifesto.get("revisao")})
    if isinstance(tokenizador, str):
        tokenizador = {"identificacao": tokenizador,
                       "revisao": manifesto.get("tokenizador_revisao", manifesto.get("revisao"))}
    return {"modelo": manifesto.get("modelo"), "revisao": manifesto.get("revisao"),
            "tokenizador": tokenizador, "dimensao": manifesto.get("dimensao"),
            "pooling": manifesto.get("pooling", "mean"), "normalizacao": "l2",
            "formato_vetor": manifesto.get("tipo_vetor"),
            "prefixo": manifesto.get("prefixo_consultas")}


class CorpusCompostoCamadaA:
    """Facade de leitura com índices globais estáveis e mmaps separados.

    O construtor recebe fontes já validadas. Por padrão os leitores pertencem
    ao chamador, que deve mantê-los abertos até terminar todas as buscas.
    ``fechar_fontes=True`` transfere seu fechamento à facade; a factory usa
    essa opção. Arrays/views não podem ser usados depois do fechamento.
    """

    def __init__(self, corpus_base, *fontes_adicionais, fechar_fontes=False):
        self._lock = threading.RLock()
        self._fechado = False
        self._fechar_fontes = fechar_fontes
        self.fontes = (corpus_base,) + tuple(fontes_adicionais)
        self.fragmentos = []
        self.por_id = {}
        self.indice_por_id = {}
        self.blocos = {}
        self._faixas = []
        self._elegiveis_por_fonte = []
        self._fontes_info = []
        self.obras_bloqueadas = (OBRA_19_ANTIGA,)
        try:
            manifesto_base = deepcopy(corpus_base.manifesto)
            for numero, fonte in enumerate(self.fontes):
                manifesto = fonte.manifesto
                esperado = {"modelo": MODELO_E5, "revisao": REVISAO_E5,
                            "dimensao": 1024, "tokens_maximo": 512,
                            "normalizacao": "L2", "tipo_vetor": "float32",
                            "prefixo_passagens": "passage: ", "prefixo_consultas": "query: "}
                if not isinstance(manifesto, dict) or any(
                        manifesto.get(chave) != valor or type(manifesto.get(chave)) is not type(valor)
                        for chave, valor in esperado.items()):
                    raise ErroBusca("A fonte da Camada A não declara o espaço E5 large fixado, float32 e L2.")
                conferir_compatibilidade({"fonte": _contrato_manifesto(manifesto)}, manifesto_base)
                vetores = fonte.vetores
                if (not isinstance(vetores, np.memmap) or vetores.mode != "r" or vetores.flags.writeable
                        or vetores.dtype != np.dtype("float32")
                        or vetores.shape != (len(fonte.fragmentos), 1024)):
                    raise ErroBusca("Cada fonte deve manter seu NPY original em mmap somente leitura.")
                if (len(fonte.fragmentos) != manifesto.get("fragmentos")
                        or len(fonte.blocos) != manifesto.get("blocos")):
                    raise ErroBusca("As contagens de uma fonte divergem do seu manifesto.")
                inicio = len(self.fragmentos)
                if set(self.blocos).intersection(fonte.blocos):
                    raise ErroBusca("As fontes possuem identificadores de blocos duplicados; não é seguro mesclá-las.")
                self.blocos.update(fonte.blocos)
                elegiveis = np.zeros(len(fonte.fragmentos), dtype=np.bool_)
                for local, fragmento in enumerate(fonte.fragmentos):
                    fid = fragmento["id"]
                    if fid in self.por_id:
                        raise ErroBusca("As fontes possuem identificadores de fragmentos duplicados.")
                    if fragmento["bloco_id"] not in fonte.blocos:
                        raise ErroBusca("Um fragmento aponta para bloco fora de sua própria fonte.")
                    self.indice_por_id[fid] = len(self.fragmentos)
                    self.por_id[fid] = fragmento
                    self.fragmentos.append(fragmento)
                    elegiveis[local] = not _bloqueado(fragmento)
                elegiveis.flags.writeable = False
                self._elegiveis_por_fonte.append(elegiveis)
                self._faixas.append((inicio, len(self.fragmentos)))
                obras = sorted({f.get("obra_id", f.get("obra")) for f in fonte.fragmentos})
                pdfs = sorted({b["referencia"]["sha256_pdf"] for b in fonte.blocos.values()
                               if isinstance(b.get("referencia", {}).get("sha256_pdf"), str)})
                self._fontes_info.append({"indice_fonte": numero, "obras_ids": obras,
                    "sha256_pdfs": pdfs, "fragmentos": len(fonte.fragmentos),
                    "fragmentos_elegiveis": int(elegiveis.sum()), "blocos": len(fonte.blocos),
                    "blocos_elegiveis": len({f["bloco_id"] for i, f in enumerate(fonte.fragmentos)
                                              if elegiveis[i]})})
            self.manifesto = manifesto_base
            self.manifesto.update(fragmentos=len(self.fragmentos), blocos=len(self.blocos))
            self.indices_elegiveis = np.asarray([i for i, f in enumerate(self.fragmentos)
                                                if not _bloqueado(f)], dtype=np.int64)
            self.indices_elegiveis.flags.writeable = False
            self.fragmentos_elegiveis = len(self.indices_elegiveis)
            self.blocos_elegiveis = len({self.fragmentos[int(i)]["bloco_id"]
                                        for i in self.indices_elegiveis})
            self.volume19_corrigido_presente = any(
                f.get("obra_id", f.get("obra")) == OBRA_19_NOVA and f.get("volume") == 19
                and fonte.blocos[f["bloco_id"]]["referencia"].get("sha256_pdf") == SHA256_PDF_19_NOVO
                for fonte in self.fontes[1:] for f in fonte.fragmentos)
            if not self.fragmentos_elegiveis:
                raise ErroBusca("A Camada A não possui fragmentos elegíveis para busca.")
        except ErroBusca:
            raise
        except (KeyError, TypeError, ValueError, AttributeError) as exc:
            raise ErroBusca("As fontes da Camada A são incompatíveis ou não foram validadas.") from exc

    @property
    def fechado(self):
        return self._fechado

    @property
    def vetores_por_fonte(self):
        self._aberto()
        return tuple(fonte.vetores for fonte in self.fontes)

    @property
    def fontes_info(self):
        return tuple(deepcopy(self._fontes_info))

    def _aberto(self):
        if self._fechado:
            raise ErroBusca("A Camada A composta já foi fechada.")

    def diagnostico(self):
        self._aberto()
        return {"fontes": list(self.fontes_info), "exclusao_fixa": list(self.obras_bloqueadas),
                "fragmentos_totais": len(self.fragmentos), "fragmentos_elegiveis": self.fragmentos_elegiveis,
                "blocos_totais": len(self.blocos), "blocos_elegiveis": self.blocos_elegiveis,
                "volume19_corrigido_presente": self.volume19_corrigido_presente,
                "matrizes_separadas": True, "inferencia_local": False}

    def close(self):
        with self._lock:
            if self._fechado:
                return
            self._fechado = True
            if self._fechar_fontes:
                for fonte in reversed(self.fontes):
                    fonte.close()

    def __enter__(self):
        self._aberto()
        return self

    def __exit__(self, *_):
        self.close()


def abrir_camada_a_composta(pasta, volume19=None):
    """Abra explicitamente a base e, quando indicado, uma segunda fonte."""
    fontes = []
    try:
        if volume19 is not None:
            from .preparar_volume19 import validar_corpus_volume19
            try:
                validacao = validar_corpus_volume19(volume19)
            except (OSError, ValueError, TypeError, KeyError, sqlite3.Error) as exc:
                raise ErroBusca("O corpus corrigido do volume 19 falhou na conferência da geração e dos hashes por linha.") from exc
            if validacao.get("embedding_real") is not True:
                raise ErroBusca("O corpus do volume 19 contém vetores sintéticos de teste. Gere os vetores E5 reais no Colab ou no ambiente E5 local.")
        fontes.append(CorpusCamadaA(pasta))
        if volume19 is not None:
            fontes.append(CorpusCamadaA(volume19))
            if any(f.get("obra_id") != OBRA_19_NOVA or f.get("volume") != 19
                   for f in fontes[-1].fragmentos) or any(
                    b["referencia"].get("sha256_pdf") != SHA256_PDF_19_NOVO
                    for b in fontes[-1].blocos.values()):
                raise ErroBusca("A segunda fonte deve ser o PDF corrigido e conferido do volume 19, com identidade própria.")
        return CorpusCompostoCamadaA(*fontes, fechar_fontes=True)
    except BaseException:
        for fonte in reversed(fontes):
            fonte.close()
        raise


class _FTS5Elegivel:
    K1, B = 1.2, 0.75

    def __init__(self, corpus):
        self._conexao = sqlite3.connect(":memory:", check_same_thread=False)
        try:
            self._conexao.execute("CREATE VIRTUAL TABLE documentos USING fts5(cabecalho, texto, tokenize='unicode61')")
            self._conexao.executemany("INSERT INTO documentos(rowid,cabecalho,texto) VALUES(?,?,?)",
                ((int(i) + 1, corpus.fragmentos[int(i)]["cabecalho"], corpus.fragmentos[int(i)]["texto"])
                 for i in corpus.indices_elegiveis))
            self._conexao.commit()
        except (sqlite3.Error, KeyError, TypeError) as exc:
            self.close()
            raise ErroBusca("Não foi possível criar o índice lexical temporário FTS5 da Camada A.") from exc

    @staticmethod
    def _ordenar(linhas, limite):
        # FTS5 pode fornecer scores negativos ou zero: nenhum deles é
        # descartado pelo filtro positivo utilizado no backend legado.
        return sorted(((int(indice), float(score)) for indice, score in linhas),
                      key=lambda item: (item[1], item[0]))[:limite]

    def ranking(self, texto, limite):
        if self._conexao is None:
            raise ErroBusca("O índice FTS5 temporário já foi fechado.")
        termos = list(dict.fromkeys(t.casefold() for t in re.findall(r"[^\W_]+", texto, re.UNICODE)))
        if not termos:
            return []
        expressao = " OR ".join('"' + termo + '"' for termo in termos)
        linhas = self._conexao.execute(
            "SELECT rowid-1, bm25(documentos) AS score FROM documentos "
            "WHERE documentos MATCH ? ORDER BY score ASC,rowid ASC LIMIT ?", (expressao, limite)).fetchall()
        return self._ordenar(linhas, limite)

    def close(self):
        if self._conexao is not None:
            self._conexao.close()
            self._conexao = None


class BuscadorCamadaA(Buscador):
    """Mesmo agrupamento/RRF/âncoras do agente, com rankings elegíveis."""

    LOTE_SEMANTICO = 512

    def __init__(self, corpus, *fontes_adicionais):
        if isinstance(corpus, CorpusCompostoCamadaA):
            if fontes_adicionais:
                raise ErroBusca("Acrescente fontes ao compor o corpus, antes de construir o buscador.")
            self.corpus = corpus
        else:
            self.corpus = CorpusCompostoCamadaA(corpus, *fontes_adicionais)
        self._lock = threading.RLock()
        self._fechado = False
        self.corpus._aberto()
        self.lexical = _FTS5Elegivel(self.corpus)

    def _rankings(self, consulta, vetor):
        with self._lock, self.corpus._lock:
            if self._fechado:
                raise ErroBusca("O buscador da Camada A já foi fechado.")
            return self._rankings_abertos(consulta, vetor)

    def _rankings_abertos(self, consulta, vetor):
        self.corpus._aberto()
        lexical = self.lexical.ranking(consulta.get("texto_vetorizado", consulta["texto"]), self.TOP_METODO)
        semanticos = []
        # Apenas scores escalares e no máximo top 50 de cada lote permanecem
        # em RAM. O mmap e sua ordem original não sofrem seleção ou cópia.
        for numero, fonte in enumerate(self.corpus.fontes):
            deslocamento = self.corpus._faixas[numero][0]
            elegiveis = self.corpus._elegiveis_por_fonte[numero]
            for inicio in range(0, len(fonte.fragmentos), self.LOTE_SEMANTICO):
                fim = min(inicio + self.LOTE_SEMANTICO, len(fonte.fragmentos))
                locais = np.flatnonzero(elegiveis[inicio:fim])
                if not len(locais):
                    continue
                scores = fonte.vetores[inicio:fim] @ vetor
                classificados = sorted(((deslocamento + inicio + int(i), float(scores[i])) for i in locais),
                                       key=lambda item: (-item[1], item[0]))[:self.TOP_METODO]
                semanticos.extend(classificados)
                semanticos.sort(key=lambda item: (-item[1], item[0]))
                del semanticos[self.TOP_METODO:]
        return [("BM25", lexical), ("E5", semanticos)]

    def _descricao_bm25(self):
        return {"backend": "sqlite_fts5", "k1": self.lexical.K1, "b": self.lexical.B,
                "tokenizacao": "unicode61; termos literais unidos por OR, sem operadores do usuário",
                "ordenacao": "score ASC; scores negativos e zero preservados; desempate pela ordem da fonte/linha",
                "indice": "temporário em memória; somente fragmentos elegíveis de todas as fontes"}

    def buscar(self, importado, progresso=lambda etapa: None):
        with self._lock, self.corpus._lock:
            if self._fechado:
                raise ErroBusca("O buscador da Camada A já foi fechado.")
            self.corpus._aberto()
            resultado = super().buscar(importado, progresso)
            resultado["metodo_fusao"]["semantica"] = (
                "produto escalar dos vetores de consulta normalizados L2 com linhas elegíveis, "
                "em lotes separados por fonte; sem concatenar ou combinar vetores")
            resultado["camada_a"] = self.corpus.diagnostico()
            return resultado

    def close(self):
        with self._lock:
            if not self._fechado:
                self._fechado = True
                self.lexical.close()

    def __enter__(self):
        if self._fechado:
            raise ErroBusca("O buscador da Camada A já foi fechado.")
        return self

    def __exit__(self, *_):
        self.close()
