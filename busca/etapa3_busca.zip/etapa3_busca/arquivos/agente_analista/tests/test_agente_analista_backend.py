"""Seleção explícita do índice e contrato HTTP, sem modelos ou provedores."""

import json
import os
from pathlib import Path
import sqlite3
from tempfile import TemporaryDirectory
from threading import Event
import time
import unittest
from unittest.mock import patch

import numpy as np

from agente_analista.app import RAIZ, ServicoAnalista, criar_app
from agente_analista.camada_a import OBRA_19_ANTIGA
from agente_analista.corpus import ErroCorpus
from agente_analista.entrada import validar_relato
from agente_analista.tests.test_agente_analista_camada_a_core import criar_fixture


TEXTO = "Uma memória de defesa e sonho.\n\nOutro parágrafo com lembranças."
OBRA_CORRIGIDA = "obra-1b4ea213276f48f7"
SHA_PDF_CORRIGIDO = "1b4ea213276f48f77b53349109c9d9a352ade2225de43aa50765225db5c0a3ba"


def fonte(manifesto):
    return {"modelo": manifesto["modelo"], "revisao": manifesto["revisao"],
            "tokenizador": {"identificacao": manifesto["modelo"], "revisao": manifesto["revisao"]},
            "dimensao": manifesto["dimensao"], "pooling": "mean", "normalizacao": "l2",
            "formato_vetor": "float32", "prefixo": "query: "}


def importada(manifesto):
    relato = validar_relato(TEXTO)
    vetor = [1.0] + [0.0] * (manifesto["dimensao"] - 1)
    return {"relato": relato, "fonte": fonte(manifesto), "consultas": [
        {"id": "consulta-fixture", "tipo": "paragrafo", "texto": relato["paragrafos"][0]["texto"],
         "inicio": relato["paragrafos"][0]["inicio"], "fim": relato["paragrafos"][0]["fim"],
         "vetor": vetor, "paragrafo_id": "P1"}]}


def envelope():
    # O parser de vetorização é isolado nestes testes do backend. Esse envelope
    # conserva o requisito real do banco: o texto original não muda na busca.
    return {"contexto": {"regras": {"analise": {"anotacao": {"segmentacao": {
        "preparacao": {"original": {"texto": TEXTO}}}}}}}}


def criar_corrigido(pasta):
    """Uma única fonte separada com a identidade do PDF corrigido."""
    refs = criar_fixture(pasta)
    velho = "obra-v19-corrigida"
    original = next(f for f in refs if f["obra_id"] == velho)
    f = {k: v.replace(velho, OBRA_CORRIGIDA) if isinstance(v, str) else v
         for k, v in original.items()}
    con = sqlite3.connect(pasta / "corpus.sqlite")
    try:
        con.execute("UPDATE obras SET id=?, sha256_pdf=? WHERE id=?", (OBRA_CORRIGIDA, SHA_PDF_CORRIGIDO, velho))
        con.execute("UPDATE secoes SET id=?, obra_id=? WHERE obra_id=?", (f["secao_id"], OBRA_CORRIGIDA, velho))
        con.execute("UPDATE paginas SET obra_id=? WHERE obra_id=?", (OBRA_CORRIGIDA, velho))
        con.execute("UPDATE blocos SET id=?, obra_id=?, secao_id=? WHERE obra_id=?",
                    (f["bloco_id"], OBRA_CORRIGIDA, f["secao_id"], velho))
        con.execute("UPDATE fragmentos SET id=?, bloco_id=?, obra_id=?, secao_id=? WHERE obra_id=?",
                    (f["id"], f["bloco_id"], OBRA_CORRIGIDA, f["secao_id"], velho))
        for tabela in ("fragmentos", "blocos", "paginas", "secoes"):
            con.execute(f"DELETE FROM {tabela} WHERE obra_id != ?", (OBRA_CORRIGIDA,))
        con.execute("DELETE FROM obras WHERE id != ?", (OBRA_CORRIGIDA,))
        con.execute("DELETE FROM fragmentos_fts")
        con.execute("INSERT INTO fragmentos_fts(fragmento_id,cabecalho,texto) VALUES (?,?,?)",
                    (f["id"], f["cabecalho"], f["texto"]))
        con.commit()
    finally:
        con.close()
    (pasta / "fragmentos.jsonl").write_text(json.dumps(f, ensure_ascii=False) + "\n", encoding="utf-8")
    vetores = np.load(pasta / "vetores_e5.npy")
    np.save(pasta / "vetores_e5.npy", vetores[[refs.index(original)]])
    m = json.loads((pasta / "manifesto.json").read_text())
    (pasta / "manifesto.json").write_text(json.dumps({**m, "fragmentos": 1, "blocos": 1}), encoding="utf-8")
    return f


class BackendTests(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.pasta = Path(self.tmp.name) / "base"
        self.pasta.mkdir()
        self.refs = criar_fixture(self.pasta)
        self.ambiente = patch.dict(os.environ, {}, clear=True)
        self.ambiente.start()
        self.addCleanup(self.ambiente.stop)

    def servico(self, **opcoes):
        s = ServicoAnalista(self.pasta, backend="camada_a", **opcoes)
        self.addCleanup(s.close)
        return s

    def app(self, servico):
        app = criar_app({"TESTING": True, "DATABASE": str(Path(self.tmp.name) / "historico.sqlite3")}, servico=servico)
        self.addCleanup(app.extensions["agente_analista"]["fechar"])
        return app

    def test_padrao_legado_mesmo_com_pastas_da_camada_definidas(self):
        with patch.dict(os.environ, {"AGENTE_ANALISTA_CAMADA_A": str(self.pasta),
                                     "AGENTE_ANALISTA_VOLUME19_CORRIGIDO": str(self.pasta)}):
            s = ServicoAnalista()
        self.addCleanup(s.close)
        self.assertEqual(s.backend, "legado")
        self.assertEqual(s.pasta, RAIZ / "agente_analista/data/Vetor")
        self.assertIsNone(s.volume19)
        self.assertIsNone(s.corpus)
        self.assertIsNone(s.buscador)

    def test_env_invalido_e_camada_sem_pasta_explicam_configuracao(self):
        for valor in ("", "CAMADA_A", "desconhecido"):
            with self.subTest(valor=valor), patch.dict(os.environ, {"AGENTE_ANALISTA_CORPUS_BACKEND": valor}):
                with self.assertRaisesRegex(ValueError, "CORPUS_BACKEND"):
                    ServicoAnalista()
        with patch.dict(os.environ, {"AGENTE_ANALISTA_CORPUS_BACKEND": "camada_a"}):
            with self.assertRaisesRegex(ValueError, "AGENTE_ANALISTA_CAMADA_A"):
                ServicoAnalista()

    def test_parametros_explicitos_prevalecem_e_env_e_capturado_ao_iniciar(self):
        with patch.dict(os.environ, {"AGENTE_ANALISTA_CORPUS_BACKEND": "camada_a", "AGENTE_ANALISTA_CAMADA_A": str(self.pasta)}):
            s = ServicoAnalista()
            legado = ServicoAnalista(self.pasta, backend="legado")
        self.addCleanup(s.close)
        self.addCleanup(legado.close)
        self.assertEqual(s.backend, "camada_a")
        self.assertEqual(s.pasta, self.pasta)
        self.assertEqual(legado.backend, "legado")
        self.assertEqual(s.status()["backend"], "camada_a")

    def test_status_sem_inferencia_declara_totais_exclusao_e_ausencia_corrigido(self):
        s = self.servico()
        with patch.dict("sys.modules", {"torch": None, "transformers": None, "sentence_transformers": None}), \
                patch("agente_analista.modelos.escolher_formato_resposta", side_effect=AssertionError("provedor não solicitado")):
            status = s.status()
        self.assertTrue(status["pronto"], status)
        self.assertFalse(status["inferencia_local"])
        self.assertEqual(status["backend"], "camada_a")
        self.assertEqual(status["corpus"]["fragmentos_totais"], 5)
        self.assertEqual(status["corpus"]["fragmentos_elegiveis"], 4)
        self.assertEqual(status["corpus"]["blocos_totais"], 4)
        self.assertEqual(status["corpus"]["blocos_elegiveis"], 3)
        self.assertFalse(status["corpus"]["volume19_corrigido_presente"])
        self.assertIsNone(s.buscador)

    def test_corrigido_opcional_permanece_em_matriz_separada(self):
        nova = Path(self.tmp.name) / "corrigido"
        nova.mkdir()
        novo = criar_corrigido(nova)
        s = self.servico(volume19=nova)
        # Este teste isola a seleção no app e a composição estrutural. A
        # validação de geração E5 real tem testes próprios no preparador.
        with patch("agente_analista.preparar_volume19.validar_corpus_volume19",
                   return_value={"corpus_validado": True, "embedding_real": True}) as validar:
            status = s.status()
        validar.assert_called_once_with(nova)
        self.assertTrue(status["pronto"], status)
        self.assertTrue(status["corpus"]["volume19_corrigido_presente"])
        self.assertEqual(status["corpus"]["fragmentos_totais"], 6)
        self.assertEqual(status["corpus"]["fragmentos_elegiveis"], 5)
        self.assertEqual(len(s.corpus.vetores_por_fonte), 2)
        self.assertIn(novo["id"], s.corpus.por_id)
        self.assertFalse(hasattr(s.corpus, "vetores"))

    def test_corrigido_sem_registro_de_geracao_valido_bloqueia_selecao(self):
        nova = Path(self.tmp.name) / "corrigido-sem-geracao"
        nova.mkdir()
        criar_corrigido(nova)
        s = self.servico(volume19=nova)
        status = s.status()
        self.assertFalse(status["pronto"])
        self.assertTrue(status["problemas"])
        self.assertIsNone(s.corpus)

    def test_manifesto_importacao_vem_da_mesma_fonte_ja_aberta(self):
        s = self.servico()
        m = s.manifesto_indice()
        app = self.app(s)
        # Alterar o manifesto bruto depois da abertura não pode selecionar
        # outro espaço para a importação enquanto a busca usa o corpus aberto.
        (self.pasta / "manifesto.json").write_text(json.dumps({**m, "dimensao": 7}), encoding="utf-8")
        esperado = importada(m)
        with patch("agente_analista.app.importar_vetorizacao", return_value=esperado):
            resposta = app.test_client().post("/api/vetorizacoes", json=envelope())
        self.assertEqual(resposta.status_code, 201, resposta.get_json())
        m["dimensao"] = 3
        self.assertEqual(s.manifesto_indice()["dimensao"], 1024)

    def test_importacao_de_espaco_incompativel_e_recusada(self):
        s = self.servico()
        app = self.app(s)
        errado = importada(s.manifesto_indice())
        errado["fonte"]["revisao"] = "b" * 40
        with patch("agente_analista.app.importar_vetorizacao", return_value=errado):
            resposta = app.test_client().post("/api/vetorizacoes", json=envelope())
        self.assertEqual(resposta.status_code, 400)
        self.assertIn("revisão", resposta.get_json()["erro"])

    def test_execucao_real_de_recuperacao_exclui_antigo19_sem_provedor(self):
        s = self.servico()
        vetorizacao = importada(s.manifesto_indice())
        etapas = []
        with patch("agente_analista.modelos.escolher_formato_resposta", return_value="json_schema"), \
                patch("agente_analista.ligacoes.avaliar_ligacoes", return_value={"ligacoes": []}):
            resultado = s.executar(vetorizacao["relato"], etapas.append, provedor="openai",
                                   modelo="modelo-teste", chave_api="chave-sintetica", vetorizacao=vetorizacao)
        self.assertIs(s.buscador.corpus, s.corpus)
        self.assertTrue(resultado["candidatos"])
        self.assertTrue(etapas)
        self.assertNotIn(OBRA_19_ANTIGA, {b["referencia"]["obra_id"] for b in resultado["candidatos"]})
        for campo in ("candidatos", "ranking_fundido", "ancoras"):
            self.assertNotIn(OBRA_19_ANTIGA, json.dumps(resultado[campo], ensure_ascii=False))
        self.assertIn(OBRA_19_ANTIGA, resultado["camada_a"]["exclusao_fixa"])

    def test_fechamento_aplicativo_libera_fontes_e_recusa_reabertura(self):
        s = self.servico()
        app = self.app(s)
        self.assertEqual(app.test_client().get("/api/status").status_code, 200)
        mapas = [v._mmap for v in s.corpus.vetores_por_fonte]
        app.extensions["agente_analista"]["fechar"]()
        self.assertTrue(all(mapa.closed for mapa in mapas))
        self.assertFalse(s.status()["pronto"])
        with self.assertRaises(ErroCorpus):
            s.manifesto_indice()
        s.close()

    def test_servico_fake_com_pasta_preserva_importacao_status_e_progresso(self):
        base = self.pasta
        esperado = importada(json.loads((base / "manifesto.json").read_text()))
        iniciou, liberar = Event(), Event()
        self.addCleanup(liberar.set)

        class Fake:
            pasta = base

            def status(self):
                return {"pronto": True, "problemas": [], "fake": True}

            def executar(self, relato, progresso, **opcoes):
                progresso("Etapa controlada")
                iniciou.set()
                if not liberar.wait(5):
                    raise AssertionError("Teste não liberou o fake")
                return {"relato": relato, "ligacoes": [], "mensagem": "Teste sem avaliação externa."}

        app = self.app(Fake())
        client = app.test_client()
        with patch("agente_analista.app.importar_vetorizacao", return_value=esperado):
            upload = client.post("/api/vetorizacoes", json=envelope())
            self.assertEqual(upload.status_code, 201, upload.get_json())
            self.assertTrue(client.get("/api/status").get_json()["fake"])
            pedido = {"texto": TEXTO, "vetorizacao_id": upload.get_json()["id"],
                      "provedor": "openai", "modelo": "modelo-teste", "chave_api": "chave-sintetica"}
            inicio = client.post("/api/buscas", json=pedido)
            self.assertEqual(inicio.status_code, 202, inicio.get_json())
            self.assertTrue(iniciou.wait(1))
            consulta = "/api/buscas/" + inicio.get_json()["id"]
            self.assertEqual(client.get(consulta).get_json()["etapa"], "Etapa controlada")
            liberar.set()
            for _ in range(100):
                final = client.get(consulta).get_json()
                if final["estado"] != "executando":
                    break
                time.sleep(.01)
            self.assertEqual(final["estado"], "concluido", final)
            self.assertEqual(final["resultado"]["relato"]["texto"], TEXTO)


if __name__ == "__main__":
    unittest.main()
