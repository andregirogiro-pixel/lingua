"""Busca opcional sobre mmaps e FTS5 reais; nenhuma inferência/modelo/API."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

from agente_analista.busca import Buscador, ErroBusca
from agente_analista.busca_camada_a import (
    BuscadorCamadaA, CorpusCompostoCamadaA, OBRA_19_NOVA, SHA256_PDF_19_NOVO,
    _FTS5Elegivel, abrir_camada_a_composta,
)
from agente_analista.camada_a import MODELO_E5, OBRA_19_ANTIGA, REVISAO_E5
from agente_analista.corpus import Corpus
from agente_analista.entrada import validar_relato
from agente_analista.ligacoes import _fontes, _validar_ligacao
from agente_analista.tests.test_agente_analista_camada_a_core import criar_fixture
from agente_analista.tests.test_agente_analista_busca import _importado, _fixture


def _sha(texto):
    return hashlib.sha256(texto.encode("utf-8")).hexdigest()


def _vetor(indice=0, primeiro=None):
    vetor = np.zeros(1024, dtype=np.float32)
    if primeiro is None:
        vetor[indice] = 1.0
    else:
        vetor[0] = primeiro
        vetor[1] = np.sqrt(1 - primeiro ** 2)
    return vetor


def _corpus(pasta, registros, prefixo="base", revisao=REVISAO_E5):
    pasta.mkdir()
    referencias = []
    vetores = []
    for numero, (obra, texto, vetor) in enumerate(registros):
        bid = f"{prefixo}-bloco-{numero}"
        cabecalho = "Freud"
        f = {"id": bid + "-fragmento", "bloco_id": bid, "obra": obra,
             "obra_id": obra, "volume": 19 if obra in (OBRA_19_ANTIGA, OBRA_19_NOVA) else 5,
             "secao": "Uma seção", "fragmento_no_bloco": 0, "inicio": 0, "fim": len(texto),
             "paginas": [10 + numero], "texto": texto, "cabecalho": cabecalho,
             "texto_origem_sha256": _sha(texto), "tokens_entrada": 30,
             "entrada_sha256": _sha("passage: " + cabecalho + "\n" + texto)}
        referencias.append(f)
        vetores.append(vetor)
    manifesto = {"modelo": MODELO_E5, "revisao": revisao, "dimensao": 1024,
        "tokens_maximo": 512, "margem_tokens": 8, "normalizacao": "L2", "tipo_vetor": "float32",
        "prefixo_passagens": "passage: ", "prefixo_consultas": "query: ",
        "referencias_arquivo": "fragmentos.jsonl", "vetores_arquivo": "vetores.npy",
        "fragmentos": len(referencias), "blocos": len(referencias)}
    (pasta / "manifesto.json").write_text(json.dumps(manifesto), encoding="utf-8")
    (pasta / "fragmentos.jsonl").write_text("".join(json.dumps(f) + "\n" for f in referencias), encoding="utf-8")
    np.save(pasta / "vetores.npy", np.asarray(vetores, dtype=np.float32))
    corpus = Corpus(pasta)
    for bloco in corpus.blocos.values():
        if bloco["referencia"]["obra_id"] == OBRA_19_NOVA:
            bloco["referencia"]["sha256_pdf"] = SHA256_PDF_19_NOVO
    return corpus


class BuscaCamadaATests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.pasta = Path(self.tmp.name)
        self.fontes = []
        self.buscadores = []
        self.addCleanup(self._fechar)

    def _fechar(self):
        for buscador in self.buscadores:
            buscador.close()
        for fonte in self.fontes:
            fonte.vetores._mmap.close()

    def fonte(self, registros, prefixo="base", revisao=REVISAO_E5):
        fonte = _corpus(self.pasta / prefixo, registros, prefixo, revisao)
        self.fontes.append(fonte)
        return fonte

    def buscador(self, *fontes):
        buscador = BuscadorCamadaA(*fontes)
        self.buscadores.append(buscador)
        return buscador

    @staticmethod
    def importado():
        importado = _importado(vetor=_vetor().tolist())
        importado["fonte"]["dimensao"] = 1024
        return importado

    def test_exclui_mais_de_top50_linhas_antigas_antes_do_ranking_e_fusao(self):
        registros = [(OBRA_19_ANTIGA, "defesa defesa defesa.", _vetor()) for _ in range(55)]
        registros.append(("obra-valida", "Uma defesa possível.", _vetor(primeiro=0.6)))
        fonte = self.fonte(registros)
        # Nem retirar manualmente o marcador contorna a exclusão fixa por ID.
        for f in fonte.fragmentos:
            f["bloqueada_para_busca"] = False
        buscador = self.buscador(fonte)
        consulta = {"texto": "defesa"}
        for metodo, linhas in buscador._rankings(consulta, _vetor()):
            self.assertEqual([i for i, _ in linhas], [55], metodo)
        importado = self.importado()
        for c in importado["consultas"]:
            c["texto_vetorizado"] = "defesa"
        resultado = buscador.buscar(importado)
        self.assertEqual([c["bloco_id"] for c in resultado["candidatos"]], ["base-bloco-55"])
        self.assertEqual([r["bloco_id"] for r in resultado["ranking_fundido"]], ["base-bloco-55"])
        self.assertTrue(all(b["bloco_id"] == "base-bloco-55"
                            for a in resultado["ancoras"] for b in a["blocos"]))
        self.assertTrue(all(p["rank"] == 1 and p["rank_bloco"] == 1
                            for c in resultado["candidatos"] for p in c["pontuacoes"]))
        self.assertEqual(len(fonte.fragmentos), 56)
        self.assertEqual(buscador.corpus.fragmentos_elegiveis, 1)

    def test_fts5_aceita_score_negativo_e_melhor_resultado_vem_primeiro(self):
        fonte = self.fonte([("obra-a", "defesa " * 15, _vetor()),
                            ("obra-a", "defesa com palavras adicionais variadas.", _vetor(1))])
        buscador = self.buscador(fonte)
        lexical = dict(buscador._rankings({"texto": "defesa"}, _vetor()))["BM25"]
        self.assertEqual([i for i, _ in lexical], [0, 1])
        self.assertLess(lexical[0][1], lexical[1][1])
        self.assertTrue(all(score < 0 for _, score in lexical))

    def test_zero_nao_e_filtrado_e_empates_preservam_ordem_da_linha(self):
        linhas = [(5, 0.0), (2, -1.0), (3, -1.0), (1, 0.0)]
        self.assertEqual(_FTS5Elegivel._ordenar(linhas, 50),
                         [(2, -1.0), (3, -1.0), (1, 0.0), (5, 0.0)])
        fonte = self.fonte([("obra-a", "defesa", _vetor()), ("obra-a", "defesa", _vetor())])
        buscador = self.buscador(fonte)
        with patch.object(buscador.lexical, "ranking", return_value=[(0, 0.0), (1, 0.0)]):
            resultado = buscador.buscar(self.importado())
        bm25 = [p for c in resultado["candidatos"] for p in c["pontuacoes"] if p["metodo"] == "BM25"]
        self.assertTrue(bm25)
        self.assertTrue(all(p["score"] == 0 for p in bm25))

    def test_consulta_fts_literal_nao_interpreta_operadores_ou_injecao(self):
        fonte = self.fonte([("obra-a", "defesa OR memória", _vetor()),
                            ("obra-a", "sonho", _vetor(1))])
        buscador = self.buscador(fonte)
        self.assertEqual([i for i, _ in buscador.lexical.ranking('" OR defesa); DROP TABLE documentos; --', 50)], [0])
        self.assertEqual(len(buscador.lexical.ranking("defesa", 50)), 1)
        self.assertEqual(buscador.lexical.ranking("!!!", 50), [])

    def test_fontes_compartilham_fts_e_disputam_o_mesmo_top_sem_copiar_matrizes(self):
        base = self.fonte([(OBRA_19_ANTIGA, "defesa " * 25, _vetor()),
                           ("obra-a", "defesa comum", _vetor(primeiro=0.3))])
        nova = self.fonte([(OBRA_19_NOVA, "defesa " * 8, _vetor(primeiro=0.8))], "nova")
        buscador = self.buscador(base, nova)
        corpus = buscador.corpus
        self.assertIs(corpus.vetores_por_fonte[0], base.vetores)
        self.assertIs(corpus.vetores_por_fonte[1], nova.vetores)
        self.assertFalse(hasattr(corpus, "vetores"))
        self.assertEqual(corpus.indices_elegiveis.tolist(), [1, 2])
        self.assertFalse(corpus.indices_elegiveis.flags.writeable)
        self.assertEqual([f["id"] for f in corpus.fragmentos],
                         [f["id"] for f in base.fragmentos + nova.fragmentos])
        for f in base.fragmentos + nova.fragmentos:
            self.assertIs(corpus.por_id[f["id"]], f)
        self.assertTrue(corpus.volume19_corrigido_presente)
        rankings = dict(buscador._rankings({"texto": "defesa"}, _vetor()))
        self.assertEqual([i for i, _ in rankings["E5"]], [2, 1])
        self.assertEqual([i for i, _ in rankings["BM25"]], [2, 1])
        resultado = buscador.buscar(self.importado())
        self.assertEqual({c["referencia"]["obra_id"] for c in resultado["candidatos"]}, {"obra-a", OBRA_19_NOVA})
        json.dumps(resultado, allow_nan=False)

    def test_exclusao_nao_deforma_estatisticas_fts_do_universo_elegivel(self):
        limpa = self.fonte([("obra-a", "defesa", _vetor()),
                            ("obra-a", "defesa com mais palavras", _vetor(1))], "limpa")
        com_antiga = self.fonte([("obra-a", "defesa", _vetor()),
                                ("obra-a", "defesa com mais palavras", _vetor(1))]
                               + [(OBRA_19_ANTIGA, "defesa " * 100, _vetor()) for _ in range(20)], "antiga")
        a = self.buscador(limpa).lexical.ranking("defesa", 50)
        b = self.buscador(com_antiga).lexical.ranking("defesa", 50)
        self.assertEqual(a, b)

    def test_semantica_em_lotes_desempata_globalmente_antes_do_top50(self):
        base = self.fonte([("obra-a", "memória", _vetor()) for _ in range(62)])
        nova = self.fonte([("obra-nova", "memória", _vetor()) for _ in range(12)], "nova")
        buscador = self.buscador(base, nova)
        buscador.LOTE_SEMANTICO = 7
        linhas = dict(buscador._rankings({"texto": "memória"}, _vetor()))["E5"]
        self.assertEqual([i for i, _ in linhas], list(range(50)))
        self.assertTrue(all(score == 1 for _, score in linhas))

    def test_citacao_do_resultado_composto_passa_validador_literal_existente(self):
        base = self.fonte([("obra-a", "O sonho permanece literal.", _vetor())])
        nova = self.fonte([(OBRA_19_NOVA, "A memória conserva sua história.", _vetor())], "nova")
        resultado = self.buscador(base, nova).buscar(self.importado())
        relato = validar_relato("Tenho uma memória.\n\nVolto ao mesmo sonho.")
        paragrafos, blocos = _fontes(relato, resultado)
        bloco = next(c for c in resultado["candidatos"] if c["referencia"]["obra_id"] == OBRA_19_NOVA)
        proposta = {"paragrafo": "P1", "bloco_id": bloco["bloco_id"],
            "relato": {k: relato["paragrafos"][0][k] for k in ("inicio", "fim", "texto")},
            "freud": {"inicio": 0, "fim": len(bloco["texto"]), "texto": bloco["texto"]},
            "fragmentos_ids": bloco["fragmentos_ids"], "situacao": "parcial", "observacao": "Teste literal.",
            "conceito": "", "ligacao": "Teste.", "justificativa": "Teste de conservação.",
            "limites": "Sem avaliação interpretativa.", "alternativas": []}
        validada, motivo = _validar_ligacao(proposta, relato, paragrafos, blocos)
        self.assertIsNone(motivo)
        self.assertEqual(validada["freud"]["texto"], bloco["texto"])
        self.assertEqual(validada["referencia"]["obra_id"], OBRA_19_NOVA)

    def test_rejeita_modelo_revisao_tokenizador_pooling_ou_dimensao_incompativel(self):
        base = self.fonte([("obra-a", "memória", _vetor())])
        nova = self.fonte([("obra-nova", "memória", _vetor())], "nova")
        for chave, valor in [("modelo", "outro-modelo"), ("revisao", "b" * 40),
                             ("tokenizador", {"identificacao": MODELO_E5, "revisao": "b" * 40}),
                             ("pooling", "cls"), ("dimensao", 768), ("prefixo_passagens", "query: ")]:
            with self.subTest(chave=chave):
                original = deepcopy(nova.manifesto)
                nova.manifesto[chave] = valor
                try:
                    with self.assertRaises(ErroBusca):
                        BuscadorCamadaA(base, nova)
                finally:
                    nova.manifesto = original

    def test_rejeita_consulta_de_outro_espaco_sem_inferir(self):
        fonte = self.fonte([("obra-a", "memória", _vetor())])
        buscador = self.buscador(fonte)
        importado = self.importado()
        importado["fonte"]["revisao"] = "b" * 40
        with self.assertRaises(ErroBusca):
            buscador.buscar(importado)

    def test_rejeita_ids_colidentes_e_universo_inteiramente_bloqueado(self):
        base = self.fonte([("obra-a", "memória", _vetor())])
        with self.assertRaises(ErroBusca):
            BuscadorCamadaA(base, base)
        antiga = self.fonte([(OBRA_19_ANTIGA, "memória", _vetor())], "antiga")
        with self.assertRaises(ErroBusca):
            BuscadorCamadaA(antiga)

    def test_preserva_facade_existente_e_close_nao_fecha_fontes_do_chamador(self):
        fonte = self.fonte([("obra-a", "memória", _vetor())])
        facade = CorpusCompostoCamadaA(fonte)
        buscador = self.buscador(facade)
        self.assertIs(buscador.corpus, facade)
        buscador.close()
        buscador.close()
        self.assertFalse(fonte.vetores._mmap.closed)
        facade.close()
        facade.close()
        self.assertFalse(fonte.vetores._mmap.closed)
        with self.assertRaises(ErroBusca):
            buscador.buscar(self.importado())
        with self.assertRaises(ErroBusca):
            buscador._rankings({"texto": "memória"}, _vetor())
        with self.assertRaises(ErroBusca):
            buscador.lexical.ranking("memória", 50)
        with self.assertRaises(ErroBusca):
            facade.vetores_por_fonte

    def test_factory_own_fontes_fecha_mmap_e_rejeita_fonte_volume19_incorreta(self):
        pasta = self.pasta / "camada"
        pasta.mkdir()
        criar_fixture(pasta)
        with abrir_camada_a_composta(pasta) as facade:
            mmap = facade.vetores_por_fonte[0]._mmap
            self.assertEqual(facade.fragmentos_elegiveis, 4)
            self.assertEqual(facade.blocos_elegiveis, 3)
        self.assertTrue(mmap.closed)
        outra = self.pasta / "outra"
        outra.mkdir()
        criar_fixture(outra)
        with self.assertRaises(ErroBusca):
            abrir_camada_a_composta(pasta, outra)

    def test_factory_rejeita_geracao_sintetica_antes_de_abrir_as_fontes(self):
        with patch("agente_analista.preparar_volume19.validar_corpus_volume19",
                   return_value={"embedding_real": False}) as validar, \
             patch("agente_analista.busca_camada_a.CorpusCamadaA") as abrir:
            with self.assertRaisesRegex(ErroBusca, "sintéticos"):
                abrir_camada_a_composta("base", "corrigida")
            validar.assert_called_once_with("corrigida")
            abrir.assert_not_called()

    def test_pool_rrf_ancoras_pesos_tipos_sao_reutilizados_sem_nova_regra(self):
        fonte = self.fonte([("obra-a", "sonho memória", _vetor()),
                            ("obra-a", "Outra memória", _vetor(1))])
        resultado = self.buscador(fonte).buscar(self.importado())
        fusao = resultado["metodo_fusao"]
        self.assertEqual(fusao["k"], Buscador.K_RRF)
        self.assertEqual(fusao["top_por_metodo_consulta"], Buscador.TOP_METODO)
        self.assertEqual(fusao["pesos_por_tipo"], {"periodo": 1 / 3, "contextual": 1 / 3, "documento": 1 / 3})
        for candidato in resultado["candidatos"]:
            self.assertAlmostEqual(candidato["rrf"], sum(p["contribuicao_rrf"] for p in candidato["pontuacoes"]))
            for p in candidato["pontuacoes"]:
                esperado = (1 / 3) / (2 if p["consulta_tipo"] != "documento" else 1) / (60 + p["rank_bloco"])
                self.assertAlmostEqual(p["contribuicao_rrf"], esperado)

    def test_legacy_usa_bm25_positivo_com_a_descricao_original(self):
        pasta = self.pasta / "legado"
        pasta.mkdir()
        _fixture(pasta)
        fonte = Corpus(pasta)
        self.addCleanup(fonte.vetores._mmap.close)
        resultado = Buscador(fonte).buscar(_importado())
        descricao = resultado["metodo_fusao"]["bm25"]
        self.assertEqual(descricao, {"k1": 1.2, "b": 0.75,
            "tokenizacao": "palavras sem acentos, minúsculas, sem palavras funcionais; sem radicalização"})
        self.assertNotIn("camada_a", resultado)
        self.assertTrue(all(p["score"] > 0 for c in resultado["candidatos"]
                            for p in c["pontuacoes"] if p["metodo"] == "BM25"))


if __name__ == "__main__":
    unittest.main()
