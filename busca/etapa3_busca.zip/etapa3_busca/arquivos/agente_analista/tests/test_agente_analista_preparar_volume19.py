"""Testes com fonte e encoder sintéticos explícitos; nenhum E5 é simulado como real."""
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

from agente_analista import preparar_volume19 as p
from agente_analista.camada_a import CorpusCamadaA, LeitorCamadaA
from agente_analista.entrada import validar_relato
from agente_analista.ligacoes import _fontes, _validar_ligacao


class EncoderSintetico:
    descricao = {"backend": "sintetico_somente_testes", "embedding_real": False}

    def __init__(self):
        self.entradas = []

    def contar_tokens(self, texto):
        return 2 + (len(texto) + 3) // 4

    def gerar(self, entradas):
        self.entradas.extend(entradas)
        return np.asarray([np.tile(np.frombuffer(hashlib.sha256(t.encode("utf-8")).digest(),
                            dtype=np.uint8).astype(np.float32) + 1, 32) for t in entradas])


def criar_fonte_sintetica(raiz):
    """Mesmas contagens/forma, mas conteúdo inventado e hashes substituídos no teste."""
    raiz.mkdir()
    fonte_id = "fonte-" + p.SHA_PDF
    secoes = [{"id": fonte_id + f":secao:{i:04d}", "titulo": f"Seção sintética {i}",
               "origem": "sumario_nativo_pdf", "pagina_inicio": min(i + 1, 244)}
              for i in range(1, 50)]
    # Inclui acentos, caracteres fora do BMP e marcas combinantes. TXT tem o
    # comprimento fixo da fonte real para exercitar a prévia sem ler seu PDF.
    base = "Memória e ação 👁 é.\n"
    conteudo_total = 537994 - 2 * 222
    tamanho, resto = divmod(conteudo_total, 223)
    textos = [(base * ((tamanho + 1) // len(base) + 1))[:tamanho + (i < resto)] for i in range(223)]
    texto = "\n\n".join(textos)
    assert len(texto) == 537994
    paginas, cursor = [], 0
    for numero in range(1, 245):
        selecionada = 10 <= numero <= 232
        trecho = textos[numero - 10] if selecionada else "Página sintética fora da busca."
        intervalo = {"inicio": cursor, "fim": cursor + len(trecho)} if selecionada else None
        paginas.append({"pagina_pdf": numero, "texto": trecho,
            "texto_sha256_utf8": p._sha_texto(trecho), "selecionada_para_busca": selecionada,
            "offsets_texto_volume19": intervalo, "secao_id": secoes[min(numero - 1, 48)]["id"]})
        if selecionada:
            cursor += len(trecho) + (2 if numero < 232 else 0)
    (raiz / "texto_volume19.txt").write_bytes(texto.encode("utf-8"))
    p._gravar_jsonl(raiz / "paginas.jsonl", paginas)
    p._gravar_jsonl(raiz / "secoes.jsonl", secoes)
    p._gravar_json(raiz / "fonte.json", {"sha256": p.SHA_PDF, "arquivo_nome": "PDF_sintetico_testes.pdf"})
    p._gravar_json(raiz / "manifesto.json", {"fonte_sha256": p.SHA_PDF})
    p._gravar_json(raiz / "validacao_preparacao.json", {"sintetico_somente_testes": True})
    return {arquivo.name: p._sha_arquivo(arquivo) for arquivo in raiz.iterdir()}


class PrepararVolume19Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.raiz = Path(self.tmp.name)
        self.fonte = self.raiz / "fonte sintetica"
        self.hashes = criar_fonte_sintetica(self.fonte)
        remendo = patch.dict(p.HASHES_FONTE, self.hashes, clear=True)
        remendo.start()
        self.addCleanup(remendo.stop)
        self.encoder = EncoderSintetico()

    def gerar(self, **opcoes):
        saida = self.raiz / "corpus novo"
        return saida, p.preparar_volume19(self.fonte, saida, cache_modelos=self.raiz / "cache",
                                        encoder=self.encoder, lote=17, **opcoes)

    def test_corpus_compativel_preserva_texto_unicode_paginas_e_citacoes(self):
        antes = {a.name: a.read_bytes() for a in self.fonte.iterdir()}
        saida, relatorio = self.gerar()
        self.assertTrue(relatorio["corpus_validado"])
        self.assertFalse(relatorio["embedding_real"])
        self.assertEqual(relatorio["estado"], "corpus_sintetico_somente_testes")
        self.assertFalse(relatorio["pronto_para_busca"])
        texto = (self.fonte / "texto_volume19.txt").read_bytes().decode("utf-8")
        with LeitorCamadaA(saida) as leitor:
            self.assertEqual(leitor.manifesto["obra_id"], p.OBRA_ID)
            fs = leitor._referencias
            self.assertGreater(len(fs), 223)
            self.assertEqual("".join(f["texto"] for f in fs), texto)
            self.assertEqual(len(fs), len(self.encoder.entradas))
            self.assertTrue(all(len(e) > 0 and e.startswith("passage: ") for e in self.encoder.entradas))
            self.assertTrue(all(self.encoder.contar_tokens(e) <= 504 for e in self.encoder.entradas))
            self.assertEqual(leitor.fragmento(fs[0]["id"])["rastreio"]["paginas_pdf"], [10])
            self.assertEqual(leitor.fragmento(fs[-1]["id"])["rastreio"]["paginas_pdf"], [232])
            self.assertEqual(leitor._paginas[p.OBRA_ID][0]["inicio"], 0)
            self.assertEqual(leitor._paginas[p.OBRA_ID][-1]["fim"], len(texto))
            self.assertEqual(leitor._vetores.shape, (len(fs), 1024))
            self.assertFalse(leitor._vetores.flags.writeable)
            self.assertTrue(leitor.busca_lexical("memória"))
            self.assertNotIn("obra-3b8627dba63512a2", leitor._obras)
        with CorpusCamadaA(saida) as corpus:
            self.assertEqual(corpus.fragmentos[0]["volume"], 19)
            self.assertEqual(corpus.fragmentos[0]["paginas"], [10])
            self.assertEqual(corpus.fragmentos[-1]["paginas"], [232])
            bloco = corpus.blocos[corpus.fragmentos[0]["bloco_id"]]
            relato = validar_relato("Um relato sintético com memória.\n\nOutro parágrafo sintético.")
            paragrafos, fontes = _fontes(relato, {"candidatos": [bloco]})
            fronteira = bloco["fragmentos"][0]["fim"]
            inicio, fim = fronteira - 5, fronteira + 5
            proposta = {"paragrafo": "P1", "bloco_id": bloco["bloco_id"],
                "relato": {k: relato["paragrafos"][0][k] for k in ("inicio", "fim", "texto")},
                "freud": {"inicio": inicio, "fim": fim, "texto": bloco["texto"][inicio:fim]},
                "fragmentos_ids": bloco["fragmentos_ids"], "situacao": "parcial",
                "observacao": "Verificação sintética de citação literal.", "conceito": "",
                "ligacao": "Teste de offsets.", "justificativa": "Cruza fragmentos na mesma página.",
                "limites": "Sem avaliação interpretativa.", "alternativas": []}
            validada, motivo = _validar_ligacao(proposta, relato, paragrafos, fontes)
            self.assertIsNone(motivo)
            self.assertEqual(validada["freud"]["texto"], bloco["texto"][inicio:fim])
            self.assertEqual(validada["referencia"]["paginas"], [10])
        self.assertEqual(antes, {a.name: a.read_bytes() for a in self.fonte.iterdir()})
        self.assertTrue(p.validar_corpus_volume19(saida)["corpus_validado"])

    def test_fonte_modificada_recusada_antes_do_encoder(self):
        (self.fonte / "texto_volume19.txt").write_text("Alterado", encoding="utf-8")
        with patch.object(p, "EncoderE5") as real:
            with self.assertRaisesRegex(p.ErroPreparacaoVolume19, "modificada"):
                p.preparar_volume19(self.fonte, self.raiz / "saida", cache_modelos=self.raiz)
        real.assert_not_called()
        self.assertFalse((self.raiz / "saida").exists())

    def test_offsets_inconsistentes_recusados_mesmo_com_hash_fixture_atualizado(self):
        paginas = p._jsonl(self.fonte / "paginas.jsonl")
        paginas[9]["offsets_texto_volume19"]["inicio"] = 1
        (self.fonte / "paginas.jsonl").unlink()
        p._gravar_jsonl(self.fonte / "paginas.jsonl", paginas)
        p.HASHES_FONTE["paginas.jsonl"] = p._sha_arquivo(self.fonte / "paginas.jsonl")
        with self.assertRaisesRegex(p.ErroPreparacaoVolume19, "Offset"):
            p.carregar_fonte(self.fonte)

    def test_saida_existente_nao_sobrescrita(self):
        saida = self.raiz / "corpus novo"
        saida.mkdir()
        (saida / "meu.txt").write_text("Preservar", encoding="utf-8")
        with self.assertRaisesRegex(p.ErroPreparacaoVolume19, "já existe"):
            self.gerar()
        self.assertEqual((saida / "meu.txt").read_text(), "Preservar")
        self.assertEqual(self.encoder.entradas, [])

    def test_nan_ou_zero_na_inferencia_nao_publicam_corpus(self):
        for valor in (0.0, float("nan")):
            with self.subTest(valor=valor), patch.object(self.encoder, "gerar", side_effect=
                    lambda entradas: np.full((len(entradas), 1024), valor, dtype=np.float32)):
                with self.assertRaises(p.ErroPreparacaoVolume19):
                    self.gerar()
                self.assertFalse((self.raiz / "corpus novo").exists())
                self.assertFalse(list(self.raiz.glob(".volume19-geracao-*")))

    def test_link_com_falha_desfaz_apenas_os_arquivos_da_execucao(self):
        link_original, contador = os.link, 0
        def falhar(origem, destino):
            nonlocal contador
            contador += 1
            if contador == 2:
                raise OSError("Falha sintética de publicação")
            return link_original(origem, destino)
        with patch.object(p.os, "link", side_effect=falhar):
            with self.assertRaisesRegex(OSError, "sintética"):
                self.gerar()
        self.assertFalse((self.raiz / "corpus novo").exists())
        self.assertFalse(list(self.raiz.glob(".volume19-geracao-*")))

    def test_publicacao_com_falha_preserva_arquivo_editado_por_outro_processo(self):
        link_original, contador, primeiro = os.link, 0, None
        def falhar(origem, destino):
            nonlocal contador, primeiro
            contador += 1
            if contador == 2:
                primeiro.write_text("Editado pelo usuário", encoding="utf-8")
                raise OSError("Falha sintética após edição")
            resultado = link_original(origem, destino)
            primeiro = Path(destino)
            return resultado
        with patch.object(p.os, "link", side_effect=falhar):
            with self.assertRaisesRegex(OSError, "após edição"):
                self.gerar()
        self.assertEqual(primeiro.read_text(), "Editado pelo usuário")
        self.assertFalse((self.raiz / "corpus novo" / "manifesto.json").exists())

    def test_encoder_sintetico_nao_pode_ser_rotulado_como_real(self):
        saida, _ = self.gerar()
        caminho = saida / "manifesto.json"
        manifesto = json.loads(caminho.read_text())
        manifesto["embedding_real"] = True
        manifesto["encoder"]["embedding_real"] = True
        caminho.write_text(json.dumps(manifesto))
        with self.assertRaisesRegex(p.ErroPreparacaoVolume19, "Execução E5 real"):
            p.validar_corpus_volume19(saida)

    def test_alteracao_matriz_detectada_pelo_hash_integral(self):
        saida, _ = self.gerar()
        matriz = np.load(saida / "vetores_e5.npy", mmap_mode="r+")
        matriz[0, 0] += 0.01
        matriz.flush()
        matriz._mmap.close()
        with self.assertRaisesRegex(p.ErroPreparacaoVolume19, "Hash do artefato"):
            p.validar_corpus_volume19(saida)

    def test_proveniencia_divergente_detectada_mesmo_se_hash_arquivo_recalculado(self):
        saida, _ = self.gerar()
        caminho = saida / "entradas_vetorizacao.jsonl"
        registros = p._jsonl(caminho)
        registros[0]["vetor_sha256_float32_le"] = "0" * 64
        caminho.unlink()
        p._gravar_jsonl(caminho, registros)
        manifesto_path = saida / "manifesto.json"
        manifesto = json.loads(manifesto_path.read_text())
        manifesto["arquivos"][caminho.name] = {"bytes": caminho.stat().st_size, "sha256": p._sha_arquivo(caminho)}
        manifesto_path.write_text(json.dumps(manifesto))
        with self.assertRaisesRegex(p.ErroPreparacaoVolume19, "Vínculo entrada/linha"):
            p.validar_corpus_volume19(saida)

    def test_fragmentacao_palavra_longa_sem_descartar_unicode(self):
        texto = "🧠é" * 2000
        fs = p._fragmentar(texto, "Cabeçalho", self.encoder)
        self.assertEqual("".join(texto[a:b] for a, b, _ in fs), texto)
        self.assertTrue(all(n <= 504 for _, _, n in fs))
        self.assertGreater(len(fs), 1)

    def test_import_e_cli_ajuda_nao_carregam_embeddings(self):
        import subprocess
        codigo = ("import importlib.util,sys; "
                  f"s=importlib.util.spec_from_file_location('builder', {str(Path(p.__file__))!r}); "
                  "m=importlib.util.module_from_spec(s);s.loader.exec_module(m);"
                  "assert not any(n in sys.modules for n in ('torch','transformers','flask'));"
                  "assert callable(m.preparar_volume19)")
        import sys
        proc = subprocess.run([sys.executable, "-c", codigo], capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        proc = subprocess.run([sys.executable, p.__file__, "--help"], capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertIn("--baixar-modelo", proc.stdout)


if __name__ == "__main__":
    unittest.main()
