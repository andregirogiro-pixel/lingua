"""Gera um corpus separado do volume 19, com E5 real e sem truncamento.

Pode ser executado diretamente no Colab ou no Python E5 do Mac. O download
exige --baixar-modelo; a revisão e os hashes dos seis artefatos são fixos.
Não importa Flask, não altera fontes, corpus existentes ou configuração de
busca. NumPy é a única dependência importada fora da biblioteca padrão;
Torch/Transformers/Hugging Face são carregados apenas para a geração real.

Os textos são os bytes auditados da preparação volume19_fonte_v2. Todas as
páginas selecionadas e seus separadores permanecem no TXT, blocos e fragmentos.
Offsets contam pontos de código Unicode, base 0 e fim exclusivo. As seções
vêm do sumário por página: sua divisão editorial dentro da página é pendente.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import sqlite3
import tempfile
from typing import Any, Callable

import numpy as np

MODELO = "intfloat/multilingual-e5-large"
REVISAO = "3d7cfbdacd47fdda877c5cd8a79fbcc4f2a574f3"
SHA_PDF = "1b4ea213276f48f77b53349109c9d9a352ade2225de43aa50765225db5c0a3ba"
OBRA_ID = "obra-" + SHA_PDF[:16]
TITULO = "Moisés e o monoteísmo, Compêndio de psicanálise e outros textos (1937–1939)"
LIMITE_ENTRADA = 504  # 512, com margem explícita de oito tokens.
HASHES_FONTE = {
    "manifesto.json": "10e0bb23757b34c62c3c0a6fde950022f5097d6da31617c45faeec4d466ee376",
    "fonte.json": "fe8f25c9dfb4281800a4216eba6a6780b5638fd952fedee74075f309c5cfea42",
    "paginas.jsonl": "f37696dd02acb34dca5e2498c34ca65ed9d82abc31abe68622b8121ba99f9e36",
    "secoes.jsonl": "2e356532e1adb704916c2e7641bb6f785ff893c3f2b94ff3c58246721a3666a6",
    "texto_volume19.txt": "ab3e323c1fbcd5a89b9e8de7669d6a7e0948558f995cdee11b671ff960be4606",
    "validacao_preparacao.json": "1ddd1b6d59e5dab784bb23830e193e729436cf2e1e1ac4531daafe00d23e95d0",
}
HASHES_MODELO = {
    "config.json": "e42d98d0c211928d788467aa951000391017f647c76ca8ce2ef6dd8d0c9ce5ca",
    "model.safetensors": "020afdebf2762b29fcaf286629a96c3b3b65af241f6a08226b1cfee60a21def6",
    "sentencepiece.bpe.model": "cfc8146abe2a0488e9e2a0c56de7952f7c11ab059eca145a0a727afce0db2865",
    "special_tokens_map.json": "06e405a36dfe4b9604f484f6a1e619af1a7f7d09e34a8555eb0b77b66318067f",
    "tokenizer.json": "62c24cdc13d4c9952d63718d6c9fa4c287974249e16b7ade6d5a85e7bbb75626",
    "tokenizer_config.json": "efb5c0d09722e5fe59a462cd2a9976ee216d55b037597d997cd3fe833216da15",
}
SCHEMA = """
CREATE TABLE obras(id TEXT PRIMARY KEY, titulo TEXT, volume_sugerido INTEGER,
 pdf_original TEXT, sha256_pdf TEXT, paginas INTEGER, texto_sha256 TEXT, estado TEXT);
CREATE TABLE secoes(id TEXT PRIMARY KEY, obra_id TEXT REFERENCES obras(id),
 titulo TEXT, origem TEXT, pagina_inicio INTEGER);
CREATE TABLE paginas(obra_id TEXT REFERENCES obras(id), pagina_pdf INTEGER,
 metodo TEXT, confianca_ocr REAL, inicio INTEGER, fim INTEGER,
 PRIMARY KEY(obra_id,pagina_pdf));
CREATE TABLE blocos(id TEXT PRIMARY KEY, obra_id TEXT REFERENCES obras(id),
 secao_id TEXT REFERENCES secoes(id), inicio INTEGER, fim INTEGER,
 texto TEXT, sha256_texto TEXT, paginas_json TEXT,
 papeis_provisorios_json TEXT, conceitos_lexicais_json TEXT);
CREATE TABLE fragmentos(id TEXT PRIMARY KEY, bloco_id TEXT REFERENCES blocos(id),
 obra_id TEXT REFERENCES obras(id), secao_id TEXT REFERENCES secoes(id),
 ordem INTEGER, inicio INTEGER, fim INTEGER, tokens INTEGER,
 anterior_id TEXT, posterior_id TEXT, cabecalho TEXT, texto TEXT, entrada_sha256 TEXT);
CREATE VIRTUAL TABLE fragmentos_fts USING fts5(fragmento_id UNINDEXED,
 cabecalho, texto, tokenize='unicode61 remove_diacritics 2');
"""


class ErroPreparacaoVolume19(ValueError):
    """Fonte, ambiente ou artefato não satisfazem a preparação auditada."""


def _sha_bytes(dados: bytes) -> str:
    return hashlib.sha256(dados).hexdigest()


def _sha_texto(texto: str) -> str:
    return _sha_bytes(texto.encode("utf-8"))


def _sha_arquivo(caminho: Path) -> str:
    sha = hashlib.sha256()
    with caminho.open("rb") as arquivo:
        for trecho in iter(lambda: arquivo.read(1024 * 1024), b""):
            sha.update(trecho)
    return sha.hexdigest()


def _objeto_json(pares):
    objeto = {}
    for chave, valor in pares:
        if chave in objeto:
            raise ErroPreparacaoVolume19(f"Chave JSON duplicada: {chave}")
        objeto[chave] = valor
    return objeto


def _json(texto: str):
    return json.loads(texto, object_pairs_hook=_objeto_json,
                      parse_constant=lambda x: (_ for _ in ()).throw(
                          ErroPreparacaoVolume19(f"Número JSON inválido: {x}")))


def _jsonl(caminho: Path) -> list[dict]:
    registros = [_json(linha) for linha in caminho.read_text(encoding="utf-8").splitlines()]
    if any(type(r) is not dict for r in registros):
        raise ErroPreparacaoVolume19(f"Objeto esperado em {caminho.name}")
    return registros


def _gravar_json(caminho: Path, objeto: Any) -> None:
    with caminho.open("x", encoding="utf-8", newline="\n") as arquivo:
        json.dump(objeto, arquivo, ensure_ascii=False, indent=2, allow_nan=False)
        arquivo.write("\n")


def _gravar_jsonl(caminho: Path, registros: list[dict]) -> None:
    with caminho.open("x", encoding="utf-8", newline="\n") as arquivo:
        for registro in registros:
            arquivo.write(json.dumps(registro, ensure_ascii=False, allow_nan=False) + "\n")


def _inteiro(valor, nome, minimo=0):
    if type(valor) is not int or valor < minimo:
        raise ErroPreparacaoVolume19(f"{nome} exige inteiro >= {minimo}")
    return valor


def carregar_fonte(fonte: str | Path) -> dict:
    """Verifica os seis hashes conhecidos antes de ler os offsets auditados."""
    raiz = Path(fonte).expanduser().resolve()
    for nome, esperado in HASHES_FONTE.items():
        caminho = raiz / nome
        if not caminho.is_file() or caminho.is_symlink() or _sha_arquivo(caminho) != esperado:
            raise ErroPreparacaoVolume19(f"Preparação auditada ausente ou modificada: {nome}")
    manifesto = _json((raiz / "manifesto.json").read_text(encoding="utf-8"))
    info = _json((raiz / "fonte.json").read_text(encoding="utf-8"))
    texto = (raiz / "texto_volume19.txt").read_bytes().decode("utf-8")
    paginas, secoes = _jsonl(raiz / "paginas.jsonl"), _jsonl(raiz / "secoes.jsonl")
    if manifesto["fonte_sha256"] != SHA_PDF or info["sha256"] != SHA_PDF:
        raise ErroPreparacaoVolume19("Identificação do PDF diverge da fonte auditada")
    if len(paginas) != 244 or len(secoes) != 49 or len(texto) != 537994:
        raise ErroPreparacaoVolume19("Contagens da preparação auditada divergentes")
    por_secao = {s["id"]: s for s in secoes}
    selecionadas = []
    cursor = 0
    for numero, pagina in enumerate(paginas, 1):
        if pagina["pagina_pdf"] != numero or pagina["texto_sha256_utf8"] != _sha_texto(pagina["texto"]):
            raise ErroPreparacaoVolume19("Ordem ou hash das páginas inválido")
        if pagina["selecionada_para_busca"] is not (10 <= numero <= 232):
            raise ErroPreparacaoVolume19("Seleção diverge do intervalo PDF 10–232")
        if pagina["selecionada_para_busca"]:
            intervalo = pagina["offsets_texto_volume19"]
            if intervalo["inicio"] != cursor or texto[cursor:intervalo["fim"]] != pagina["texto"]:
                raise ErroPreparacaoVolume19("Offset da página não reproduz o TXT")
            if pagina["secao_id"] not in por_secao:
                raise ErroPreparacaoVolume19("Página selecionada sem seção do sumário")
            cursor = intervalo["fim"]
            if numero < 232:
                if texto[cursor:cursor + 2] != "\n\n":
                    raise ErroPreparacaoVolume19("Separador de páginas divergente")
                cursor += 2
            selecionadas.append(pagina)
    if cursor != len(texto):
        raise ErroPreparacaoVolume19("Páginas não cobrem integralmente o TXT")
    return {"raiz": raiz, "info": info, "texto": texto, "paginas": paginas,
            "secoes": secoes, "selecionadas": selecionadas}


class EncoderE5:
    """Encoder real com mean pooling incluindo prefixo e tokens especiais."""

    def __init__(self, cache_modelos, *, baixar_modelo=False, dispositivo="cpu"):
        cache = Path(cache_modelos).expanduser().resolve()
        os.environ.setdefault("HF_XET_CACHE", str(cache / "xet"))
        try:
            import torch
            from huggingface_hub import snapshot_download
            from transformers import AutoModel, AutoTokenizer
        except ImportError as exc:
            raise ErroPreparacaoVolume19(
                "Use o Python E5 existente ou instale as dependências do notebook: "
                "torch, transformers, safetensors, huggingface-hub e sentencepiece") from exc
        try:
            snapshot = Path(snapshot_download(
                repo_id=MODELO, revision=REVISAO, cache_dir=str(cache),
                local_files_only=not baixar_modelo, allow_patterns=list(HASHES_MODELO),
            ))
        except Exception as exc:
            raise ErroPreparacaoVolume19(
                "E5 da revisão fixa indisponível no cache; no Colab autorize o "
                "download com --baixar-modelo. Nenhum download ocorre por padrão.") from exc
        if snapshot.name != REVISAO:
            raise ErroPreparacaoVolume19("O snapshot não corresponde ao commit E5 fixo")
        for nome, esperado in HASHES_MODELO.items():
            arquivo = snapshot / nome
            if not arquivo.is_file() or _sha_arquivo(arquivo) != esperado:
                raise ErroPreparacaoVolume19(f"Artefato E5 diverge do cache auditado: {nome}")
        if dispositivo == "auto":
            dispositivo = "cuda" if torch.cuda.is_available() else "cpu"
        if dispositivo == "cuda" and not torch.cuda.is_available():
            raise ErroPreparacaoVolume19("GPU CUDA selecionada, mas indisponível")
        if dispositivo == "mps" and not torch.backends.mps.is_available():
            raise ErroPreparacaoVolume19("GPU MPS selecionada, mas indisponível")
        if dispositivo not in {"cpu", "cuda", "mps"}:
            raise ErroPreparacaoVolume19("Dispositivo deve ser cpu, cuda, mps ou auto")
        self.torch, self.dispositivo = torch, dispositivo
        self.tokenizer = AutoTokenizer.from_pretrained(
            str(snapshot), use_fast=True, local_files_only=True, trust_remote_code=False)
        if not self.tokenizer.is_fast or self.tokenizer.model_max_length != 512:
            raise ErroPreparacaoVolume19("Tokenizador fast E5 com limite 512 esperado")
        self.modelo = AutoModel.from_pretrained(
            str(snapshot), local_files_only=True, trust_remote_code=False, use_safetensors=True)
        config = self.modelo.config
        if config.model_type != "xlm-roberta" or config.hidden_size != 1024:
            raise ErroPreparacaoVolume19("Arquitetura XLM-RoBERTa E5 large incompatível")
        self.modelo.to(device=dispositivo, dtype=torch.float32).eval()
        self.descricao = {
            "backend": "transformers_torch_mean_pooling", "modelo": MODELO, "revisao": REVISAO,
            "tokenizador": MODELO, "tokenizador_revisao": REVISAO,
            "pooling": "mean", "include_prompt": True, "dimensao": 1024,
            "precisao_inferencia": "float32", "dispositivo": dispositivo,
            "prefixo_automatico": False, "truncamento_automatico": False,
            "artefatos": dict(HASHES_MODELO), "embedding_real": True,
            "bibliotecas": {n: importlib.metadata.version(n) for n in (
                "torch", "transformers", "huggingface-hub", "numpy")},
        }

    def contar_tokens(self, texto: str) -> int:
        return len(self.tokenizer(texto, add_special_tokens=True,
                                  truncation=False, padding=False)["input_ids"])

    def gerar(self, entradas: list[str]) -> np.ndarray:
        if any(self.contar_tokens(e) > LIMITE_ENTRADA for e in entradas):
            raise ErroPreparacaoVolume19("Entrada excede 504 tokens; truncamento proibido")
        tokens = self.tokenizer(entradas, padding=True, truncation=False,
                                add_special_tokens=True, return_tensors="pt")
        tokens = {k: v.to(self.dispositivo) for k, v in tokens.items()}
        with self.torch.inference_mode():
            saida = self.modelo(**tokens).last_hidden_state.float()
            mascara = tokens["attention_mask"].unsqueeze(-1).to(saida.dtype)
            somas = (saida * mascara).sum(dim=1)
            vetores = somas / mascara.sum(dim=1).clamp(min=1)
            return vetores.detach().float().cpu().numpy()


def _contar(encoder, texto):
    return _inteiro(encoder.contar_tokens(texto), "contagem de tokens", 1)


def _fragmentar(texto: str, cabecalho: str, encoder) -> list[tuple[int, int, int]]:
    """Particiona tudo, incluindo espaços, verificando cada entrada efetiva."""
    prefixo = "passage: " + cabecalho + "\n"
    resultado, inicio = [], 0
    while inicio < len(texto):
        # Cada limite devolvido foi realmente tokenizado. A busca pode produzir
        # uma janela menor quando tokenizações de prefixos não são monotônicas;
        # isso altera apenas o tamanho, nunca cobertura ou orçamento.
        baixo, alto = inicio + 1, len(texto)
        if _contar(encoder, prefixo + texto[inicio:baixo]) > LIMITE_ENTRADA:
            raise ErroPreparacaoVolume19("Nem um caractere cabe com o cabeçalho E5")
        if _contar(encoder, prefixo + texto[inicio:alto]) <= LIMITE_ENTRADA:
            fim = alto
        else:
            while baixo < alto:
                meio = (baixo + alto + 1) // 2
                if _contar(encoder, prefixo + texto[inicio:meio]) <= LIMITE_ENTRADA:
                    baixo = meio
                else:
                    alto = meio - 1
            fim = baixo
            # Prefere fim de linha/palavra sem remover nenhum caractere.
            for limite in range(fim, inicio + (fim - inicio) // 2, -1):
                if texto[limite - 1].isspace() and _contar(
                        encoder, prefixo + texto[inicio:limite]) <= LIMITE_ENTRADA:
                    fim = limite
                    break
        tokens = _contar(encoder, prefixo + texto[inicio:fim])
        if tokens > LIMITE_ENTRADA:
            raise ErroPreparacaoVolume19("Fragmento final ultrapassa o orçamento E5")
        resultado.append((inicio, fim, tokens))
        inicio = fim
    return resultado


def _normalizar(vetores, quantidade):
    dados = np.asarray(vetores, dtype=np.float32)
    if dados.shape != (quantidade, 1024) or not np.isfinite(dados).all():
        raise ErroPreparacaoVolume19("Encoder retornou shape inválido ou NaN/infinito")
    normas = np.linalg.norm(dados.astype(np.float64), axis=1)
    if np.any(normas <= 0):
        raise ErroPreparacaoVolume19("Encoder retornou vetor zero")
    normalizados = np.asarray(dados.astype(np.float64) / normas[:, None], dtype="<f4")
    if not np.allclose(np.linalg.norm(normalizados, axis=1), 1, rtol=0, atol=3e-5):
        raise ErroPreparacaoVolume19("Falha na normalização L2 float32")
    return normalizados


def _planejar(fonte, encoder):
    texto, secoes = fonte["texto"], {s["id"]: s for s in fonte["secoes"]}
    blocos, fragmentos = [], []
    paginas_selecionadas = fonte["selecionadas"]
    for indice, pagina in enumerate(paginas_selecionadas):
        inicio = pagina["offsets_texto_volume19"]["inicio"]
        fim = (paginas_selecionadas[indice + 1]["offsets_texto_volume19"]["inicio"]
               if indice + 1 < len(paginas_selecionadas) else len(texto))
        secao = secoes[pagina["secao_id"]]
        bid = OBRA_ID + f"-b{indice:05d}"
        bloco = {"id": bid, "obra_id": OBRA_ID, "secao_id": secao["id"],
                 "inicio": inicio, "fim": fim, "texto": texto[inicio:fim],
                 "sha256_texto": _sha_texto(texto[inicio:fim]),
                 "paginas": [pagina["pagina_pdf"]], "papeis_provisorios": [], "conceitos_lexicais": []}
        cabecalho = "Freud — Obras completas, volume 19 — " + secao["titulo"]
        for ordem, (a, b, tokens) in enumerate(_fragmentar(bloco["texto"], cabecalho, encoder)):
            trecho = bloco["texto"][a:b]
            fragmentos.append({"id": bid + f"-f{ordem:03d}", "bloco_id": bid,
                "obra_id": OBRA_ID, "secao_id": secao["id"], "ordem": ordem,
                "inicio": a, "fim": b, "texto": trecho, "tokens_entrada": tokens,
                "cabecalho": cabecalho, "entrada_sha256": _sha_texto("passage: " + cabecalho + "\n" + trecho),
                "anterior_id": None, "posterior_id": None, "paginas": bloco["paginas"]})
        blocos.append(bloco)
    for posicao, fragmento in enumerate(fragmentos):
        fragmento["anterior_id"] = fragmentos[posicao - 1]["id"] if posicao else None
        fragmento["posterior_id"] = fragmentos[posicao + 1]["id"] if posicao + 1 < len(fragmentos) else None
    return blocos, fragmentos


def _gravar_sqlite(raiz, fonte, blocos, fragmentos):
    with sqlite3.connect(raiz / "corpus.sqlite") as con:
        con.executescript(SCHEMA)
        con.execute("PRAGMA foreign_keys=ON")
        con.execute("INSERT INTO obras VALUES (?,?,?,?,?,?,?,?)", (
            OBRA_ID, TITULO, 19, fonte["info"]["arquivo_nome"], SHA_PDF, 244,
            _sha_texto(fonte["texto"]), "fonte_corrigida_revisao_editorial_pendente"))
        for s in fonte["secoes"]:
            con.execute("INSERT INTO secoes VALUES (?,?,?,?,?)", (
                s["id"], OBRA_ID, s["titulo"], s["origem"], s["pagina_inicio"]))
        for p in fonte["paginas"]:
            intervalo = p["offsets_texto_volume19"]
            a = intervalo["inicio"] if intervalo else (0 if p["pagina_pdf"] < 10 else len(fonte["texto"]))
            b = intervalo["fim"] if intervalo else a
            con.execute("INSERT INTO paginas VALUES (?,?,?,?,?,?)", (
                OBRA_ID, p["pagina_pdf"], "pdf_texto" if intervalo else "fora_busca_intervalo_vazio",
                None, a, b))
        for b in blocos:
            con.execute("INSERT INTO blocos VALUES (?,?,?,?,?,?,?,?,?,?)", (
                b["id"], OBRA_ID, b["secao_id"], b["inicio"], b["fim"], b["texto"],
                b["sha256_texto"], json.dumps(b["paginas"]), "[]", "[]"))
        for f in fragmentos:
            con.execute("INSERT INTO fragmentos VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", tuple(f[k] for k in (
                "id", "bloco_id", "obra_id", "secao_id", "ordem", "inicio", "fim", "tokens_entrada",
                "anterior_id", "posterior_id", "cabecalho", "texto", "entrada_sha256")))
            con.execute("INSERT INTO fragmentos_fts(fragmento_id,cabecalho,texto) VALUES (?,?,?)", (
                f["id"], f["cabecalho"], f["texto"]))


def validar_corpus_volume19(saida: str | Path) -> dict:
    """Confere integralmente o corpus final sem carregar o modelo ou a rede.

    Hashes comprovam integridade e vínculo das linhas com a execução registrada;
    não substituem inferência independente nem conferência editorial integral.
    """
    raiz = Path(saida).expanduser().resolve()
    manifesto = _json((raiz / "manifesto.json").read_text(encoding="utf-8"))
    esperado = {"schema": "camada_a_freud.v1", "modelo": MODELO, "revisao": REVISAO,
        "tokenizador": MODELO, "tokenizador_revisao": REVISAO, "pooling": "mean",
        "include_prompt": True, "pronto_para_busca": False,
        "dimensao": 1024, "tokens_maximo": 512, "margem_tokens": 8,
        "prefixo_passagens": "passage: ", "prefixo_consultas": "query: ",
        "tipo_vetor": "float32", "normalizacao": "L2", "obra_id": OBRA_ID,
        "sha256_pdf": SHA_PDF, "blocos": 223, "paginas_pdf": 244}
    for chave, valor in esperado.items():
        if manifesto.get(chave) != valor or type(manifesto.get(chave)) is not type(valor):
            raise ErroPreparacaoVolume19(f"Manifesto de saída incompatível em {chave}")
    if type(manifesto.get("embedding_real")) is not bool or manifesto.get("fonte_hashes") != HASHES_FONTE:
        raise ErroPreparacaoVolume19("Metadados de geração/fonte insuficientes")
    descricao = manifesto.get("encoder")
    if type(descricao) is not dict or descricao.get("embedding_real") is not manifesto["embedding_real"]:
        raise ErroPreparacaoVolume19("Identidade de execução do encoder divergente")
    if manifesto["embedding_real"]:
        descricao_esperada = {"backend": "transformers_torch_mean_pooling", "modelo": MODELO,
            "revisao": REVISAO, "tokenizador": MODELO, "tokenizador_revisao": REVISAO,
            "pooling": "mean", "include_prompt": True, "dimensao": 1024,
            "precisao_inferencia": "float32", "prefixo_automatico": False,
            "truncamento_automatico": False, "artefatos": HASHES_MODELO}
        if any(descricao.get(k) != v or type(descricao.get(k)) is not type(v)
               for k, v in descricao_esperada.items()):
            raise ErroPreparacaoVolume19("Execução E5 real não comprova o contrato/artefatos fixos")
    nomes = {"corpus.sqlite", "fragmentos.jsonl", "blocos.jsonl", "paginas.jsonl",
             "secoes.jsonl", "vetores_e5.npy", "texto_volume19.txt", "entradas_vetorizacao.jsonl"}
    if set(manifesto["arquivos"]) != nomes:
        raise ErroPreparacaoVolume19("Manifesto não cobre os oito artefatos esperados")
    for nome, registro in manifesto["arquivos"].items():
        arquivo = raiz / nome
        if arquivo.is_symlink() or not arquivo.is_file() or arquivo.stat().st_size != registro["bytes"]:
            raise ErroPreparacaoVolume19(f"Arquivo ausente/alterado: {nome}")
        if _sha_arquivo(arquivo) != registro["sha256"]:
            raise ErroPreparacaoVolume19(f"Hash do artefato divergente: {nome}")
    texto = (raiz / "texto_volume19.txt").read_bytes().decode("utf-8")
    if _sha_texto(texto) != HASHES_FONTE["texto_volume19.txt"]:
        raise ErroPreparacaoVolume19("TXT de saída diverge do texto auditado")
    refs, blocos = _jsonl(raiz / "fragmentos.jsonl"), _jsonl(raiz / "blocos.jsonl")
    proveniencia = _jsonl(raiz / "entradas_vetorizacao.jsonl")
    if len(refs) != manifesto["fragmentos"] or len(proveniencia) != len(refs) or len(blocos) != 223:
        raise ErroPreparacaoVolume19("Contagens de fragmentos/blocos/proveniência divergentes")
    por_bloco = {b["id"]: b for b in blocos}
    if len(por_bloco) != 223 or len({f["id"] for f in refs}) != len(refs):
        raise ErroPreparacaoVolume19("IDs duplicados")
    cursor = 0
    por_bloco_refs = {bid: [] for bid in por_bloco}
    for b in blocos:
        if b["inicio"] != cursor or b["texto"] != texto[b["inicio"]:b["fim"]] or b["sha256_texto"] != _sha_texto(b["texto"]):
            raise ErroPreparacaoVolume19("Blocos não preservam a cobertura integral do TXT")
        cursor = b["fim"]
    if cursor != len(texto):
        raise ErroPreparacaoVolume19("Fim dos blocos diverge do TXT")
    matriz = np.load(raiz / "vetores_e5.npy", mmap_mode="r", allow_pickle=False)
    try:
        if matriz.shape != (len(refs), 1024) or matriz.dtype != np.dtype("float32") or matriz.flags.writeable:
            raise ErroPreparacaoVolume19("Matriz incompatível")
        for indice, (f, p) in enumerate(zip(refs, proveniencia)):
            b = por_bloco.get(f["bloco_id"])
            if not b or f["obra_id"] != OBRA_ID or f["secao_id"] != b["secao_id"] or f["paginas"] != b["paginas"]:
                raise ErroPreparacaoVolume19("Referência de fragmento incompatível")
            if not 0 <= f["inicio"] < f["fim"] <= len(b["texto"]) or f["texto"] != b["texto"][f["inicio"]:f["fim"]]:
                raise ErroPreparacaoVolume19("Texto/offset do fragmento divergente")
            if not 1 <= _inteiro(f["tokens_entrada"], "tokens", 1) <= LIMITE_ENTRADA:
                raise ErroPreparacaoVolume19("Tokens excedem orçamento")
            entrada = "passage: " + f["cabecalho"] + "\n" + f["texto"]
            if f["entrada_sha256"] != _sha_texto(entrada):
                raise ErroPreparacaoVolume19("Hash da entrada efetiva divergente")
            if f["anterior_id"] != (refs[indice - 1]["id"] if indice else None) or f["posterior_id"] != (refs[indice + 1]["id"] if indice + 1 < len(refs) else None):
                raise ErroPreparacaoVolume19("Vizinhança incompatível")
            vetor = np.asarray(matriz[indice], dtype="<f4")
            if not np.isfinite(vetor).all() or not np.isclose(np.linalg.norm(vetor), 1, rtol=0, atol=3e-5):
                raise ErroPreparacaoVolume19("Vetor não finito ou sem L2")
            if p != {"linha": indice, "fragmento_id": f["id"], "entrada_sha256": f["entrada_sha256"],
                     "tokens_entrada": f["tokens_entrada"], "vetor_sha256_float32_le": _sha_bytes(vetor.tobytes())}:
                raise ErroPreparacaoVolume19("Vínculo entrada/linha da matriz divergente")
            por_bloco_refs[f["bloco_id"]].append(f)
        for bid, fs in por_bloco_refs.items():
            cursor = 0
            for ordem, f in enumerate(fs):
                if f["ordem"] != ordem or f["inicio"] != cursor:
                    raise ErroPreparacaoVolume19("Fragmentos com lacunas/sobreposições")
                cursor = f["fim"]
            if cursor != len(por_bloco[bid]["texto"]):
                raise ErroPreparacaoVolume19("Fragmentos não cobrem bloco")
    finally:
        vetor = None
        matriz._mmap.close()
    con = sqlite3.connect((raiz / "corpus.sqlite").as_uri() + "?mode=ro&immutable=1", uri=True)
    con.row_factory = sqlite3.Row
    try:
        if [r[0] for r in con.execute("PRAGMA quick_check")] != ["ok"] or list(con.execute("PRAGMA foreign_key_check")):
            raise ErroPreparacaoVolume19("SQLite inválido")
        obras = list(con.execute("SELECT * FROM obras"))
        if len(obras) != 1 or obras[0]["id"] != OBRA_ID or obras[0]["sha256_pdf"] != SHA_PDF or obras[0]["texto_sha256"] != _sha_texto(texto):
            raise ErroPreparacaoVolume19("Identidade da obra SQLite divergente")
        secoes, paginas = _jsonl(raiz / "secoes.jsonl"), _jsonl(raiz / "paginas.jsonl")
        rows_sec = [dict(r) for r in con.execute("SELECT * FROM secoes ORDER BY rowid")]
        rows_pag = [dict(r) for r in con.execute("SELECT * FROM paginas ORDER BY pagina_pdf")]
        if rows_sec != secoes or rows_pag != paginas or [p["pagina_pdf"] for p in paginas] != list(range(1, 245)):
            raise ErroPreparacaoVolume19("Seções/páginas SQLite divergem dos JSONLs")
        rows_b = list(con.execute("SELECT * FROM blocos ORDER BY rowid"))
        if len(rows_b) != len(blocos):
            raise ErroPreparacaoVolume19("Contagem SQLite de blocos divergente")
        for b, row in zip(blocos, rows_b):
            if any(b[k] != row[k] for k in ("id", "obra_id", "secao_id", "inicio", "fim", "texto", "sha256_texto")) or json.loads(row["paginas_json"]) != b["paginas"]:
                raise ErroPreparacaoVolume19("Bloco SQLite divergente")
        rows = list(con.execute("SELECT * FROM fragmentos ORDER BY rowid"))
        if len(rows) != len(refs):
            raise ErroPreparacaoVolume19("Contagem SQLite de fragmentos divergente")
        campos = ("id", "bloco_id", "obra_id", "secao_id", "ordem", "inicio", "fim", "anterior_id", "posterior_id", "cabecalho", "texto", "entrada_sha256")
        for f, row in zip(refs, rows):
            if any(f[k] != row[k] for k in campos) or f["tokens_entrada"] != row["tokens"]:
                raise ErroPreparacaoVolume19("Fragmento SQLite divergente")
        sql_fts = con.execute("SELECT sql FROM sqlite_master WHERE name='fragmentos_fts'").fetchone()[0]
        if "USING fts5" not in sql_fts or "unicode61 remove_diacritics 2" not in sql_fts:
            raise ErroPreparacaoVolume19("FTS5 exige a tokenização do contrato v1")
        fts = list(con.execute("SELECT fragmento_id,cabecalho,texto FROM fragmentos_fts ORDER BY rowid"))
        if len(fts) != len(refs) or any(tuple(r) != (f["id"], f["cabecalho"], f["texto"]) for f, r in zip(refs, fts)):
            raise ErroPreparacaoVolume19("Índice FTS diverge de referências")
    finally:
        con.close()
    relatorio_path = raiz / "geracao.json"
    if relatorio_path.exists():
        relatorio = _json(relatorio_path.read_text(encoding="utf-8"))
        estado = ("corpus_volume19_gerado_verificado_com_limites" if manifesto["embedding_real"]
                  else "corpus_sintetico_somente_testes")
        if relatorio.get("manifesto_sha256") != _sha_arquivo(raiz / "manifesto.json") or \
           relatorio.get("hashes_artefatos") != manifesto["arquivos"] or \
           relatorio.get("estado") != estado or relatorio.get("embedding_real") is not manifesto["embedding_real"]:
            raise ErroPreparacaoVolume19("Relatório da geração diverge do corpus/manifesto")
    return {"corpus_validado": True, "fragmentos": len(refs), "blocos": len(blocos),
            "paginas_pdf": 244, "paginas_no_corpo": 223, "secoes": len(secoes),
            "linhas_vetores_conferidas": len(refs), "cobertura_textual_integral": True,
            "arquivos_conferidos": len(nomes), "embedding_real": manifesto["embedding_real"],
            "conferencia_editorial_integral": False, "pronto_para_busca": False}


def _publicar_exclusivo(temporario: Path, destino: Path) -> None:
    """Publica arquivos exclusivos; manifesto vai por último. Nunca sobrescreve."""
    destino.mkdir()
    identidade = (destino.stat().st_dev, destino.stat().st_ino)
    criados = []
    try:
        arquivos = sorted(temporario.iterdir(), key=lambda p: p.name == "manifesto.json")
        for arquivo in arquivos:
            novo = destino / arquivo.name
            os.link(arquivo, novo)
            st = novo.stat()
            criados.append((novo, st.st_dev, st.st_ino, _sha_arquivo(arquivo)))
    except BaseException:
        if destino.is_dir() and (destino.stat().st_dev, destino.stat().st_ino) == identidade:
            for novo, dev, ino, sha in reversed(criados):
                try:
                    st = novo.lstat()
                    if (st.st_dev, st.st_ino) == (dev, ino) and _sha_arquivo(novo) == sha:
                        novo.unlink()
                except FileNotFoundError:
                    pass
            try:
                destino.rmdir()
            except OSError:
                pass  # Preserva qualquer arquivo criado por outro processo.
        raise


def preparar_volume19(fonte: str | Path, saida: str | Path, *, cache_modelos,
                      baixar_modelo=False, dispositivo="cpu", lote=4, encoder=None,
                      progresso: Callable[[str], None] | None = None) -> dict:
    """Gera e valida um corpus novo. Encoder injetável existe somente para testes.

    A CLI nunca oferece encoder alternativo. Artefatos de teste são marcados
    embedding_real=False, sem fingir execução E5. O callback recebe progresso
    sem textos ou vetores. Em falhas não se publica manifesto final.
    """
    _inteiro(lote, "lote", 1)
    if lote > 256:
        raise ErroPreparacaoVolume19("Lote máximo: 256")
    destino = Path(saida).expanduser()
    if destino.is_symlink() or destino.exists():
        raise ErroPreparacaoVolume19("Saída já existe; escolha uma pasta nova")
    destino = destino.absolute()
    if not destino.parent.is_dir() or destino.parent.is_symlink():
        raise ErroPreparacaoVolume19("A pasta pai da saída deve existir e não ser link")
    destino = destino.parent.resolve() / destino.name
    entrada = carregar_fonte(fonte)
    if destino.is_relative_to(entrada["raiz"]):
        raise ErroPreparacaoVolume19("Saída não pode ficar dentro da preparação original")
    informar = progresso or (lambda mensagem: None)
    informar("Fonte auditada conferida; carregando E5 da revisão fixa.")
    injetado = encoder is not None
    if encoder is None:
        encoder = EncoderE5(cache_modelos, baixar_modelo=baixar_modelo, dispositivo=dispositivo)
    descricao = dict(encoder.descricao)
    descricao["embedding_real"] = not injetado
    informar("Segmentando o TXT integral com orçamento de tokens, sem truncamento.")
    blocos, fragmentos = _planejar(entrada, encoder)
    informar(f"Planejados {len(blocos)} blocos e {len(fragmentos)} fragmentos.")
    temporario = Path(tempfile.mkdtemp(prefix=".volume19-geracao-", dir=destino.parent))
    try:
        _gravar_sqlite(temporario, entrada, blocos, fragmentos)
        _gravar_jsonl(temporario / "fragmentos.jsonl", fragmentos)
        _gravar_jsonl(temporario / "blocos.jsonl", blocos)
        con = sqlite3.connect(temporario / "corpus.sqlite")
        con.row_factory = sqlite3.Row
        try:
            _gravar_jsonl(temporario / "paginas.jsonl", [dict(p) for p in con.execute("SELECT * FROM paginas ORDER BY pagina_pdf")])
            _gravar_jsonl(temporario / "secoes.jsonl", [dict(s) for s in con.execute("SELECT * FROM secoes ORDER BY rowid")])
        finally:
            con.close()
        (temporario / "texto_volume19.txt").write_bytes(entrada["texto"].encode("utf-8"))
        matriz = np.lib.format.open_memmap(temporario / "vetores_e5.npy", mode="w+",
                                          dtype="<f4", shape=(len(fragmentos), 1024))
        proveniencia = []
        try:
            for inicio in range(0, len(fragmentos), lote):
                refs_lote = fragmentos[inicio:inicio + lote]
                entradas = ["passage: " + f["cabecalho"] + "\n" + f["texto"] for f in refs_lote]
                if any(_contar(encoder, e) != f["tokens_entrada"] for e, f in zip(entradas, refs_lote)):
                    raise ErroPreparacaoVolume19("Tokenização mudou entre planejamento e inferência")
                vetores = _normalizar(encoder.gerar(entradas), len(refs_lote))
                matriz[inicio:inicio + len(refs_lote)] = vetores
                for indice, (f, vetor) in enumerate(zip(refs_lote, vetores), inicio):
                    proveniencia.append({"linha": indice, "fragmento_id": f["id"],
                        "entrada_sha256": f["entrada_sha256"], "tokens_entrada": f["tokens_entrada"],
                        "vetor_sha256_float32_le": _sha_bytes(vetor.tobytes())})
                informar(f"Vetores gerados: {inicio + len(refs_lote)}/{len(fragmentos)}.")
            matriz.flush()
        finally:
            matriz._mmap.close()
        _gravar_jsonl(temporario / "entradas_vetorizacao.jsonl", proveniencia)
        hashes = {p.name: {"bytes": p.stat().st_size, "sha256": _sha_arquivo(p)}
                  for p in sorted(temporario.iterdir())}
        manifesto = {"schema": "camada_a_freud.v1", "modelo": MODELO, "revisao": REVISAO,
            "tokenizador": MODELO, "tokenizador_revisao": REVISAO, "dimensao": 1024,
            "tokens_maximo": 512, "margem_tokens": 8, "prefixo_passagens": "passage: ",
            "prefixo_consultas": "query: ", "pooling": "mean", "include_prompt": True,
            "tipo_vetor": "float32", "normalizacao": "L2", "obra_id": OBRA_ID,
            "sha256_pdf": SHA_PDF, "vetores_arquivo": "vetores_e5.npy",
            "referencias_arquivo": "fragmentos.jsonl", "fragmentos": len(fragmentos),
            "blocos": len(blocos), "paginas_pdf": 244, "intervalo_corpo_pdf": [10, 232],
            "embedding_real": not injetado, "encoder": descricao,
            "fonte_hashes": dict(HASHES_FONTE), "arquivos": hashes,
            "segmentacao": "pagina_com_separador_final; particao_unicode_contigua; tokens_entrada<=504",
            "cobertura_integral_exigida": True, "pronto_para_busca": False,
            "limites": ["Conferência editorial integral pendente.",
                "Seções atribuídas pelo sumário por página, sem localizar divisões dentro da página.",
                "Hash de linha documenta a geração; não é uma segunda inferência independente.",
                "Busca e rotas do aplicativo não são ativadas por esta ferramenta."],
        }
        _gravar_json(temporario / "manifesto.json", manifesto)
        validacao = validar_corpus_volume19(temporario)
        if {nome: _sha_arquivo(entrada["raiz"] / nome) for nome in HASHES_FONTE} != HASHES_FONTE:
            raise ErroPreparacaoVolume19("A preparação original mudou durante a geração")
        relatorio = {"estado": "corpus_volume19_gerado_verificado_com_limites" if not injetado else "corpus_sintetico_somente_testes",
            **validacao, "obra_id": OBRA_ID, "sha256_pdf": SHA_PDF,
            "texto_sha256": HASHES_FONTE["texto_volume19.txt"], "modelo": MODELO,
            "revisao": REVISAO, "pooling": "mean", "normalizacao": "L2",
            "encoder": descricao, "manifesto_sha256": _sha_arquivo(temporario / "manifesto.json"),
            "hashes_artefatos": hashes, "fonte_original_alterada": False,
            "busca_aplicativo_ativada": False, "saida": str(destino)}
        _gravar_json(temporario / "geracao.json", relatorio)
        _publicar_exclusivo(temporario, destino)
        informar(f"Corpus novo gerado e validado: {destino}")
        return relatorio
    finally:
        shutil.rmtree(temporario)


def _main():
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--fonte", required=True)
    parser.add_argument("--saida", required=True)
    parser.add_argument("--cache-modelos", required=True)
    parser.add_argument("--baixar-modelo", action="store_true", help="Autoriza download explícito da revisão E5 fixa.")
    parser.add_argument("--dispositivo", choices=("cpu", "cuda", "mps", "auto"), default="cpu")
    parser.add_argument("--lote", type=int, default=4)
    args = parser.parse_args()
    try:
        relatorio = preparar_volume19(args.fonte, args.saida, cache_modelos=args.cache_modelos,
            baixar_modelo=args.baixar_modelo, dispositivo=args.dispositivo, lote=args.lote,
            progresso=lambda mensagem: print(mensagem, flush=True))
    except (ErroPreparacaoVolume19, OSError, ValueError) as exc:
        parser.exit(1, f"Geração interrompida: {exc}\n")
    print("Estado:", relatorio["estado"])
    print("Relatório:", Path(args.saida) / "geracao.json")


if __name__ == "__main__":
    _main()
