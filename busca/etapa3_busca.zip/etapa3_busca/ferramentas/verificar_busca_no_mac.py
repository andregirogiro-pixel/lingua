#!/usr/bin/env python3
"""Conferência técnica da busca real da Camada A, sem inferência ou rede.

Os vetores usados nas consultas são linhas já existentes do corpus: servem
somente para exercitar exclusão, rankings, fusão e referências. Não são
embeddings de relatos nem uma avaliação de relevância clínica/editorial.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import importlib
import json
from pathlib import Path
import re
import sqlite3
import sys

sys.dont_write_bytecode = True
from verificar_leitura_base import VerificacaoLeitura, hash_arquivo, hash_texto, ler_objeto, OBRA_19_ANTIGA

RAIZ_PACOTE = Path(__file__).resolve().parents[1]
SHA_ETAPA1 = "c6e43bc1d4d7b83825d22f1b44607f3f693772336e72970620f44c272f5af496"
# Derivado verificável do relatório d6768f415e471aa9867c9326a897f59e8c80ec47882731ab533d38f926323d2c:
# somente os campos raiz 'projeto' e 'corpus' foram retirados para publicação.
SHA_ETAPA2 = "18ca4a6cde0ba470d0bb9fcb885958a2c49228031109a78f814faedb5fbc4ae6"
MODULOS = ("__init__", "camada_a", "busca_camada_a", "busca", "corpus", "entrada", "ligacoes", "importacao", "transporte", "preparar_volume19")
PDF_VOLUME19_SHA256 = "1b4ea213276f48f77b53349109c9d9a352ade2225de43aa50765225db5c0a3ba"
OBRA_VOLUME19_NOVA = "obra-1b4ea213276f48f7"


def importado_tecnico(manifesto, vetor, texto):
    """Envelope técnico rastreável; nunca descreve a linha como relato real."""
    primeiro = texto.strip() or "Conferência estrutural do corpus."
    segundo = "Segundo parágrafo sintético para conferir a recuperação local."
    original = primeiro + "\n\n" + segundo
    par = [{"id": "P1", "inicio": 0, "fim": len(primeiro), "texto": primeiro},
           {"id": "P2", "inicio": len(primeiro)+2, "fim": len(original), "texto": segundo}]
    consultas = []
    for p in par:
        consultas.append({"id": "tecnico-"+p["id"], "tipo": "paragrafo", "paragrafo_id": p["id"],
                          "unidade_id": None, "periodo_id": None, "artefato_id": "linha-corpo-"+p["id"],
                          "origem": {"campo": "teste_estrutural.linha_corpo", "original": {k: p[k] for k in ("inicio", "fim")}},
                          **{k: p[k] for k in ("inicio", "fim", "texto")},
                          "texto_vetorizado": p["texto"], "vetor": [float(x) for x in vetor]})
    consultas.append({"id": "tecnico-documento", "tipo": "documento", "paragrafo_id": None,
                      "unidade_id": None, "periodo_id": None, "artefato_id": "linha-corpo-documento",
                      "origem": {"campo": "teste_estrutural.linha_corpo"}, "inicio": 0, "fim": len(original),
                      "texto": original, "texto_vetorizado": original, "vetor": [float(x) for x in vetor]})
    modelo, revisao = manifesto["modelo"], manifesto["revisao"]
    tokenizador = manifesto.get("tokenizador", {"identificacao": modelo, "revisao": revisao})
    if isinstance(tokenizador, str):
        tokenizador = {"identificacao": tokenizador, "revisao": manifesto.get("tokenizador_revisao", revisao)}
    return {"relato": {"texto": original, "paragrafos": par, "palavras": len(original.split())},
            "consultas": consultas, "fonte": {
                "schema_version": "1.0.0", "execucao_id": "diagnostico-estrutural-sem-inferencia",
                "contexto_execucao_id": "contexto-tecnico", "documento_id": "documento-sintetico",
                "espaco_vetorial_id": "identificacao-tecnica-manifesto", "modelo": modelo, "revisao": revisao,
                "tokenizador": deepcopy(tokenizador), "dimensao": manifesto["dimensao"],
                "pooling": manifesto.get("pooling", "mean"), "normalizacao": "l2", "prefixo": "query: ",
                "formato_vetor": "float32", "perfil": "e5_analista",
                "estrategia_consultas": "paragrafos_documento", "agregacao": "nenhuma",
                "vetor_origem": "linha_corpo_para_teste_estrutural"}}


def verificar_resultado(resultado, corpus, check):
    """Inspecione todos os canais que poderiam transportar uma fonte bloqueada."""
    blocos_bloqueados = {bid for bid, b in corpus.blocos.items()
                        if b.get("bloqueada_para_busca") or b.get("obra_id") == OBRA_19_ANTIGA
                        or b.get("referencia", {}).get("obra_id") == OBRA_19_ANTIGA}
    fragmentos_bloqueados = {f["id"] for f in corpus.fragmentos
                            if f.get("bloqueada_para_busca") or f.get("obra_id") == OBRA_19_ANTIGA}
    candidatos = resultado.get("candidatos", [])
    ids = [b["bloco_id"] for b in candidatos]
    if len(ids) != len(set(ids)) or not ids:
        check.falhar("candidatos_vazios_ou_duplicados")
    for candidato in candidatos:
        bid = candidato["bloco_id"]
        if bid not in corpus.blocos or bid in blocos_bloqueados:
            check.falhar("bloco_bloqueado_ou_desconhecido_em_candidatos", bid)
        original = corpus.blocos.get(bid, {})
        for k in ("texto", "referencia", "fragmentos", "fragmentos_ids"):
            if candidato.get(k) != original.get(k):
                check.falhar("fonte_literal_ou_referencia_modificada", bid)
        for fid in candidato.get("fragmentos_ids", []) + candidato.get("fragmentos_recuperados_ids", []):
            if fid not in corpus.por_id or fid in fragmentos_bloqueados:
                check.falhar("fragmento_bloqueado_ou_desconhecido_em_candidatos", fid)
        for p in candidato.get("pontuacoes", []):
            if p["fragmento_id"] in fragmentos_bloqueados or p["fragmento_id"] not in corpus.por_id:
                check.falhar("fragmento_bloqueado_ou_desconhecido_em_pontuacoes", p["fragmento_id"])
            elif corpus.por_id[p["fragmento_id"]]["bloco_id"] != bid:
                check.falhar("pontuacao_de_outro_bloco", p["fragmento_id"])
    for ranking in resultado.get("ranking_fundido", []):
        if ranking["bloco_id"] in blocos_bloqueados or ranking["bloco_id"] not in corpus.blocos:
            check.falhar("bloco_bloqueado_ou_desconhecido_em_ranking", ranking["bloco_id"])
    for ancora in resultado.get("ancoras", []):
        for b in ancora["blocos"]:
            if b["bloco_id"] in blocos_bloqueados or b["bloco_id"] not in set(ids):
                check.falhar("bloco_bloqueado_ou_ausente_em_ancoras", b["bloco_id"])


class VerificarBusca(VerificacaoLeitura):
    def __init__(self, projeto, corpus, baseline, volume19=None, *, evidencia=None):
        super().__init__(corpus, baseline)
        self.projeto = projeto.resolve()
        self.volume19 = volume19.resolve() if volume19 else None
        self.evidencia = evidencia or RAIZ_PACOTE / "dados/ADAPTADOR_ETAPA2_MAC.json"
        self.hashes_projeto, self.hashes_novo = {}, {}
        self.relatorio.update(schema_relatorio="verificacao_busca_camada_a.v1", etapa=3,
                              escopo="busca real opcional; conferência estrutural com linhas existentes",
                              projeto=str(self.projeto), volume19=str(self.volume19) if self.volume19 else None,
                              backend_ativado_no_aplicativo=False, inferencia_local=False, rede_utilizada=False,
                              chamadas_api_executadas=False, vetor_origem="linha_corpo_para_teste_estrutural")
        self.relatorio["limites"] = [
            "Consultas técnicas usam linhas passage: existentes; não são embeddings query: de relatos reais.",
            "Esta execução confere exclusão, rankings, RRF e citações; não mede pertinência ou qualidade semântica.",
            "Preservar o NPY auditado não prova a correspondência histórica de cada embedding com seu texto.",
            "Fonte antiga do volume 19 continua arquivada e deve ser excluída antes de qualquer top-k.",
            "O aplicativo, suas rotas e o provedor não são iniciados por esta ferramenta.",
            "Sem o pacote vetorizado do novo volume 19, valida-se a busca das outras fontes somente.",
            "Páginas são do PDF; conferência editorial e paginação impressa permanecem separadas."]

    def carregar_baseline(self):
        if not super().carregar_baseline():
            return False
        c = self.checar("continuidade_etapas1_2_concluidas")
        if self.relatorio["auditoria_etapa1_sha256"] != SHA_ETAPA1:
            c.falhar("baseline_etapa1_diferente_do_concluido")
        try:
            dados = self.evidencia.read_bytes()
            self.relatorio["adaptador_etapa2_sha256"] = hashlib.sha256(dados).hexdigest()
            if self.relatorio["adaptador_etapa2_sha256"] != SHA_ETAPA2:
                c.falhar("evidencia_etapa2_diferente_da_conferida")
            r = ler_objeto(dados.decode("utf-8"))
            checks = r["verificacoes"]
            if (r["estado"] != "adaptador_real_leitura_verificado_com_limites" or r["etapa"] != 2
                    or r["auditoria_etapa1_sha256"] != SHA_ETAPA1 or len(checks) != 11
                    or len({x["nome"] for x in checks}) != 11
                    or any(x["estado"] != "passou" or x["falhas"] != {} for x in checks)):
                c.falhar("etapa2_nao_concluida_com_onze_verificacoes")
            entradas = r["baseline_e_hashes_da_leitura"]
            por_nome = {x["arquivo"]: x for x in entradas}
            if len(por_nome) != len(entradas) or set(por_nome) != set(self.baseline):
                c.falhar("evidencia_etapa2_arquivos_divergentes")
            else:
                for nome, item in por_nome.items():
                    if (item["bytes"] != self.baseline[nome]["bytes"] or item["conteudo_inalterado"] is not True
                            or any(item[k] != self.baseline[nome]["sha256"] for k in ("sha256_baseline", "sha256_antes", "sha256_depois"))):
                        c.falhar("evidencia_etapa2_hash_divergente", nome)
            self.hashes_estaveis_etapa2 = {x["arquivo"]: x["sha256_depois"] for x in r["hashes_modulos_projeto"]}
            c.dados.update(verificacoes_etapa2=11, arquivos_baseline=len(self.baseline))
        except (OSError, ValueError, UnicodeError, KeyError, TypeError) as exc:
            c.falhar("evidencia_etapa2_ilegivel_" + type(exc).__name__)
        return not c.falhas

    def conferir_projeto(self, depois=False):
        c = self.checar("modulos_projeto_apos_busca" if depois else "modulos_projeto_antes_importacao")
        registros = []
        for nome in MODULOS:
            relativo = "agente_analista/"+nome+".py"
            arquivo = (self.projeto / relativo).resolve()
            if not arquivo.is_relative_to(self.projeto) or not arquivo.is_file():
                c.falhar("modulo_ausente_ou_externo", relativo)
                continue
            sha = hash_arquivo(arquivo)
            if depois:
                if self.hashes_projeto.get(relativo) != sha:
                    c.falhar("modulo_alterado_durante_busca", relativo)
            else:
                self.hashes_projeto[relativo] = sha
                if relativo in getattr(self, "hashes_estaveis_etapa2", {}) and self.hashes_estaveis_etapa2[relativo] != sha:
                    c.falhar("modulo_estavel_diverge_da_etapa2", relativo)
            registros.append({"arquivo": relativo, "sha256_antes": self.hashes_projeto.get(relativo),
                              **({"sha256_depois": sha, "conteudo_inalterado": self.hashes_projeto.get(relativo) == sha} if depois else {})})
        if depois:
            self.relatorio["hashes_modulos_projeto"] = registros
        return not c.falhas

    def conferir_novo(self, depois=False):
        if not self.volume19:
            return True
        c = self.checar("volume19_artefatos_apos_busca" if depois else "volume19_artefatos_antes_busca")
        try:
            nomes = sorted(str(p.relative_to(self.volume19)) for p in self.volume19.rglob("*") if p.is_file())
            if depois and set(nomes) != set(self.hashes_novo):
                c.falhar("volume19_arquivos_adicionados_ou_removidos")
            registros = []
            for nome in nomes:
                p = (self.volume19 / nome).resolve()
                if not p.is_relative_to(self.volume19):
                    c.falhar("volume19_arquivo_externo", nome)
                    continue
                sha = hash_arquivo(p)
                if depois and self.hashes_novo.get(nome) != sha:
                    c.falhar("volume19_artefato_alterado", nome)
                if not depois:
                    self.hashes_novo[nome] = sha
                registros.append({"arquivo": nome, "bytes": p.stat().st_size, "sha256_antes": self.hashes_novo.get(nome),
                                  **({"sha256_depois": sha, "conteudo_inalterado": self.hashes_novo.get(nome) == sha} if depois else {})})
            c.dados["arquivos_conferidos"] = len(registros)
            if depois:
                self.relatorio["hashes_volume19"] = registros
        except OSError as exc:
            c.falhar("volume19_ilegivel_"+type(exc).__name__)
        return not c.falhas

    def ler_componente(self):
        if not self.conferir_projeto() or not self.conferir_novo():
            return
        sys.path.insert(0, str(self.projeto))
        origens = self.checar("origens_dos_modulos_reais")
        modulos = {}
        for nome in MODULOS:
            completo = "agente_analista" if nome == "__init__" else "agente_analista."+nome
            m = importlib.import_module(completo)
            if Path(m.__file__).resolve() != (self.projeto / "agente_analista" / (nome+".py")).resolve():
                origens.falhar("modulo_importado_de_outro_projeto", completo)
            modulos[nome] = m
        if origens.falhas:
            return
        import numpy as np
        modulo = modulos["busca_camada_a"]
        if self.volume19:
            check_novo = self.checar("volume19_manifesto_geracao_e_integridade_validados")
            modulos["preparar_volume19"].validar_corpus_volume19(self.volume19)
            m_novo = ler_objeto((self.volume19 / "manifesto.json").read_text(encoding="utf-8"))
            if m_novo.get("embedding_real") is not True:
                check_novo.falhar("volume19_encoder_sintetico_nao_e_entrega_e5_real")
                return
            check_novo.dados.update(validador_real_sem_inferencia=True, manifesto_sha256=hash_arquivo(self.volume19 / "manifesto.json"))
        corpus = modulo.abrir_camada_a_composta(self.raiz, volume19=self.volume19)
        buscador = None
        try:
            fontes = corpus.fontes
            c = self.checar("fontes_indices_e_matrizes_originais_somente_leitura")
            elegiveis = set(int(i) for i in corpus.indices_elegiveis)
            esperados = {i for i, f in enumerate(corpus.fragmentos)
                         if f["obra_id"] != OBRA_19_ANTIGA and not f.get("bloqueada_para_busca")}
            if elegiveis != esperados or corpus.indices_elegiveis.flags.writeable:
                c.falhar("indices_elegiveis_divergentes_ou_mutaveis")
            if len(fontes) != (2 if self.volume19 else 1) or len(corpus.vetores_por_fonte) != len(fontes):
                c.falhar("fontes_ou_matrizes_ausentes")
            total, linha_por_id = 0, {}
            for fonte, matriz in zip(fontes, corpus.vetores_por_fonte):
                if matriz is not fonte.vetores or not isinstance(matriz, np.memmap) or matriz.mode != "r" or matriz.flags.writeable:
                    c.falhar("matriz_nao_e_original_mmap_readonly")
                for i, f in enumerate(fonte.fragmentos):
                    if f["id"] in linha_por_id or corpus.indice_por_id.get(f["id"]) != total+i:
                        c.falhar("id_colidido_ou_indice_alterado", f["id"])
                    linha_por_id[f["id"]] = (fonte, i, total+i)
                total += len(fonte.fragmentos)
            if self.volume19:
                novos = fontes[1].fragmentos
                if {f["obra_id"] for f in novos} != {OBRA_VOLUME19_NOVA}:
                    c.falhar("volume19_fonte_nao_e_pdf_corrigido")
                if any(b["referencia"]["sha256_pdf"] != PDF_VOLUME19_SHA256 for b in fontes[1].blocos.values()):
                    c.falhar("volume19_sha_pdf_divergente")
            if len(corpus.fragmentos) != total or [f["id"] for f in corpus.fragmentos[:len(fontes[0].fragmentos)]] != [f["id"] for f in self.registros["fragmentos"]]:
                c.falhar("linhas_base_alteradas_ou_copia_composta_divergente")
            c.dados.update(fontes=len(fontes), fragmentos_total=total, fragmentos_elegiveis=len(elegiveis),
                           fragmentos_bloqueados=total-len(elegiveis), matriz_concatenada_criada=False)
            fts = self.checar("sqlite_fts5_somente_leitura")
            for fonte in fontes:
                db = fonte._leitor._con
                if db.execute("PRAGMA query_only").fetchone()[0] != 1:
                    fts.falhar("conexao_nao_e_query_only")
                schema = db.execute("SELECT sql FROM sqlite_master WHERE name='fragmentos_fts'").fetchone()
                if not schema or not re.search(r"\bfts5\b", schema[0], re.I):
                    fts.falhar("indice_fts5_ausente")
            fts.dados["fontes_sqlite_conferidas"] = len(fontes)
            buscador = modulo.BuscadorCamadaA(corpus)
            self.relatorio.update(buscas_executadas=True, buscador_instanciado=True, diagnostico=corpus.diagnostico())
            rankings_check = self.checar("rankings_topk_filtrados_antes_rrf")
            resultado_check = self.checar("candidatos_rrf_ancoras_e_pontuacoes_sem_fonte_antiga")
            citacoes_check = self.checar("citacoes_literais_dos_resultados_reais")
            por_obra = {}
            for f in corpus.fragmentos:
                por_obra.setdefault(f["obra_id"], f)
            resumos, citacoes, cobertura = [], [], set()
            for oid, f in sorted(por_obra.items()):
                fonte, indice, global_idx = linha_por_id[f["id"]]
                vetor = fonte.vetores[indice]
                # Pequeno recorte lexical determinístico; não entra no relatório.
                lexical = " ".join(re.findall(r"[^\W\d_]+", f["texto"], re.UNICODE)[:16]) or "memória sonho"
                importado = importado_tecnico(corpus.manifesto, vetor, lexical)
                consulta = importado["consultas"][0]
                rankings = buscador._rankings(consulta, vetor)
                if {metodo for metodo, _ in rankings} != {"BM25", "E5"}:
                    rankings_check.falhar("metodos_de_ranking_ausentes", oid)
                for metodo, itens in rankings:
                    indices = [int(i) for i, _ in itens]
                    if len(indices) > buscador.TOP_METODO or len(indices) != len(set(indices)) or any(i not in elegiveis for i in indices):
                        rankings_check.falhar("ranking_com_fonte_bloqueada_duplicada_ou_topk_incorreto", oid)
                    if metodo == "E5":
                        if len(indices) != min(buscador.TOP_METODO, len(elegiveis)):
                            rankings_check.falhar("topk_semantico_incompleto_apos_exclusao", oid)
                        for i, score in itens:
                            origem, linha, _ = linha_por_id[corpus.fragmentos[int(i)]["id"]]
                            if not np.isclose(score, float(origem.vetores[linha] @ vetor), atol=2e-5, rtol=0):
                                rankings_check.falhar("score_semantico_nao_corresponde_ao_vetor_original", oid)
                resultado = buscador.buscar(importado)
                verificar_resultado(resultado, corpus, resultado_check)
                paragrafos, blocos = modulos["ligacoes"]._fontes(importado["relato"], resultado)
                for b in resultado["candidatos"][:2]:
                    texto = b["texto"]
                    if not texto.strip():
                        continue
                    inicio = next(i for i, char in enumerate(texto) if not char.isspace())
                    fim = min(len(texto), inicio+64)
                    cobrem = [item["id"] for item in b["fragmentos"] if item["inicio"] < fim and item["fim"] > inicio]
                    proposta = {"paragrafo": "P1", "bloco_id": b["bloco_id"],
                                "relato": {k: importado["relato"]["paragrafos"][0][k] for k in ("inicio", "fim", "texto")},
                                "freud": {"inicio": inicio, "fim": fim, "texto": texto[inicio:fim]}, "fragmentos_ids": cobrem,
                                "situacao": "parcial", "observacao": "Conferência técnica local.", "conceito": "",
                                "ligacao": "Teste estrutural sem interpretação.", "justificativa": "Offsets e cobertura literal.",
                                "limites": "Sem avaliação de pertinência.", "alternativas": []}
                    validada, motivo = modulos["ligacoes"]._validar_ligacao(proposta, importado["relato"], paragrafos, blocos)
                    if validada is None or motivo is not None or validada["referencia"] != b["referencia"]:
                        citacoes_check.falhar("citacao_ou_referencia_rejeitada", b["bloco_id"])
                    citacoes.append({"bloco_id": b["bloco_id"], "fragmentos_ids": cobrem, "inicio_local": inicio,
                                     "fim_local": fim, "sha256_citacao": hash_texto(texto[inicio:fim]),
                                     "literal_validada": validada is not None and motivo is None})
                obras_resultado = {b["referencia"]["obra_id"] for b in resultado["candidatos"]}
                cobertura.update(obras_resultado)
                resumos.append({"obra_id_linha_teste": oid, "fragmento_id_linha_teste": f["id"], "indice_global": global_idx,
                                "vetor_origem": "linha_corpo_para_teste_estrutural", "tentativa_fonte_antiga": oid == OBRA_19_ANTIGA,
                                "consulta_lexical_sha256": hash_texto(lexical), "consultas": len(importado["consultas"]),
                                "rankings": [{"metodo": m, "fragmentos": len(itens)} for m, itens in rankings],
                                "candidatos": len(resultado["candidatos"]), "ranking_fundido": len(resultado["ranking_fundido"]),
                                "ancoras": len(resultado["ancoras"]), "obras_nos_candidatos": sorted(obras_resultado)})
            incompatibilidade = self.checar("contrato_vetorial_incompativel_rejeitado")
            adulterado = deepcopy(importado)
            adulterado["fonte"]["revisao"] = "0"*40
            try:
                buscador.buscar(adulterado)
            except modulos["busca"].ErroBusca:
                incompatibilidade.dados["revisao_divergente_rejeitada"] = True
            else:
                incompatibilidade.falhar("revisao_incompativel_aceita")
            rankings_check.dados.update(linhas_tecnicas_testadas=len(resumos), fontes_testadas=len(por_obra),
                                       tentativa_vetor_da_fonte_antiga=OBRA_19_ANTIGA in por_obra)
            citacoes_check.dados["citacoes_conferidas"] = len(citacoes)
            self.relatorio.update(amostras_buscas=resumos, amostras_citacoes=citacoes,
                                  obras_observadas_em_resultados=sorted(cobertura))
        finally:
            fechamento = self.checar("fechamento_deterministico_buscador_e_fontes")
            if buscador:
                buscador.close()
                buscador.close()
                try:
                    buscador._rankings({"texto": "memória"}, [0.0]*corpus.manifesto["dimensao"])
                except (ValueError, RuntimeError, sqlite3.Error):
                    fechamento.dados["busca_apos_close_rejeitada"] = True
                else:
                    fechamento.falhar("busca_apos_close_aceita")
            corpus.close()
            corpus.close()
            if any(fonte._leitor._con is not None for fonte in fontes):
                fechamento.falhar("conexao_sqlite_permaneceu_aberta")
            self.conferir_novo(depois=True)
            self.conferir_projeto(depois=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for nome in ("projeto", "corpus", "baseline", "saida"):
        parser.add_argument("--"+nome, type=Path, required=True)
    parser.add_argument("--volume19", type=Path)
    a = parser.parse_args(argv)
    projeto, corpus, baseline, saida = (p.expanduser().resolve() for p in (a.projeto, a.corpus, a.baseline, a.saida))
    volume19 = a.volume19.expanduser().resolve() if a.volume19 else None
    if not projeto.is_dir() or not corpus.is_dir() or not baseline.is_file() or (volume19 and not volume19.is_dir()):
        parser.error("Projeto, corpus, baseline e volume19 opcional devem existir.")
    proibidos = [projeto, corpus]+([volume19] if volume19 else [])
    if saida.exists() or a.saida.expanduser().is_symlink() or any(saida.is_relative_to(p) for p in proibidos) or not saida.parent.is_dir():
        parser.error("Escolha uma saída nova fora do projeto e dos corpora, em diretório existente.")
    r = VerificarBusca(projeto, corpus, baseline, volume19).executar()
    if r["estado"] != "falhou":
        r["estado"] = "busca_real_verificada_com_limites"
    try:
        with saida.open("x", encoding="utf-8") as arquivo:
            json.dump(r, arquivo, ensure_ascii=False, indent=2, allow_nan=False)
            arquivo.write("\n")
    except FileExistsError:
        parser.error("A saída já existe; nenhum relatório foi sobrescrito.")
    print("Busca real:", r["estado"])
    print("Relatório:", saida)
    print("Consultas técnicas sem inferência ou rede; não certificam pertinência semântica.")
    return 1 if r["estado"] == "falhou" else 0


if __name__ == "__main__":
    sys.exit(main())
