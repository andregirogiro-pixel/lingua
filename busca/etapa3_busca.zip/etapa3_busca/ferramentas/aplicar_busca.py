"""Aplica a etapa 3 após conferir a versão, com backup e rollback local."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import tempfile

PACOTE = Path(__file__).resolve().parents[1]


def digest(caminho):
    return hashlib.sha256(caminho.read_bytes()).hexdigest()


def dentro(raiz, relativo):
    rel = Path(relativo)
    if rel.is_absolute() or ".." in rel.parts or not rel.parts:
        raise ValueError("Caminho inválido no manifesto de instalação.")
    caminho = raiz / rel
    if caminho.is_symlink() or not caminho.resolve().is_relative_to(raiz):
        raise ValueError("Um caminho contém symlink ou sai da pasta selecionada.")
    return caminho


def _arquivo_atomico(destino, conteudo, *, exclusivo, modo=0o644):
    temporario = None
    try:
        with tempfile.NamedTemporaryFile(dir=destino.parent, prefix=".etapa3_", delete=False) as f:
            temporario = Path(f.name)
            f.write(conteudo)
            f.flush()
            os.fsync(f.fileno())
        temporario.chmod(modo)
        if exclusivo:
            os.link(temporario, destino)
        else:
            os.replace(temporario, destino)
    finally:
        if temporario is not None:
            temporario.unlink(missing_ok=True)


def instalar(projeto, registro, backup, *, pacote=PACOTE):
    projeto = projeto.expanduser().resolve()
    pacote = pacote.expanduser().resolve()
    if registro.expanduser().is_symlink() or backup.expanduser().is_symlink():
        raise ValueError("Registro e backup não podem ser symlinks.")
    registro, backup = registro.expanduser().resolve(), backup.expanduser().resolve()
    if not projeto.is_dir() or not registro.parent.is_dir() or not backup.parent.is_dir():
        raise ValueError("Projeto e diretórios de saída devem existir.")
    if (registro.exists() or backup.exists() or registro.is_relative_to(projeto)
            or backup.is_relative_to(projeto) or registro == backup
            or registro.is_relative_to(backup) or backup.is_relative_to(registro)):
        raise ValueError("Escolha registro e backup novos, separados e fora do projeto.")
    manifesto = json.loads((pacote / "INSTALACAO.json").read_text(encoding="utf-8"))
    for nome, esperado in manifesto["base"].items():
        destino = dentro(projeto, nome)
        if not destino.is_file() or digest(destino) != esperado:
            raise ValueError(f"{nome} difere da versão revisada; nada foi instalado.")
    operacoes, iguais = [], []
    for categoria in ("substituir", "novos"):
        for nome, item in manifesto[categoria].items():
            antes = item["antes"] if categoria == "substituir" else None
            depois = item["depois"] if categoria == "substituir" else item
            origem, destino = dentro(pacote / "arquivos", nome), dentro(projeto, nome)
            if not origem.is_file() or digest(origem) != depois:
                raise ValueError(f"Conteúdo do pacote inconsistente: {nome}.")
            if not destino.parent.is_dir():
                raise ValueError(f"Diretório de destino ausente para {nome}.")
            if destino.exists():
                if not destino.is_file():
                    raise ValueError(f"Destino não é arquivo: {nome}.")
                atual = digest(destino)
                if atual == depois:
                    iguais.append(nome)
                    continue
                if antes is None or atual != antes:
                    raise ValueError(f"{nome} foi alterado localmente; não será sobrescrito.")
            elif antes is not None:
                raise ValueError(f"Arquivo original ausente: {nome}.")
            operacoes.append((nome, origem, destino, antes, depois))
    aplicados, originais = [], {}
    recibo = None
    recibo_identidade = None
    try:
        recibo = registro.open("x", encoding="utf-8")
        s = os.fstat(recibo.fileno())
        recibo_identidade = (s.st_dev, s.st_ino)
        backup.mkdir()
        for nome, _, destino, antes, _ in operacoes:
            if antes is not None:
                conteudo = destino.read_bytes()
                if hashlib.sha256(conteudo).hexdigest() != antes:
                    raise ValueError(f"{nome} mudou durante a conferência.")
                modo = stat.S_IMODE(destino.stat().st_mode)
                originais[nome] = (conteudo, modo)
                copia = dentro(backup, nome)
                copia.parent.mkdir(parents=True, exist_ok=True)
                _arquivo_atomico(copia, conteudo, exclusivo=True, modo=modo)
        for nome, origem, destino, antes, depois in operacoes:
            conteudo = origem.read_bytes()
            if hashlib.sha256(conteudo).hexdigest() != depois:
                raise ValueError(f"{nome} mudou no pacote.")
            if antes is not None and (not destino.is_file() or digest(destino) != antes):
                raise ValueError(f"{nome} mudou antes da aplicação.")
            modo = originais[nome][1] if antes is not None else 0o644
            _arquivo_atomico(destino, conteudo, exclusivo=antes is None, modo=modo)
            aplicados.append((nome, destino, antes, depois))
            if digest(destino) != depois:
                raise ValueError(f"Cópia inconsistente: {nome}.")
        resultado = {
            "etapa": 3, "estado": "busca_opcional_instalada",
            "criado_em_utc": datetime.now(timezone.utc).isoformat(),
            "projeto": str(projeto), "backup": str(backup),
            "substituidos": [{"arquivo": n, "sha256_antes": a, "sha256_depois": d}
                             for n, _, a, d in aplicados if a is not None],
            "adicionados": [{"arquivo": n, "sha256": d}
                            for n, _, a, d in aplicados if a is None],
            "ja_presentes_iguais": iguais,
            "backend_ativado": False, "modelos_baixados": False,
            "corpus_ou_banco_alterados": False,
        }
        json.dump(resultado, recibo, ensure_ascii=False, indent=2, allow_nan=False)
        recibo.write("\n")
        recibo.flush()
        return resultado
    except BaseException:
        problemas_rollback = []
        for nome, destino, antes, depois in reversed(aplicados):
            try:
                if not destino.is_file() or digest(destino) != depois:
                    problemas_rollback.append(nome)
                    continue
                if antes is None:
                    destino.unlink()
                else:
                    conteudo, modo = originais[nome]
                    _arquivo_atomico(destino, conteudo, exclusivo=False, modo=modo)
            except OSError:
                problemas_rollback.append(nome)
        if problemas_rollback:
            print("Restaurar manualmente do backup; arquivos modificados durante a instalação: "
                  + ", ".join(problemas_rollback), file=sys.stderr)
        if recibo is not None:
            recibo.close()
            recibo = None
        if recibo_identidade is not None and registro.is_file():
            s = registro.stat()
            if (s.st_dev, s.st_ino) == recibo_identidade:
                registro.unlink()
        raise
    finally:
        if recibo is not None:
            recibo.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--projeto", required=True, type=Path)
    parser.add_argument("--registro", required=True, type=Path)
    parser.add_argument("--backup", required=True, type=Path)
    args = parser.parse_args()
    try:
        r = instalar(args.projeto, args.registro, args.backup)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(f"Instalação não concluída: {exc}", file=sys.stderr)
        return 2
    print("Arquivos substituídos com backup:", len(r["substituidos"]))
    print("Arquivos novos adicionados:", len(r["adicionados"]))
    print("Registro:", args.registro.expanduser().resolve())
    print("Backup:", args.backup.expanduser().resolve())
    print("Busca opcional instalada; nenhuma variável ou servidor foi ativado.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
