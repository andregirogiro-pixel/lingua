#!/usr/bin/env python3
"""Valida a leitura da Camada A contra o baseline concluído da etapa 1.

Usa o leitor independente, sem acoplamento ao aplicativo, consultas ou modelos.
Só grava um relatório novo fora do corpus; não inclui texto nem vetores.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import sys

RAIZ_PACOTE = Path(__file__).resolve().parents[1]
if str(RAIZ_PACOTE) not in sys.path:
    sys.path.insert(0, str(RAIZ_PACOTE))

OBRA_19_ANTIGA = "obra-3b8627dba63512a2"
TIPOS = ("obras", "secoes", "paginas", "blocos", "fragmentos")
OBRIGATORIOS = {n + ".jsonl" for n in TIPOS} | {
    "manifesto.json", "corpus.sqlite", "vetores_e5.npy", "relatorio_qualidade.json"}
CHECAGENS_ETAPA1 = {"manifesto_e_arquivos", *("jsonl_" + n for n in TIPOS),
                   "contagens_e_volumes", "textos_offsets_hashes_e_relacoes", "vizinhanca_e_ordem_fragmentos",
                   "sqlite_somente_leitura_e_fts", "vetores_numpy_memmap", "hashes_baseline_atual"}
SHA = re.compile(r"^[0-9a-f]{64}$")


def hash_arquivo(path):
    h = hashlib.sha256()
    with path.open("rb") as entrada:
        for parte in iter(lambda: entrada.read(8 * 1024 * 1024), b""):
            h.update(parte)
    return h.hexdigest()


def hash_texto(texto):
    return hashlib.sha256(texto.encode("utf-8")).hexdigest()


class DadosInvalidos(ValueError):
    pass


def sem_duplicatas(pares):
    dados = {}
    for chave, valor in pares:
        if chave in dados:
            raise DadosInvalidos("chave_json_duplicada")
        dados[chave] = valor
    return dados


def ler_objeto(texto):
    def constante_invalida(_):
        raise DadosInvalidos("numero_json_invalido")
    dados = json.loads(texto, object_pairs_hook=sem_duplicatas, parse_constant=constante_invalida)
    if not isinstance(dados, dict):
        raise DadosInvalidos("objeto_json_esperado")
    return dados


class Checagem:
    def __init__(self, nome):
        self.nome = nome
        self.falhas = Counter()
        self.amostras = defaultdict(list)
        self.dados = {}

    def falhar(self, codigo, ident=None):
        self.falhas[codigo] += 1
        if ident is not None and len(self.amostras[codigo]) < 8:
            self.amostras[codigo].append(str(ident).replace("\n", " ").replace("\r", " ")[:160])

    def relatorio(self):
        return {"nome": self.nome, "estado": "falhou" if self.falhas else "passou",
                "falhas": dict(self.falhas), "amostra_ids": dict(self.amostras), "dados": self.dados}


class VerificacaoLeitura:
    def __init__(self, raiz, auditoria_path):
        self.raiz = raiz.resolve()
        self.auditoria_path = auditoria_path.resolve()
        self.checagens = []
        self.baseline = {}
        self.hashes_antes = {}
        self.caminhos = {}
        self.contagens_esperadas = {}
        self.relatorio = {
            "schema_relatorio": "verificacao_leitura_camada_a.v1", "etapa": 2,
            "escopo": "leitor independente; IDs, fontes, blocos e contexto raio 1",
            "iniciado_em_utc": datetime.now(timezone.utc).isoformat(),
            "corpus": str(self.raiz), "aplicativo_integrado": False,
            "buscas_executadas": False, "modelos_carregados": False,
            "texto_ou_vetores_incluidos": False,
            "limites": [
                "Esta execução não integra o leitor ao aplicativo e não mede a qualidade das buscas.",
                "Hashes conferem a continuidade com a etapa 1, não autenticam a origem histórica dos embeddings.",
                "A correspondência semântica entre cada vetor e fragmento permanece não comprovada.",
                "A fonte antiga do volume 19 permanece bloqueada nas buscas; sua leitura de auditoria é permitida.",
                "Páginas derivadas indicam páginas PDF, não numeração impressa nem conferência editorial.",
                "O contexto é conferido por amostragem determinística, incluindo limites de obras e blocos.",
            ],
        }

    def checar(self, nome):
        c = Checagem(nome)
        self.checagens.append(c)
        return c

    def validar_caminho(self, relativo, c):
        if not isinstance(relativo, str) or not relativo or Path(relativo).is_absolute() or ".." in Path(relativo).parts:
            c.falhar("caminho_baseline_invalido")
            return None
        caminho = (self.raiz / relativo).resolve()
        if not caminho.is_relative_to(self.raiz):
            c.falhar("caminho_sai_do_corpus")
            return None
        if not caminho.is_file():
            c.falhar("arquivo_ausente", relativo)
            return None
        return caminho

    def carregar_baseline(self):
        c = self.checar("baseline_etapa1_concluido")
        try:
            auditoria_bytes = self.auditoria_path.read_bytes()
            documento = ler_objeto(auditoria_bytes.decode("utf-8"))
            self.relatorio["auditoria_etapa1_sha256"] = hashlib.sha256(auditoria_bytes).hexdigest()
        except (OSError, ValueError, UnicodeError) as exc:
            c.falhar("auditoria_ilegivel_" + type(exc).__name__)
            return False
        resumo = documento.get("etapa") == 1 and documento.get("situacao") == "concluida_com_limites_documentados"
        original = (documento.get("etapa") == "validacao_estrutural"
                    and documento.get("estado") == "concluida_com_limites")
        if not (resumo or original):
            c.falhar("etapa1_nao_concluida")
        verificacoes = documento.get("verificacoes")
        if not isinstance(verificacoes, list) or not verificacoes:
            c.falhar("verificacoes_etapa1_ausentes")
            return False
        try:
            por_nome = {v["nome"]: v for v in verificacoes}
            if len(por_nome) != len(verificacoes) or any(v.get("estado") != "passou" or v.get("falhas") != {} for v in verificacoes):
                c.falhar("verificacao_etapa1_falhou_ou_duplicada")
            if not CHECAGENS_ETAPA1.issubset(por_nome):
                c.falhar("verificacoes_obrigatorias_etapa1_ausentes")
            contagens = documento.get("contagens_confirmadas") if resumo else por_nome["contagens_e_volumes"]["dados"]["contagens"]
            declarado = por_nome["hashes_baseline_atual"]["dados"]["arquivos_conferidos"]
            if not isinstance(contagens, dict) or any(type(contagens.get(n)) is not int or contagens[n] <= 0 for n in TIPOS):
                raise DadosInvalidos("contagens_invalidas")
            self.contagens_esperadas = {n: contagens[n] for n in TIPOS}
        except (KeyError, TypeError, ValueError):
            c.falhar("metadados_baseline_incompletos")
            return False
        entradas = documento.get("arquivos_hashes_antes_depois" if resumo else "baseline_arquivos_atual")
        if not isinstance(entradas, list) or type(declarado) is not int or len(entradas) != declarado:
            c.falhar("quantidade_arquivos_baseline_divergente")
            return False
        vistos = set()
        for entrada in entradas:
            if not isinstance(entrada, dict):
                c.falhar("registro_baseline_invalido")
                continue
            relativo = entrada.get("arquivo")
            hashes = [entrada.get(campo) for campo in ("sha256", "sha256_antes", "sha256_depois")]
            if not all(isinstance(h, str) and SHA.fullmatch(h) for h in hashes) or len(set(hashes)) != 1 or entrada.get("conteudo_inalterado") is not True:
                c.falhar("hash_baseline_invalido_ou_alterado")
                continue
            if type(entrada.get("bytes")) is not int or entrada["bytes"] < 0:
                c.falhar("tamanho_baseline_invalido")
                continue
            caminho = self.validar_caminho(relativo, c)
            if caminho is None:
                continue
            if relativo in self.baseline or caminho in vistos:
                c.falhar("arquivo_baseline_duplicado", relativo)
                continue
            vistos.add(caminho)
            self.baseline[relativo] = entrada
            self.caminhos[relativo] = caminho
        if not OBRIGATORIOS.issubset(self.baseline):
            c.falhar("baseline_nao_cobre_todos_arquivos_obrigatorios")
        c.dados.update(arquivos_baseline=len(entradas), contagens_esperadas=self.contagens_esperadas)
        return not c.falhas

    def conferir_hashes(self, depois=False):
        c = self.checar("hashes_apos_leitura" if depois else "hashes_antes_de_abrir_leitor")
        resultados = []
        for relativo, entrada in sorted(self.baseline.items()):
            caminho = self.validar_caminho(relativo, c)
            if caminho is None:
                continue
            try:
                antes = caminho.stat()
                atual = hash_arquivo(caminho)
                apos = caminho.stat()
                if (antes.st_size, antes.st_mtime_ns) != (apos.st_size, apos.st_mtime_ns):
                    c.falhar("arquivo_mudou_durante_hash", relativo)
                if apos.st_size != entrada["bytes"] or atual != entrada["sha256"]:
                    c.falhar("corpus_diverge_do_baseline_etapa1", relativo)
                if depois and self.hashes_antes.get(relativo) != atual:
                    c.falhar("arquivo_mudou_durante_leitura", relativo)
                if not depois:
                    self.hashes_antes[relativo] = atual
                resultados.append({"arquivo": relativo, "bytes": apos.st_size, "sha256_baseline": entrada["sha256"],
                                   "sha256_antes": self.hashes_antes.get(relativo),
                                   **({"sha256_depois": atual, "conteudo_inalterado": self.hashes_antes.get(relativo) == atual} if depois else {})})
            except OSError as exc:
                c.falhar("arquivo_ilegivel_" + type(exc).__name__, relativo)
        c.dados["arquivos_conferidos"] = len(resultados)
        if depois:
            self.relatorio["baseline_e_hashes_da_leitura"] = resultados
        return not c.falhas

    def carregar_jsonls(self):
        c = self.checar("ids_e_contagens_jsonl")
        self.registros, self.indices = {}, {}
        for nome in TIPOS:
            registros, indices = [], {}
            with self.caminhos[nome + ".jsonl"].open(encoding="utf-8") as entrada:
                for linha, texto in enumerate(entrada, 1):
                    registro = ler_objeto(texto)
                    ident = (registro["obra_id"], registro["pagina_pdf"]) if nome == "paginas" else registro["id"]
                    if ident in indices:
                        c.falhar("id_duplicado_" + nome)
                    indices[ident] = registro
                    registros.append(registro)
            if len(registros) != self.contagens_esperadas[nome]:
                c.falhar("contagem_divergente_" + nome)
            self.registros[nome], self.indices[nome] = registros, indices
        for oid in self.indices["obras"]:
            if "textos_obras/" + oid + ".txt" not in self.baseline:
                c.falhar("texto_obra_fora_do_baseline", oid)
        with self.caminhos["manifesto.json"].open(encoding="utf-8") as entrada:
            manifesto = ler_objeto(entrada.read())
        for campo in ("vetores_arquivo", "referencias_arquivo"):
            if manifesto.get(campo) not in self.baseline:
                c.falhar("artefato_manifesto_fora_do_baseline_" + campo)
        self.paginas_por_obra = defaultdict(list)
        for pagina in self.registros["paginas"]:
            self.paginas_por_obra[pagina["obra_id"]].append(pagina)
        for paginas in self.paginas_por_obra.values():
            paginas.sort(key=lambda p: p["pagina_pdf"])
        c.dados["contagens_lidas"] = {n: len(self.registros[n]) for n in TIPOS}
        return not c.falhas

    def rastreio_esperado(self, registro, inicio, fim):
        oid = registro["obra_id"]
        obra, secao = self.indices["obras"][oid], self.indices["secoes"][registro["secao_id"]]
        paginas = [p for p in self.paginas_por_obra[oid] if p["inicio"] < fim and p["fim"] > inicio and p["fim"] > p["inicio"]]
        return {"obra_id": oid, "titulo_obra": obra["titulo"], "volume_sugerido": obra["volume_sugerido"],
                "pdf_original": obra["pdf_original"], "sha256_pdf": obra["sha256_pdf"],
                "estado_obra": obra["estado"], "secao_id": secao["id"], "titulo_secao": secao["titulo"],
                "origem_secao": secao["origem"], "inicio_obra": inicio, "fim_obra": fim,
                "paginas_pdf": [p["pagina_pdf"] for p in paginas],
                "paginas_metadado_origem": registro["paginas"],
                "secoes_por_pagina": [{"pagina_pdf": p["pagina_pdf"], "secao_id": p["secao_id"]} for p in paginas],
                "atravessa_secoes": len({p["secao_id"] for p in paginas}) > 1,
                "bloqueada_nas_buscas": oid == OBRA_19_ANTIGA}

    @staticmethod
    def resumo_registro(registro):
        r = registro["rastreio"]
        return {"id": registro["id"], "obra_id": registro["obra_id"], "secao_id": registro["secao_id"],
                "sha256_texto": hash_texto(registro["texto"]), "sha256_pdf": r["sha256_pdf"],
                "paginas_metadado_origem": registro["paginas"], "paginas_pdf_derivadas": r["paginas_pdf"],
                "inicio_obra": r["inicio_obra"], "fim_obra": r["fim_obra"],
                "atravessa_secoes": r["atravessa_secoes"], "bloqueada_nas_buscas": r["bloqueada_nas_buscas"]}

    def ler_componente(self):
        from componentes.corpus_camada_a import CorpusCamadaA
        c = self.checar("leitura_todos_fragmentos_blocos_e_fontes")
        obras, blocos = self.indices["obras"], self.indices["blocos"]
        por_obra, por_bloco = defaultdict(list), defaultdict(list)
        for f in self.registros["fragmentos"]:
            por_obra[f["obra_id"]].append(f["id"])
            por_bloco[f["bloco_id"]].append(f["id"])
        for oid in obras:
            if not por_obra[oid]:
                c.falhar("fonte_sem_fragmentos_para_leitura", oid)
        escolhidos = set()
        for ids in por_obra.values():
            escolhidos.update((ids[0], ids[len(ids) // 2], ids[-1]))
        amostras, amostras_blocos = [], []
        fragmentos_lidos, blocos_lidos, bloqueados = 0, 0, 0
        with CorpusCamadaA(self.raiz) as corpus:
            for original in self.registros["fragmentos"]:
                fid = original["id"]
                f = corpus.fragmento(fid)
                fragmentos_lidos += 1
                if any(f.get(k) != v for k, v in original.items()):
                    c.falhar("fragmento_campos_originais_divergentes", fid)
                b = blocos[original["bloco_id"]]
                esperado = self.rastreio_esperado(original, b["inicio"] + original["inicio"], b["inicio"] + original["fim"])
                if any(f["rastreio"].get(k) != v for k, v in esperado.items()):
                    c.falhar("fragmento_rastreio_fontes_paginas_divergente", fid)
                bloqueados += int(f["rastreio"]["bloqueada_nas_buscas"])
                if fid in escolhidos:
                    amostras.append(self.resumo_registro(f))
            for original in self.registros["blocos"]:
                bid = original["id"]
                b = corpus.bloco(bid)
                blocos_lidos += 1
                if any(b.get(k) != v for k, v in original.items()):
                    c.falhar("bloco_campos_originais_divergentes", bid)
                esperado = self.rastreio_esperado(original, original["inicio"], original["fim"])
                if any(b["rastreio"].get(k) != v for k, v in esperado.items()) or b.get("fragmentos_ids") != por_bloco[bid]:
                    c.falhar("bloco_rastreio_ou_lista_fragmentos_divergente", bid)
                if (len(amostras_blocos) < 8 and b["rastreio"]["atravessa_secoes"]) or (bid == self.registros["blocos"][0]["id"]):
                    amostras_blocos.append(self.resumo_registro(b))
                    ids = por_bloco[bid]
                    if ids:
                        escolhidos.add(ids[0])
                        escolhidos.add(ids[-1])
            ctx_check = self.checar("contextos_raio1_amostrados_sem_cruzar_obras")
            ctx_amostras = []
            posicoes = {fid: (oid, pos) for oid, ids in por_obra.items() for pos, fid in enumerate(ids)}
            for original in self.registros["fragmentos"]:
                fid = original["id"]
                if fid not in escolhidos:
                    continue
                contexto = corpus.contexto(fid, raio=1)
                oid, pos = posicoes[fid]
                esperado_ids = por_obra[oid][max(0, pos - 1):pos + 2]
                if contexto.get("fragmento_id") != fid or contexto.get("obra_id") != oid or contexto.get("raio") != 1:
                    ctx_check.falhar("contexto_foco_ou_obra_divergente", fid)
                partes = contexto["fragmentos"]
                if [f["id"] for f in partes] != esperado_ids or any(f["obra_id"] != oid for f in partes):
                    ctx_check.falhar("contexto_vizinhanca_ou_obra_divergente", fid)
                for parte in partes:
                    orig = self.indices["fragmentos"][parte["id"]]
                    if any(parte.get(k) != v for k, v in orig.items()):
                        ctx_check.falhar("contexto_fragmento_original_divergente", parte["id"])
                    bloco = blocos[orig["bloco_id"]]
                    esperado_rastreio = self.rastreio_esperado(orig, bloco["inicio"] + orig["inicio"], bloco["inicio"] + orig["fim"])
                    if any(parte["rastreio"].get(k) != v for k, v in esperado_rastreio.items()):
                        ctx_check.falhar("contexto_rastreio_fontes_paginas_divergente", parte["id"])
                ctx_amostras.append({"fragmento_id": fid, "obra_id": oid,
                                     "fragmentos_ids": [f["id"] for f in partes],
                                     "blocos_ids": [f["bloco_id"] for f in partes],
                                     "paginas_pdf_derivadas": [f["rastreio"]["paginas_pdf"] for f in partes],
                                     "bloqueada_nas_buscas": oid == OBRA_19_ANTIGA})
            ctx_check.dados["contextos_conferidos"] = len(ctx_amostras)
        c.dados.update(fragmentos_lidos=fragmentos_lidos, blocos_lidos=blocos_lidos,
                       fontes_conferidas=len(obras), fragmentos_de_fonte_bloqueada=bloqueados)
        self.relatorio["fontes"] = [
            {"obra_id": oid, "sha256_pdf": o["sha256_pdf"], "texto_sha256": o["texto_sha256"],
             "fragmentos": len(por_obra[oid]), "bloqueada_nas_buscas": oid == OBRA_19_ANTIGA}
            for oid, o in obras.items()]
        self.relatorio["amostras_fragmentos"] = amostras
        self.relatorio["amostras_blocos"] = amostras_blocos
        self.relatorio["amostras_contextos"] = ctx_amostras

    def executar(self):
        baseline_ok = self.carregar_baseline()
        if baseline_ok:
            antes_ok = self.conferir_hashes()
            try:
                if antes_ok and self.carregar_jsonls():
                    self.ler_componente()
            except (OSError, ValueError, KeyError, TypeError, ImportError, RuntimeError, sqlite3.Error) as exc:
                self.checar("abertura_e_leitura_componente").falhar("componente_ou_dados_rejeitados_" + type(exc).__name__)
            finally:
                self.conferir_hashes(depois=True)
        self.relatorio["verificacoes"] = [c.relatorio() for c in self.checagens]
        self.relatorio["concluido_em_utc"] = datetime.now(timezone.utc).isoformat()
        self.relatorio["estado"] = "falhou" if any(c.falhas for c in self.checagens) else "leitura_verificada_com_limites"
        return self.relatorio


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus", type=Path, required=True)
    parser.add_argument("--auditoria", type=Path, required=True, help="Conclusão da etapa 1 ou relatório original aprovado.")
    parser.add_argument("--saida", type=Path, required=True, help="Novo JSON fora do corpus; nunca sobrescreve.")
    args = parser.parse_args(argv)
    raiz = args.corpus.expanduser().resolve()
    audit_path = args.auditoria.expanduser().resolve()
    saida = args.saida.expanduser().resolve()
    if not raiz.is_dir() or not audit_path.is_file():
        parser.error("Corpus e auditoria devem existir; nenhum corpus será criado.")
    if saida.is_relative_to(raiz) or saida.exists() or args.saida.expanduser().is_symlink() or not saida.parent.is_dir():
        parser.error("Escolha uma saída nova fora do corpus, em diretório existente.")
    verificacao = VerificacaoLeitura(raiz, audit_path)
    relatorio = verificacao.executar()
    try:
        with saida.open("x", encoding="utf-8") as arquivo:
            json.dump(relatorio, arquivo, ensure_ascii=False, indent=2, allow_nan=False)
            arquivo.write("\n")
    except FileExistsError:
        parser.error("A saída foi criada por outro processo; nenhum arquivo foi sobrescrito.")
    print("Leitura da Camada A:", relatorio["estado"])
    print("Relatório:", saida)
    print("Leitor independente; sem integração ao aplicativo ou execução de buscas.")
    return 1 if relatorio["estado"] == "falhou" else 0


if __name__ == "__main__":
    sys.exit(main())
