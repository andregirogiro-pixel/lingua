"""Testes técnicos da ferramenta de diagnóstico, sem corpus privado ou rede."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

import agente_analista
from agente_analista.busca_camada_a import abrir_camada_a_composta, BuscadorCamadaA
from agente_analista.importacao import conferir_compatibilidade
from agente_analista.tests.test_agente_analista_camada_a_core import criar_fixture
from verificar_leitura_base import Checagem, OBRA_19_ANTIGA
from verificar_busca_no_mac import VerificarBusca, importado_tecnico, verificar_resultado, main


class VerificarBuscaTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.raiz = Path(self.tmp.name)
        self.corpus_dir = self.raiz / "corpus"
        self.corpus_dir.mkdir()
        self.originais = criar_fixture(self.corpus_dir)
        self.projeto = Path(agente_analista.__file__).resolve().parents[1]

    def abrir(self):
        c = abrir_camada_a_composta(self.corpus_dir)
        self.addCleanup(c.close)
        b = BuscadorCamadaA(c)
        self.addCleanup(b.close)
        f = c.fragmentos[0]
        pacote = importado_tecnico(c.manifesto, c.vetores_por_fonte[0][0], "defesa memória")
        return c, b, pacote

    def test_envelope_tecnico_passa_compatibilidade_sem_alterar_vetor(self):
        c, b, pacote = self.abrir()
        vetor = c.vetores_por_fonte[0][0].copy()
        conferir_compatibilidade(pacote, c.manifesto)
        self.assertEqual(pacote["fonte"]["vetor_origem"], "linha_corpo_para_teste_estrutural")
        self.assertEqual(len(pacote["relato"]["paragrafos"]), 2)
        for consulta in pacote["consultas"]:
            np.testing.assert_array_equal(consulta["vetor"], vetor)
        resultado = b.buscar(pacote)
        check = Checagem("resultado")
        verificar_resultado(resultado, c, check)
        self.assertEqual(dict(check.falhas), {})

    def test_driver_real_confere_rankings_citacoes_fts_e_close_sem_rede(self):
        driver = VerificarBusca(self.projeto, self.corpus_dir, self.raiz / "baseline.json")
        driver.registros = {"fragmentos": self.originais}
        with patch("socket.socket.connect", side_effect=AssertionError("rede não autorizada no teste")):
            driver.ler_componente()
        falhas = {c.nome: dict(c.falhas) for c in driver.checagens if c.falhas}
        self.assertEqual(falhas, {})
        checks = {c.nome: c for c in driver.checagens}
        self.assertTrue(checks["rankings_topk_filtrados_antes_rrf"].dados["tentativa_vetor_da_fonte_antiga"])
        self.assertGreater(checks["citacoes_literais_dos_resultados_reais"].dados["citacoes_conferidas"], 0)
        self.assertTrue(checks["fechamento_deterministico_buscador_e_fontes"].dados["busca_apos_close_rejeitada"])
        self.assertFalse(driver.relatorio["backend_ativado_no_aplicativo"])
        self.assertFalse(driver.relatorio["rede_utilizada"])
        for amostra in driver.relatorio["amostras_buscas"]:
            self.assertEqual(amostra["vetor_origem"], "linha_corpo_para_teste_estrutural")
            self.assertNotIn(OBRA_19_ANTIGA, amostra["obras_nos_candidatos"])
            self.assertNotIn("texto", amostra)
            self.assertNotIn("vetor", amostra)
        json.dumps(driver.relatorio, ensure_ascii=False, allow_nan=False)

    def test_detecta_fonte_antiga_em_candidatos(self):
        c, b, pacote = self.abrir()
        resultado = b.buscar(pacote)
        bloqueado = next(deepcopy(v) for v in c.blocos.values() if v["referencia"]["obra_id"] == OBRA_19_ANTIGA)
        resultado["candidatos"].append(bloqueado)
        check = Checagem("resultado")
        verificar_resultado(resultado, c, check)
        self.assertIn("bloco_bloqueado_ou_desconhecido_em_candidatos", check.falhas)

    def test_detecta_fonte_antiga_em_pontuacoes(self):
        c, b, pacote = self.abrir()
        resultado = b.buscar(pacote)
        bloqueado = next(f for f in c.fragmentos if f["obra_id"] == OBRA_19_ANTIGA)
        resultado["candidatos"][0]["pontuacoes"][0]["fragmento_id"] = bloqueado["id"]
        check = Checagem("resultado")
        verificar_resultado(resultado, c, check)
        self.assertIn("fragmento_bloqueado_ou_desconhecido_em_pontuacoes", check.falhas)

    def test_detecta_fonte_antiga_em_ranking_e_ancoras(self):
        c, b, pacote = self.abrir()
        resultado = b.buscar(pacote)
        bloqueado = next(f for f in c.fragmentos if f["obra_id"] == OBRA_19_ANTIGA)
        resultado["ranking_fundido"].append({"bloco_id": bloqueado["bloco_id"]})
        resultado["ancoras"].append({"blocos": [{"bloco_id": bloqueado["bloco_id"]}]})
        check = Checagem("resultado")
        verificar_resultado(resultado, c, check)
        self.assertIn("bloco_bloqueado_ou_desconhecido_em_ranking", check.falhas)
        self.assertIn("bloco_bloqueado_ou_ausente_em_ancoras", check.falhas)

    def test_recusa_saida_existente_e_preserva_conteudo(self):
        baseline = self.raiz / "baseline.json"
        baseline.write_text("{}", encoding="utf-8")
        saida = self.raiz / "saida.json"
        saida.write_text("arquivo original", encoding="utf-8")
        with self.assertRaises(SystemExit) as e:
            main(["--projeto", str(self.projeto), "--corpus", str(self.corpus_dir),
                  "--baseline", str(baseline), "--saida", str(saida)])
        self.assertEqual(e.exception.code, 2)
        self.assertEqual(saida.read_text(encoding="utf-8"), "arquivo original")

    def test_recusa_saida_dentro_corpus(self):
        baseline = self.raiz / "baseline.json"
        baseline.write_text("{}", encoding="utf-8")
        saida = self.corpus_dir / "relatorio.json"
        with self.assertRaises(SystemExit) as e:
            main(["--projeto", str(self.projeto), "--corpus", str(self.corpus_dir),
                  "--baseline", str(baseline), "--saida", str(saida)])
        self.assertEqual(e.exception.code, 2)
        self.assertFalse(saida.exists())


if __name__ == "__main__":
    unittest.main()
