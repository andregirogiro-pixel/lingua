#!/bin/bash
set -euo pipefail

PACOTE_BUSCA="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BUSCA="${PYTHON_BUSCA:-/Users/rodrigodevellis/lingua-agente/instance/venv-agente-e5-intel/bin/python}"
PROJETO_BUSCA="${1:-/Users/rodrigodevellis/lingua-agente}"
CORPUS_BUSCA="${2:-/Users/rodrigodevellis/Documents/Qoder/2026-10-11/a276916c/camada_a}"
VOLUME19_BUSCA="${3:-}"
SAIDA_BUSCA="${4:-$HOME/Downloads}"
EXECUCAO_BUSCA="$(date +%Y%m%d_%H%M%S)_$$"

"$PYTHON_BUSCA" -c 'import sys; assert sys.version_info >= (3, 10), "Requer Python 3.10+"; import numpy, flask; print("Python:", sys.executable); print("NumPy:", numpy.__version__)'
"$PYTHON_BUSCA" "$PACOTE_BUSCA/ferramentas/aplicar_busca.py" \
  --projeto "$PROJETO_BUSCA" \
  --registro "$SAIDA_BUSCA/instalacao_busca_$EXECUCAO_BUSCA.json" \
  --backup "$SAIDA_BUSCA/backup_busca_$EXECUCAO_BUSCA"

ARGUMENTOS_BUSCA=(--projeto "$PROJETO_BUSCA" --corpus "$CORPUS_BUSCA" \
  --baseline "$PACOTE_BUSCA/dados/CONCLUSAO_ETAPA1.json" \
  --saida "$SAIDA_BUSCA/busca_camada_a_$EXECUCAO_BUSCA.json")
if [[ -n "$VOLUME19_BUSCA" ]]; then
  ARGUMENTOS_BUSCA+=(--volume19 "$VOLUME19_BUSCA")
fi
"$PYTHON_BUSCA" "$PACOTE_BUSCA/ferramentas/verificar_busca_no_mac.py" "${ARGUMENTOS_BUSCA[@]}"
printf '\nEnvie o relatório: %s\n' "$SAIDA_BUSCA/busca_camada_a_$EXECUCAO_BUSCA.json"
printf 'Guarde o backup: %s\n' "$SAIDA_BUSCA/backup_busca_$EXECUCAO_BUSCA"
