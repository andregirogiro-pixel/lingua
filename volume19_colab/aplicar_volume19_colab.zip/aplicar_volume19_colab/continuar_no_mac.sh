#!/bin/bash
set -euo pipefail

PACOTE_VOLUME19="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_VOLUME19="${PYTHON_VOLUME19:-/Users/rodrigodevellis/lingua-agente/instance/venv-agente-e5-intel/bin/python}"
PROJETO_VOLUME19="${1:-/Users/rodrigodevellis/lingua-agente}"
BASE_VOLUME19="${2:-/Users/rodrigodevellis/Documents/Qoder/2026-10-11/a276916c/camada_a}"
SAIDA_VOLUME19="${3:-$HOME/Downloads}"
EXECUCAO_VOLUME19="$(date +%Y%m%d_%H%M%S)_$$"
CODIGO_VOLUME19="$SAIDA_VOLUME19/codigo_busca_$EXECUCAO_VOLUME19"
CORPUS_VOLUME19="$PROJETO_VOLUME19/instance/volume19_camada_a_20261012T103312Z_9f45c9aa"

"$PYTHON_VOLUME19" -c 'import sys; assert sys.version_info >= (3, 10), "Requer Python 3.10+"; import numpy; print("Python:", sys.executable); print("NumPy:", numpy.__version__)'
if [[ ! -d "$SAIDA_VOLUME19" || ! -d "$PROJETO_VOLUME19/instance" ]]; then
  printf 'Downloads/saída e instance do projeto devem existir. Nenhum código foi aplicado.\n' >&2
  exit 2
fi
"$PYTHON_VOLUME19" "$PACOTE_VOLUME19/ferramentas/importar_volume19.py" \
  --preparar-codigo "$CODIGO_VOLUME19"
ETAPA_BUSCA_VOLUME19="$CODIGO_VOLUME19/etapa3_busca"

"$PYTHON_VOLUME19" "$ETAPA_BUSCA_VOLUME19/ferramentas/aplicar_busca.py" \
  --projeto "$PROJETO_VOLUME19" \
  --registro "$SAIDA_VOLUME19/instalacao_busca_$EXECUCAO_VOLUME19.json" \
  --backup "$SAIDA_VOLUME19/backup_busca_$EXECUCAO_VOLUME19"

"$PYTHON_VOLUME19" "$PACOTE_VOLUME19/ferramentas/importar_volume19.py" \
  --projeto "$PROJETO_VOLUME19" --destino "$CORPUS_VOLUME19" \
  --registro "$SAIDA_VOLUME19/importacao_volume19_$EXECUCAO_VOLUME19.json"

"$PYTHON_VOLUME19" "$ETAPA_BUSCA_VOLUME19/ferramentas/verificar_busca_no_mac.py" \
  --projeto "$PROJETO_VOLUME19" --corpus "$BASE_VOLUME19" \
  --baseline "$ETAPA_BUSCA_VOLUME19/dados/CONCLUSAO_ETAPA1.json" \
  --volume19 "$CORPUS_VOLUME19" \
  --saida "$SAIDA_VOLUME19/busca_camada_a_$EXECUCAO_VOLUME19.json"

printf '\nEnvie o relatório: %s\n' "$SAIDA_VOLUME19/busca_camada_a_$EXECUCAO_VOLUME19.json"
printf 'Guarde o backup e os dois recibos em: %s\n' "$SAIDA_VOLUME19"
printf 'O script terminou sem iniciar servidor ou selecionar o backend de busca.\n'
