"""Confere o resultado Colab fixo e importa o volume 19 em uma pasta própria.

NumPy é necessário somente para a conferência real do corpus. Este script não
carrega E5, inicia servidores, muda variáveis ou altera o corpus histórico.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import sys
import tempfile
import zipfile

PACOTE = Path(__file__).resolve().parents[1]
EXECUCAO = "20261012T103312Z_9f45c9aa"
NOME_JSON = f"volume19_vetores_colab_{EXECUCAO}.json"
NOME_ZIP = f"volume19_vetores_colab_{EXECUCAO}.zip"
HASHES = {
    "etapa3_busca.zip": "605e807571cc1778aaaead56903fa8301b3134a90e3f3f463ae64dd69321289e",
    NOME_JSON: "344d92482dfe7bf77f8942356eea0ab8fe67af32728e8d0bc7758509859c82b1",
    NOME_ZIP: "7b511841e49bcf20631d246450194b2429d8802771541aa84f472a1a4128e410",
}
HASH_BUILDER = "37f1984db5e17e2472f32326e671520117913f441cf55a44d7382fd3389031b6"
NOMES_CORPUS = {
    "blocos.jsonl", "corpus.sqlite", "entradas_vetorizacao.jsonl",
    "fragmentos.jsonl", "geracao.json", "manifesto.json", "paginas.jsonl",
    "secoes.jsonl", "texto_volume19.txt", "vetores_e5.npy",
}


def sha(caminho: Path) -> str:
    calculo = hashlib.sha256()
    with caminho.open("rb") as arquivo:
        for trecho in iter(lambda: arquivo.read(1024 * 1024), b""):
            calculo.update(trecho)
    return calculo.hexdigest()


def _objeto(pares):
    resultado = {}
    for chave, valor in pares:
        if chave in resultado:
            raise ValueError(f"Chave JSON duplicada: {chave}")
        resultado[chave] = valor
    return resultado


def caminho_sem_links(caminho: Path) -> Path:
    """Recusa links em todos os componentes, inclusive caminhos não existentes."""
    absoluto = Path(os.path.abspath(caminho.expanduser()))
    for componente in (absoluto, *absoluto.parents):
        if componente.is_symlink():
            raise ValueError(f"Caminho contém symlink: {componente}")
    return absoluto


def conferir_artefatos(pacote: Path = PACOTE) -> dict:
    pasta = caminho_sem_links(pacote / "artefatos")
    for nome, esperado in HASHES.items():
        arquivo = caminho_sem_links(pasta / nome)
        if not arquivo.is_file() or sha(arquivo) != esperado:
            raise ValueError(f"Artefato ausente ou alterado: {nome}. Nenhum código será executado.")
    relatorio = json.loads((pasta / NOME_JSON).read_text(encoding="utf-8"),
        object_pairs_hook=_objeto,
        parse_constant=lambda x: (_ for _ in ()).throw(ValueError(f"Número inválido: {x}")))
    if (relatorio.get("execucao_id") != EXECUCAO
            or relatorio.get("pacote_codigo_sha256") != HASHES["etapa3_busca.zip"]
            or relatorio.get("arquivo_resultado_sha256") != HASHES[NOME_ZIP]
            or relatorio.get("validacao_integral", {}).get("embedding_real") is not True
            or relatorio.get("ativado_no_aplicativo") is not False
            or set(relatorio.get("arquivos_corpus", {})) != NOMES_CORPUS):
        raise ValueError("Resultado Colab não corresponde à execução real conferida.")
    return relatorio


def conferir_zip(arquivo: zipfile.ZipFile, raiz: str, *, nomes=None):
    registros = arquivo.infolist()
    vistos = set()
    for registro in registros:
        nome = registro.filename
        rel = PurePosixPath(nome)
        modo = registro.external_attr >> 16
        if (nome in vistos or "\\" in nome or rel.is_absolute()
                or ".." in rel.parts or not rel.parts or rel.parts[0] != raiz
                or nome != str(rel) or registro.is_dir()
                or stat.S_ISLNK(modo) or (stat.S_IFMT(modo) not in (0, stat.S_IFREG))
                or registro.flag_bits & 1):
            raise ValueError(f"Entrada ZIP inválida ou duplicada: {nome}")
        vistos.add(nome)
    if nomes is not None and vistos != {raiz + "/" + nome for nome in nomes}:
        raise ValueError("ZIP do corpus deve conter somente os dez arquivos conferidos.")
    if not registros:
        raise ValueError("ZIP vazio.")
    return registros


def preparar_codigo(saida: Path, *, pacote: Path = PACOTE) -> Path:
    """Verifica os três SHA antes de extrair qualquer código em pasta nova."""
    conferir_artefatos(pacote)
    saida = caminho_sem_links(saida)
    if saida.exists() or not saida.parent.is_dir():
        raise ValueError("Pasta de código deve ser nova, com diretório pai existente.")
    with zipfile.ZipFile(pacote / "artefatos" / "etapa3_busca.zip") as arquivo:
        registros = conferir_zip(arquivo, "etapa3_busca")
        saida.mkdir()
        try:
            for registro in registros:
                destino = saida / registro.filename
                destino.parent.mkdir(parents=True, exist_ok=True)
                with arquivo.open(registro) as origem, destino.open("xb") as novo:
                    shutil.copyfileobj(origem, novo)
        except BaseException:
            shutil.rmtree(saida)
            raise
    return saida / "etapa3_busca"


def carregar_builder(projeto: Path):
    projeto = caminho_sem_links(projeto)
    arquivo = caminho_sem_links(projeto / "agente_analista" / "preparar_volume19.py")
    if not arquivo.is_file() or sha(arquivo) != HASH_BUILDER:
        raise ValueError("Validador do projeto difere do código conferido da etapa 3.")
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location("_importacao_volume19_builder", arquivo)
    modulo = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modulo)
    return modulo


def conferir_pasta(pasta: Path, arquivos: dict) -> None:
    pasta = caminho_sem_links(pasta)
    if not pasta.is_dir() or {p.name for p in pasta.iterdir()} != NOMES_CORPUS:
        raise ValueError("Pasta de destino não contém exatamente os dez artefatos esperados.")
    for nome, registro in arquivos.items():
        arquivo = caminho_sem_links(pasta / nome)
        if (not arquivo.is_file() or arquivo.stat().st_size != registro["bytes"]
                or sha(arquivo) != registro["sha256"]):
            raise ValueError(f"Arquivo de corpus ausente ou diferente: {nome}. Será preservado.")


def _remover_publicados(pasta: Path, identidade: tuple, arquivos: dict) -> None:
    """Rollback limitado à pasta criada e a bytes ainda idênticos aos publicados."""
    if pasta.is_symlink() or not pasta.is_dir():
        return
    estado = pasta.stat()
    if (estado.st_dev, estado.st_ino) != identidade:
        return
    for nome, registro in arquivos.items():
        arquivo = pasta / nome
        if not arquivo.is_symlink() and arquivo.is_file() and sha(arquivo) == registro["sha256"]:
            arquivo.unlink()
    try:
        pasta.rmdir()
    except OSError:
        pass


def _gravar_recibo(registro: Path, resultado: dict):
    temporario = None
    try:
        with tempfile.NamedTemporaryFile(dir=registro.parent, prefix=".importacao_recibo_", delete=False) as arquivo:
            temporario = Path(arquivo.name)
            arquivo.write((json.dumps(resultado, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8"))
            arquivo.flush()
            os.fsync(arquivo.fileno())
        os.link(temporario, registro)
    finally:
        if temporario is not None:
            temporario.unlink(missing_ok=True)


def importar(projeto: Path, destino: Path, registro: Path, *, pacote: Path = PACOTE) -> dict:
    relatorio = conferir_artefatos(pacote)
    projeto = caminho_sem_links(projeto)
    destino = caminho_sem_links(destino)
    registro = caminho_sem_links(registro)
    if (not destino.parent.is_dir() or not registro.parent.is_dir()
            or registro.exists() or registro.is_relative_to(destino)
            or registro.is_relative_to(projeto) or destino.is_relative_to(pacote.resolve())
            or destino.is_relative_to(projeto / "agente_analista")):
        raise ValueError("Destino e recibo devem ter pais existentes; recibo novo fora do projeto/corpus.")
    builder = carregar_builder(projeto)
    arquivos = relatorio["arquivos_corpus"]
    ja_presente = destino.exists()
    identidade = None
    if ja_presente:
        conferir_pasta(destino, arquivos)
        validacao = builder.validar_corpus_volume19(destino)
    else:
        with zipfile.ZipFile(pacote / "artefatos" / NOME_ZIP) as arquivo:
            entradas = conferir_zip(arquivo, "volume19_camada_a_novo", nomes=NOMES_CORPUS)
            with tempfile.TemporaryDirectory(prefix=".volume19-importacao-", dir=destino.parent) as temporario:
                pasta = Path(temporario)
                for entrada in entradas:
                    nome = PurePosixPath(entrada.filename).name
                    with arquivo.open(entrada) as origem, (pasta / nome).open("xb") as novo:
                        shutil.copyfileobj(origem, novo)
                conferir_pasta(pasta, arquivos)
                validacao = builder.validar_corpus_volume19(pasta)
                if validacao != relatorio["validacao_integral"] or validacao["embedding_real"] is not True:
                    raise ValueError("Validação real diverge do resultado recebido do Colab.")
                builder._publicar_exclusivo(pasta, destino)
                estado = destino.stat()
                identidade = (estado.st_dev, estado.st_ino)
    try:
        conferir_pasta(destino, arquivos)
        if validacao != relatorio["validacao_integral"]:
            raise ValueError("Validação real diverge do resultado recebido do Colab.")
        resultado = {
            "etapa": "importacao_volume19_colab", "estado": "volume19_real_importado_verificado_com_limites",
            "execucao_colab": EXECUCAO, "criado_em_utc": datetime.now(timezone.utc).isoformat(),
            "destino": str(destino), "ja_presente_igual": ja_presente,
            "resultado_colab_sha256": HASHES[NOME_JSON], "zip_colab_sha256": HASHES[NOME_ZIP],
            "arquivos_corpus": arquivos, "validacao_integral": validacao,
            "corpus_historico_alterado": False, "backend_ativado": False,
            "modelo_carregado": False, "conferencia_editorial_integral": False,
        }
        _gravar_recibo(registro, resultado)
        return resultado
    except BaseException:
        if identidade is not None:
            _remover_publicados(destino, identidade, arquivos)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preparar-codigo", type=Path)
    parser.add_argument("--projeto", type=Path)
    parser.add_argument("--destino", type=Path)
    parser.add_argument("--registro", type=Path)
    args = parser.parse_args()
    try:
        if args.preparar_codigo is not None:
            if any((args.projeto, args.destino, args.registro)):
                raise ValueError("Use preparação de código ou importação de corpus separadamente.")
            print("Três SHA256 conferidos; código extraído:", preparar_codigo(args.preparar_codigo))
        else:
            if not all((args.projeto, args.destino, args.registro)):
                raise ValueError("Importação exige --projeto, --destino e --registro.")
            resultado = importar(args.projeto, args.destino, args.registro)
            print("Volume 19:", resultado["destino"])
            print("Vetores reais conferidos:", resultado["validacao_integral"]["linhas_vetores_conferidas"])
            print("Já presente com conteúdo igual:", resultado["ja_presente_igual"])
            print("Recibo:", args.registro)
        return 0
    except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile) as exc:
        print(f"Operação não concluída: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
