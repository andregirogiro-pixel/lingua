"""Testes de importação usando o resultado real recebido do Colab (440 linhas)."""
from pathlib import Path
import shutil
import stat
import tempfile
import unittest
from unittest.mock import patch
import warnings
import zipfile

import importar_volume19 as importar


class ImportacaoRealTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="importacao volume19 ")
        self.raiz = Path(self.temp.name)
        self.projeto = self.raiz / "projeto com espaços"
        (self.projeto / "agente_analista").mkdir(parents=True)
        self.codigo = importar.preparar_codigo(self.raiz / "codigo conferido")
        shutil.copy2(self.codigo / "arquivos/agente_analista/preparar_volume19.py",
                     self.projeto / "agente_analista/preparar_volume19.py")
        self.destino = self.raiz / "corpus novo com espaços"
        self.registro = self.raiz / "recibo inicial.json"

    def tearDown(self):
        self.temp.cleanup()

    def aplicar(self, registro=None, **opcoes):
        return importar.importar(self.projeto, self.destino, registro or self.registro, **opcoes)

    def test_importacao_real_integral_e_idempotencia(self):
        primeira = self.aplicar()
        self.assertFalse(primeira["ja_presente_igual"])
        self.assertEqual(primeira["validacao_integral"]["linhas_vetores_conferidas"], 440)
        hashes = {p.name: importar.sha(p) for p in self.destino.iterdir()}
        segunda = self.aplicar(self.raiz / "recibo repeticao.json")
        self.assertTrue(segunda["ja_presente_igual"])
        self.assertEqual(hashes, {p.name: importar.sha(p) for p in self.destino.iterdir()})
        self.assertFalse(segunda["backend_ativado"])

    def test_conflito_preserva_edicao_do_usuario(self):
        self.aplicar()
        texto = self.destino / "texto_volume19.txt"
        texto.write_text("edição local", encoding="utf-8")
        recibo = self.raiz / "recibo nao criado.json"
        with self.assertRaisesRegex(ValueError, "Será preservado"):
            self.aplicar(recibo)
        self.assertEqual(texto.read_text(encoding="utf-8"), "edição local")
        self.assertFalse(recibo.exists())

    def test_arquivo_extra_recusado_sem_remocao(self):
        self.aplicar()
        extra = self.destino / "nota pessoal.txt"
        extra.write_text("preservar", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "dez artefatos"):
            self.aplicar(self.raiz / "outro recibo.json")
        self.assertEqual(extra.read_text(), "preservar")

    def test_json_zip_ou_codigo_alterados_recusados_antes_de_extrair(self):
        pacote = self.raiz / "pacote alterado"
        shutil.copytree(importar.PACOTE / "artefatos", pacote / "artefatos")
        for nome in importar.HASHES:
            with self.subTest(nome=nome):
                arquivo = pacote / "artefatos" / nome
                original = arquivo.read_bytes()
                arquivo.write_bytes(original + b" ")
                with self.assertRaisesRegex(ValueError, "Artefato ausente ou alterado"):
                    importar.preparar_codigo(self.raiz / "extracao recusada", pacote=pacote)
                self.assertFalse((self.raiz / "extracao recusada").exists())
                arquivo.write_bytes(original)

    def test_symlink_destino_e_pai_recusados(self):
        verdadeiro = self.raiz / "destino verdadeiro"
        verdadeiro.mkdir()
        self.destino.symlink_to(verdadeiro, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, "symlink"):
            self.aplicar()
        self.destino.unlink()
        pai_link = self.raiz / "pai link"
        pai_link.symlink_to(verdadeiro, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, "symlink"):
            importar.importar(self.projeto, pai_link / "novo", self.registro)
        self.assertEqual(list(verdadeiro.iterdir()), [])

    def test_recibo_existente_preservado(self):
        self.registro.write_bytes(b"")
        with self.assertRaisesRegex(ValueError, "recibo novo"):
            self.aplicar()
        self.assertEqual(self.registro.read_bytes(), b"")
        self.assertFalse(self.destino.exists())

    def test_rollback_publicacao_parcial_e_receipt_falha(self):
        builder = importar.carregar_builder(self.projeto)
        original = builder.os.link
        contador = 0

        def falhar_no_terceiro(origem, destino):
            nonlocal contador
            contador += 1
            if contador == 3:
                raise OSError("falha de disco simulada")
            return original(origem, destino)

        with patch.object(importar, "carregar_builder", return_value=builder), patch.object(builder.os, "link", side_effect=falhar_no_terceiro):
            with self.assertRaisesRegex(OSError, "falha de disco"):
                self.aplicar()
        self.assertFalse(self.destino.exists())
        self.assertFalse(self.registro.exists())
        self.assertEqual(list(self.raiz.glob(".volume19-importacao-*")), [])
        with patch.object(importar, "_gravar_recibo", side_effect=OSError("sem espaço no recibo")):
            with self.assertRaisesRegex(OSError, "sem espaço"):
                self.aplicar()
        self.assertFalse(self.destino.exists())
        self.assertFalse(self.registro.exists())

    def test_rollback_preserva_alteracao_concorrente(self):
        def falhar_apos_edicao(registro, resultado):
            (self.destino / "texto_volume19.txt").write_text("edição concorrente", encoding="utf-8")
            raise OSError("falha após edição")
        with patch.object(importar, "_gravar_recibo", side_effect=falhar_apos_edicao):
            with self.assertRaisesRegex(OSError, "falha após edição"):
                self.aplicar()
        self.assertEqual((self.destino / "texto_volume19.txt").read_text(encoding="utf-8"), "edição concorrente")
        self.assertEqual({p.name for p in self.destino.iterdir()}, {"texto_volume19.txt"})

    def test_validador_local_alterado_recusado(self):
        arquivo = self.projeto / "agente_analista/preparar_volume19.py"
        with arquivo.open("ab") as f:
            f.write(b"\n# mudanca local\n")
        with self.assertRaisesRegex(ValueError, "Validador do projeto difere"):
            self.aplicar()
        self.assertFalse(self.destino.exists())

    def test_zip_traversal_duplicatas_symlinks_e_extras_recusados(self):
        zip_teste = self.raiz / "zip malicioso.zip"
        casos = [
            ["volume19_camada_a_novo/../fora.txt"],
            ["/volume19_camada_a_novo/texto_volume19.txt"],
            ["volume19_camada_a_novo/duplicado", "volume19_camada_a_novo/duplicado"],
            ["outra_raiz/texto.txt"],
            ["volume19_camada_a_novo\\texto.txt"],
        ]
        for nomes in casos:
            with self.subTest(nomes=nomes):
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore", UserWarning)
                    with zipfile.ZipFile(zip_teste, "w") as z:
                        for nome in nomes:
                            z.writestr(nome, b"x")
                with zipfile.ZipFile(zip_teste) as z:
                    with self.assertRaises(ValueError):
                        importar.conferir_zip(z, "volume19_camada_a_novo", nomes=importar.NOMES_CORPUS)
        with zipfile.ZipFile(zip_teste, "w") as z:
            item = zipfile.ZipInfo("volume19_camada_a_novo/texto_volume19.txt")
            item.external_attr = (stat.S_IFLNK | 0o777) << 16
            z.writestr(item, "../../destino")
        with zipfile.ZipFile(zip_teste) as z:
            with self.assertRaisesRegex(ValueError, "Entrada ZIP inválida"):
                importar.conferir_zip(z, "volume19_camada_a_novo")


if __name__ == "__main__":
    unittest.main(verbosity=2)
