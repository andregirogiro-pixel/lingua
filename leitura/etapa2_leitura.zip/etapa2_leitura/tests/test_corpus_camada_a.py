"""Testes de contrato com SQLite FTS5 e matriz NumPy reais, sem modelos remotos."""

import copy
import concurrent.futures
import hashlib
import json
import sqlite3
import sys
import tempfile
import threading
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "componentes"))
from corpus_camada_a import (  # noqa: E402
    CONTRATO_CONSULTA_E5, CorpusCamadaA, ErroContratoCamadaA,
    MODELO_E5, OBRA_19_ANTIGA, REVISAO_E5, contrato_de_execucao_lingua,
)


SCHEMA = """
CREATE TABLE obras(id TEXT PRIMARY KEY, titulo TEXT, volume_sugerido INTEGER,
  pdf_original TEXT, sha256_pdf TEXT, paginas INTEGER, texto_sha256 TEXT, estado TEXT);
CREATE TABLE secoes(id TEXT PRIMARY KEY, obra_id TEXT REFERENCES obras(id),
  titulo TEXT, origem TEXT, pagina_inicio INTEGER);
CREATE TABLE paginas(obra_id TEXT REFERENCES obras(id), pagina_pdf INTEGER,
  metodo TEXT, confianca_ocr REAL, inicio INTEGER, fim INTEGER,
  PRIMARY KEY(obra_id,pagina_pdf));
CREATE TABLE blocos(id TEXT PRIMARY KEY, obra_id TEXT REFERENCES obras(id),
  secao_id TEXT REFERENCES secoes(id), inicio INTEGER, fim INTEGER,
  texto TEXT, sha256_texto TEXT, paginas_json TEXT,
  papeis_provisorios_json TEXT, conceitos_lexicais_json TEXT);
CREATE TABLE fragmentos(id TEXT PRIMARY KEY, bloco_id TEXT REFERENCES blocos(id),
  obra_id TEXT REFERENCES obras(id), secao_id TEXT REFERENCES secoes(id),
  ordem INTEGER, inicio INTEGER, fim INTEGER, tokens INTEGER,
  anterior_id TEXT, posterior_id TEXT, cabecalho TEXT, texto TEXT, entrada_sha256 TEXT);
CREATE VIRTUAL TABLE fragmentos_fts USING fts5(fragmento_id UNINDEXED,
  cabecalho, texto, tokenize='unicode61 remove_diacritics 2');
"""


def sha(texto):
    return hashlib.sha256(texto.encode("utf-8")).hexdigest()


def criar_fixture(raiz):
    primeiro = "defesa defesa defesa.\n"
    segundo = "Vida cotidiana."
    terceiro = " Memória e sonho."
    descricoes = [
        ("obra-a", "Obra Alpha", 5, [(primeiro + segundo, [primeiro, segundo]),
                                      (terceiro, [terceiro])]),
        ("obra-v19-corrigida", "Obra revista", 19, [("defesa OR memória.", ["defesa OR memória."])]),
        (OBRA_19_ANTIGA, "Fonte antiga", 19, [("defesa defesa defesa defesa.", ["defesa defesa defesa defesa."])]),
    ]
    refs = []
    con = sqlite3.connect(raiz / "corpus.sqlite")
    con.executescript(SCHEMA)
    con.execute("PRAGMA foreign_keys=ON")
    blocos_n = 0
    for obra, titulo, volume, blocos in descricoes:
        texto_obra = "".join(b[0] for b in blocos)
        con.execute("INSERT INTO obras VALUES (?,?,?,?,?,?,?,?)",
                    (obra, titulo, volume, titulo + ".pdf", "a" * 64,
                     2 if obra == "obra-a" else 1, sha(texto_obra), "extraido_requer_conferencia_visual"))
        sec1 = obra + "-sec-0001"
        con.execute("INSERT INTO secoes VALUES (?,?,?,?,?)", (sec1, obra, "Início", "sumario_pdf", 1))
        if obra == "obra-a":
            sec2 = obra + "-sec-0002"
            con.execute("INSERT INTO secoes VALUES (?,?,?,?,?)", (sec2, obra, "Continuação", "sumario_pdf", 2))
            con.execute("INSERT INTO paginas VALUES (?,?,?,?,?,?)", (obra, 1, "pdf_texto", None, 0, len(primeiro)))
            con.execute("INSERT INTO paginas VALUES (?,?,?,?,?,?)", (obra, 2, "pdf_texto", None, len(primeiro), len(texto_obra)))
        else:
            con.execute("INSERT INTO paginas VALUES (?,?,?,?,?,?)", (obra, 1, "pdf_texto", None, 0, len(texto_obra)))
        refs_obra = []
        cursor = 0
        for i, (texto_bloco, fragmentos) in enumerate(blocos):
            bid = obra + f"-b{i:05d}"
            secid = (obra + "-sec-0002") if obra == "obra-a" and i == 1 else sec1
            pnos = ([1, 2] if i == 0 else [2]) if obra == "obra-a" else [1]
            con.execute("INSERT INTO blocos VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (bid, obra, secid, cursor, cursor + len(texto_bloco), texto_bloco,
                         sha(texto_bloco), json.dumps(pnos), "[]", "[]"))
            pos = 0
            for j, texto in enumerate(fragmentos):
                cabecalho = titulo + " — " + ("Continuação" if i else "Início")
                f = {"id": bid + f"-f{j:03d}", "bloco_id": bid, "obra_id": obra,
                     "secao_id": secid, "ordem": j, "inicio": pos, "fim": pos + len(texto),
                     "texto": texto, "tokens_entrada": 24, "cabecalho": cabecalho,
                     "entrada_sha256": sha("passage: " + cabecalho + "\n" + texto),
                     "anterior_id": None, "posterior_id": None, "paginas": pnos}
                refs_obra.append(f)
                pos += len(texto)
            cursor += len(texto_bloco)
            blocos_n += 1
        for pos, f in enumerate(refs_obra):
            f["anterior_id"] = refs_obra[pos - 1]["id"] if pos else None
            f["posterior_id"] = refs_obra[pos + 1]["id"] if pos + 1 < len(refs_obra) else None
            con.execute("INSERT INTO fragmentos VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", tuple(f[k] for k in (
                "id", "bloco_id", "obra_id", "secao_id", "ordem", "inicio", "fim", "tokens_entrada",
                "anterior_id", "posterior_id", "cabecalho", "texto", "entrada_sha256")))
            con.execute("INSERT INTO fragmentos_fts(fragmento_id,cabecalho,texto) VALUES (?,?,?)",
                        (f["id"], f["cabecalho"], f["texto"]))
        refs.extend(refs_obra)
    con.commit()
    con.close()
    (raiz / "fragmentos.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in refs), encoding="utf-8")
    v = np.zeros((len(refs), 1024), dtype=np.float32)
    v[0, 0], v[1, 1], v[2, 2], v[4, 0] = 1, 1, 1, 1
    v[3, :2] = np.float32(1 / np.sqrt(2))
    np.save(raiz / "vetores_e5.npy", v)
    manifest = {"schema": "camada_a_freud.v1", "modelo": MODELO_E5, "revisao": REVISAO_E5,
                "dimensao": 1024, "tokens_maximo": 512, "margem_tokens": 8,
                "prefixo_passagens": "passage: ", "prefixo_consultas": "query: ",
                "tipo_vetor": "float32", "normalizacao": "L2", "vetores_arquivo": "vetores_e5.npy",
                "referencias_arquivo": "fragmentos.jsonl", "fragmentos": len(refs), "blocos": blocos_n}
    (raiz / "manifesto.json").write_text(json.dumps(manifest), encoding="utf-8")
    return refs


def metadados_lingua():
    config = {"include_prompt": True, "pooling_mode_mean_tokens": True,
              "pooling_mode_cls_token": False, "pooling_mode_lasttoken": False,
              "pooling_mode_max_tokens": False, "pooling_mode_mean_sqrt_len_tokens": False,
              "pooling_mode_weightedmean_tokens": False, "word_embedding_dimension": 1024}
    modelo = {"identificacao": MODELO_E5, "revisao": REVISAO_E5}
    perfil = {"modelo": modelo, "tokenizador": modelo, "finalidade": "consulta",
              "agregacao": "nenhuma", "precisao_inferencia": "float32", "limite_tokens": 504,
              "prefixo": "query: ", "pooling": "mean", "normalizacao": "l2", "formato_armazenamento": "float32"}
    adaptador = {"modelo": modelo, "tokenizador": modelo, "truncamento_automatico": False,
                 "prefixo_automatico": False, "pooling": "mean", "dimensao": 1024,
                 "pooling_configuracao": [config]}
    processamento = {**adaptador, "precisao_inferencia": "float32",
                     "limite_tokens_selecionado": 504, "limite_modelo_tokens": 512,
                     "adaptador": copy.deepcopy(adaptador)}
    return {"perfil": copy.deepcopy(perfil), "processamento": copy.deepcopy(processamento)}


class CorpusTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.raiz = Path(self.tmp.name)
        self.refs = criar_fixture(self.raiz)

    def abrir(self, **kwargs):
        c = CorpusCamadaA(self.raiz, **kwargs)
        self.addCleanup(c.close)
        return c

    def mudar_refs(self, refs):
        (self.raiz / "fragmentos.jsonl").write_text("".join(json.dumps(r) + "\n" for r in refs), encoding="utf-8")

    def alterar_sql(self, sql, parametros=()):
        con = sqlite3.connect(self.raiz / "corpus.sqlite")
        con.execute(sql, parametros)
        con.commit()
        con.close()

    def test_leitura_nao_altera_arquivos_e_nem_metadados_originais(self):
        antes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in self.raiz.iterdir()}
        c = self.abrir()
        f = c.fragmento(self.refs[1]["id"])
        self.assertEqual({k: f[k] for k in self.refs[1]}, self.refs[1])
        self.assertEqual(f["paginas"], [1, 2])
        self.assertEqual(f["rastreio"]["paginas_pdf"], [2])
        f["texto"] = "modificado fora do leitor"
        self.assertEqual(c.fragmento(self.refs[1]["id"])["texto"], self.refs[1]["texto"])
        c.busca_lexical("memoria")
        c.busca_semantica(np.eye(1, 1024, dtype=np.float32)[0], contrato=CONTRATO_CONSULTA_E5)
        c.close()
        depois = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in self.raiz.iterdir()}
        self.assertEqual(antes, depois)

    def test_contexto_preserva_vizinhanca_entre_blocos_e_limita_obra(self):
        c = self.abrir()
        ctx = c.contexto(self.refs[1]["id"], raio=1)
        self.assertEqual([f["id"] for f in ctx["fragmentos"]], [f["id"] for f in self.refs[:3]])
        ultimo = c.contexto(self.refs[2]["id"], raio=5)
        self.assertEqual({f["obra_id"] for f in ultimo["fragmentos"]}, {"obra-a"})
        self.assertEqual(len(c.contexto(self.refs[1]["id"], raio=0)["fragmentos"]), 1)

    def test_paginas_precisas_e_secao_transversal_explicita(self):
        c = self.abrir()
        a = c.fragmento(self.refs[0]["id"])
        self.assertEqual(a["rastreio"]["paginas_pdf"], [1])
        b = c.bloco(self.refs[0]["bloco_id"])
        self.assertEqual(b["rastreio"]["paginas_pdf"], [1, 2])
        self.assertTrue(b["rastreio"]["atravessa_secoes"])
        self.assertEqual(len(b["fragmentos_ids"]), 2)
        self.assertEqual(c.fragmento(self.refs[2]["id"])["rastreio"]["inicio_obra"],
                         len(self.refs[0]["texto"]) + len(self.refs[1]["texto"]))

    def test_bm25_ordena_menor_score_e_bloqueia_apenas_fonte_antiga(self):
        c = self.abrir()
        resultados = c.busca_lexical("defesa", top_k=50, consulta_id="consulta-a")
        self.assertEqual({r["obra_id"] for r in resultados}, {"obra-a", "obra-v19-corrigida"})
        self.assertEqual([r["score"] for r in resultados], sorted(r["score"] for r in resultados))
        self.assertEqual([r["rank"] for r in resultados], [1, 2])
        self.assertTrue(all(r["consulta_id"] == "consulta-a" for r in resultados))
        completo = self.abrir(obras_bloqueadas=frozenset())
        self.assertIn(OBRA_19_ANTIGA, {r["obra_id"] for r in completo.busca_lexical("defesa")})
        self.assertEqual(c.busca_lexical("defesa", top_k=1, consulta_id="consulta-a"), resultados[:1])

    def test_fts_operadores_e_injecao_sao_tokens_literais(self):
        c = self.abrir()
        self.assertEqual([r["obra_id"] for r in c.busca_lexical("OR")], ["obra-v19-corrigida"])
        self.assertEqual([r["obra_id"] for r in c.busca_lexical('" OR 1=1 --')], ["obra-v19-corrigida"])
        self.assertEqual(c.busca_lexical("*** \"\""), [])
        self.assertEqual({r["obra_id"] for r in c.busca_lexical("memoria")}, {"obra-a", "obra-v19-corrigida"})

    def test_cosseno_normaliza_consulta_e_preserva_rank_ids(self):
        c = self.abrir()
        q = np.zeros(1024, dtype=np.float32)
        q[0] = 7
        resultados = c.busca_semantica(q, contrato=CONTRATO_CONSULTA_E5, top_k=3)
        self.assertEqual([r["fragmento_id"] for r in resultados], [self.refs[i]["id"] for i in (0, 3, 1)])
        np.testing.assert_allclose([r["score"] for r in resultados], [1, 1 / np.sqrt(2), 0], atol=1e-6)
        self.assertEqual([r["rank"] for r in resultados], [1, 2, 3])
        self.assertNotIn(OBRA_19_ANTIGA, [r["obra_id"] for r in resultados])

    def test_dimensao_igual_nao_compensa_modelo_ou_prefixo_incompativel(self):
        c = self.abrir()
        q = np.eye(1, 1024, dtype=np.float32)[0]
        for campo, invalido in (("modelo", "outro-modelo"), ("revisao", "main"),
                                ("tokenizador_revisao", "outro-commit"),
                                ("prefixo_consultas", "passage: "), ("pooling", "cls"),
                                ("normalizacao", "nenhuma"), ("tipo_vetor", "float16")):
            with self.subTest(campo=campo):
                contrato = {**CONTRATO_CONSULTA_E5, campo: invalido}
                with self.assertRaises(ErroContratoCamadaA):
                    c.busca_semantica(q, contrato=contrato)
        with self.assertRaises(ErroContratoCamadaA):
            c.busca_semantica(q, contrato={"dimensao": 1024})

    def test_consultas_de_vetor_invalidas(self):
        c = self.abrir()
        for q in (np.zeros(1024), np.ones(10), np.ones((1, 1024)), np.full(1024, np.nan),
                  np.full(1024, np.inf), ["1"] * 1024, np.ones(1024, dtype=complex)):
            with self.subTest(shape=np.shape(q)):
                with self.assertRaises(ErroContratoCamadaA):
                    c.busca_semantica(q, contrato=CONTRATO_CONSULTA_E5)

    def test_limites_e_fechamento(self):
        c = self.abrir()
        for valor in (-1, 0, 1.0, True):
            with self.assertRaises(ErroContratoCamadaA):
                c.busca_lexical("defesa", top_k=valor)
        for valor in (-1, 101, True):
            with self.assertRaises(ErroContratoCamadaA):
                c.contexto(self.refs[0]["id"], raio=valor)
        with self.assertRaises(KeyError):
            c.fragmento("inexistente")
        c.close()
        with self.assertRaises(RuntimeError):
            c.busca_lexical("defesa")

    def test_close_libera_mmap_conexao_e_caches_sem_esperar_gc(self):
        c = self.abrir()
        conexao = c._con
        mapa = c._vetores._mmap
        self.assertFalse(mapa.closed)
        self.assertTrue(c._por_id)
        preservado = c.fragmento(self.refs[0]["id"])
        c.close()
        self.assertTrue(mapa.closed)
        self.assertIsNone(c._vetores)
        self.assertIsNone(c._con)
        for nome in ("_referencias", "_por_id", "_obras", "_secoes", "_blocos",
                     "_paginas", "_por_obra", "_posicao_obra"):
            self.assertFalse(getattr(c, nome))
        with self.assertRaises(sqlite3.ProgrammingError):
            conexao.execute("SELECT 1")
        self.assertEqual(preservado["texto"], self.refs[0]["texto"])
        c.close()  # Encerramento idempotente.

    def test_matriz_rejeitada_fecha_mmap_mesmo_com_traceback_retido(self):
        v = np.load(self.raiz / "vetores_e5.npy")
        v[-1, 0] = np.nan
        np.save(self.raiz / "vetores_e5.npy", v)
        mapas = []
        objetos = []

        class ObservarRejeicao(CorpusCamadaA):
            def _validar_vetores(self):
                mapas.append(self._vetores._mmap)
                objetos.append(self)
                return super()._validar_vetores()

        erro_retido = None
        try:
            ObservarRejeicao(self.raiz)
        except ErroContratoCamadaA as exc:
            erro_retido = exc
        self.assertIsNotNone(erro_retido)
        self.assertIsNotNone(erro_retido.__traceback__)
        self.assertTrue(mapas[0].closed)
        self.assertIsNone(objetos[0]._con)
        self.assertFalse(objetos[0]._por_id)

    def test_close_aguarda_leitura_antes_de_liberar_caches(self):
        c = self.abrir()
        iniciou = threading.Event()
        liberar = threading.Event()
        close_iniciou = threading.Event()
        close_terminou = threading.Event()
        rastreio_original = c._rastreio

        def rastreio_pausado(f, inicio, fim):
            iniciou.set()
            if not liberar.wait(2):
                raise TimeoutError("A leitura instrumentada não foi liberada")
            return rastreio_original(f, inicio, fim)

        def fechar():
            close_iniciou.set()
            c.close()
            close_terminou.set()

        c._rastreio = rastreio_pausado
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            leitura = executor.submit(c.fragmento, self.refs[0]["id"])
            try:
                self.assertTrue(iniciou.wait(2))
                fechamento = executor.submit(fechar)
                self.assertTrue(close_iniciou.wait(2))
                self.assertFalse(close_terminou.wait(0.03))
            finally:
                liberar.set()
            self.assertEqual(leitura.result(timeout=2)["texto"], self.refs[0]["texto"])
            fechamento.result(timeout=2)
        self.assertTrue(close_terminou.is_set())

    def test_contrato_manifesto_e_caminhos_nao_escapam_da_raiz(self):
        p = self.raiz / "manifesto.json"
        original = json.loads(p.read_text())
        for campo, valor in (("revisao", "main"), ("dimensao", 768), ("prefixo_passagens", "query: "),
                             ("vetores_arquivo", "/tmp/vetores.npy"),
                             ("referencias_arquivo", "../fragmentos.jsonl")):
            with self.subTest(campo=campo):
                p.write_text(json.dumps({**original, campo: valor}))
                with self.assertRaises(ErroContratoCamadaA):
                    CorpusCamadaA(self.raiz)
        p.write_text(json.dumps(original))

    def test_matriz_shape_tipo_finitude_norma_em_todas_linhas(self):
        p = self.raiz / "vetores_e5.npy"
        original = np.load(p)
        ruim_nan = original.copy()
        ruim_nan[-1, 0] = np.nan
        ruim_norma = original.copy()
        ruim_norma[-1] *= 2
        for ruim in (original[:-1], original[:, :768], original.astype(np.float64), ruim_nan, ruim_norma):
            with self.subTest(shape=ruim.shape, dtype=ruim.dtype):
                np.save(p, ruim)
                with self.assertRaises(ErroContratoCamadaA):
                    CorpusCamadaA(self.raiz)

    def test_jsonl_ordem_ids_e_hash_nao_sao_confiados(self):
        for transformacao in (lambda r: r[::-1], lambda r: [r[0]] + r[:-1],
                              lambda r: [{**r[0], "entrada_sha256": "0" * 64}] + r[1:]):
            self.mudar_refs(transformacao(copy.deepcopy(self.refs)))
            with self.assertRaises(ErroContratoCamadaA):
                CorpusCamadaA(self.raiz)

    def test_vizinho_cruzando_obra_e_rejeitado_mesmo_com_sql_json_coerentes(self):
        referencias = copy.deepcopy(self.refs)
        referencias[2]["posterior_id"] = referencias[3]["id"]
        self.mudar_refs(referencias)
        self.alterar_sql("UPDATE fragmentos SET posterior_id=? WHERE id=?",
                         (referencias[3]["id"], referencias[2]["id"]))
        with self.assertRaisesRegex(ErroContratoCamadaA, "Vizinhança"):
            CorpusCamadaA(self.raiz)

    def test_texto_fts_incorreto_e_rejeitado(self):
        self.alterar_sql("UPDATE fragmentos_fts SET texto=? WHERE fragmento_id=?", ("texto errado", self.refs[0]["id"]))
        with self.assertRaisesRegex(ErroContratoCamadaA, "FTS"):
            CorpusCamadaA(self.raiz)

    def trocar_tipo_fts(self, criacao):
        con = sqlite3.connect(self.raiz / "corpus.sqlite")
        linhas = con.execute("SELECT fragmento_id,cabecalho,texto FROM fragmentos_fts").fetchall()
        con.execute("DROP TABLE fragmentos_fts")
        con.execute(criacao)
        con.executemany("INSERT INTO fragmentos_fts(fragmento_id,cabecalho,texto) VALUES (?,?,?)", linhas)
        con.commit()
        con.close()

    def test_tabela_comum_com_mesmos_ids_nao_satisfaz_fts5(self):
        self.trocar_tipo_fts("CREATE TABLE fragmentos_fts(fragmento_id TEXT,cabecalho TEXT,texto TEXT)")
        with self.assertRaisesRegex(ErroContratoCamadaA, "tabela virtual FTS5"):
            CorpusCamadaA(self.raiz)

    def test_fts_com_tokenizacao_diferente_nao_satisfaz_v1(self):
        self.trocar_tipo_fts("CREATE VIRTUAL TABLE fragmentos_fts USING fts5(fragmento_id UNINDEXED,cabecalho,texto,tokenize='unicode61 remove_diacritics 0')")
        with self.assertRaisesRegex(ErroContratoCamadaA, "remove_diacritics 2"):
            CorpusCamadaA(self.raiz)

    def test_schema_fts_legitimo_aceita_caixa_espacos_e_nome_entre_aspas(self):
        self.trocar_tipo_fts('''CREATE VIRTUAL TABLE "fragmentos_fts" USING FTS5(
            fragmento_id UNINDEXED, cabecalho, texto,
            TOKENIZE = 'unicode61   remove_diacritics   2'
        )''')
        c = self.abrir()
        self.assertEqual({r["obra_id"] for r in c.busca_lexical("memoria")}, {"obra-a", "obra-v19-corrigida"})

    def test_wal_pendente_nao_e_ignorado(self):
        (self.raiz / "corpus.sqlite-wal").write_bytes(b"pendente")
        with self.assertRaisesRegex(ErroContratoCamadaA, "WAL"):
            CorpusCamadaA(self.raiz)

    def test_pagina_ausente_nao_produz_citacao_vazia(self):
        self.alterar_sql("DELETE FROM paginas WHERE obra_id=? AND pagina_pdf=?", ("obra-a", 2))
        with self.assertRaisesRegex(ErroContratoCamadaA, "Contagem de páginas"):
            CorpusCamadaA(self.raiz)

    def test_numero_pdf_fora_da_sequencia_nao_produz_citacao_errada(self):
        self.alterar_sql("UPDATE paginas SET pagina_pdf=? WHERE obra_id=? AND pagina_pdf=?", (200, "obra-a", 2))
        with self.assertRaisesRegex(ErroContratoCamadaA, "sequência 1"):
            CorpusCamadaA(self.raiz)

    def test_secao_nao_pode_comecar_em_pagina_inexistente(self):
        self.alterar_sql("UPDATE secoes SET pagina_inicio=? WHERE id=?", (3, "obra-a-sec-0002"))
        with self.assertRaisesRegex(ErroContratoCamadaA, "Página inicial da seção"):
            CorpusCamadaA(self.raiz)

    def test_converte_metadados_lingua_l2_minusculo_sem_reetiquetar(self):
        contrato = contrato_de_execucao_lingua(metadados_lingua())
        self.assertEqual(contrato["normalizacao"], "l2")
        c = self.abrir()
        q = np.eye(1, 1024, dtype=np.float32)[0]
        self.assertEqual(c.busca_semantica(q, contrato=contrato, top_k=1)[0]["fragmento_id"], self.refs[0]["id"])

    def test_metadados_lingua_tamper_truncamento_pooling_modelo(self):
        for alterar in (
            lambda e: e["perfil"].update(prefixo="passage: "),
            lambda e: e["processamento"].update(truncamento_automatico=True),
            lambda e: e["processamento"]["adaptador"].update(prefixo_automatico=True),
            lambda e: e["processamento"]["pooling_configuracao"][0].update(include_prompt=False),
            lambda e: e["processamento"]["modelo"].update(revisao="main"),
        ):
            e = metadados_lingua()
            alterar(e)
            with self.assertRaises(ErroContratoCamadaA):
                contrato_de_execucao_lingua(e)


if __name__ == "__main__":
    unittest.main()
