"""Testes próprios do driver; não repetem a bateria do leitor independente."""
from contextlib import redirect_stderr, redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

DRIVER_SPEC = importlib.util.spec_from_file_location("verificar_leitura", Path(__file__).with_name("verificar_leitura.py"))
driver = importlib.util.module_from_spec(DRIVER_SPEC)
DRIVER_SPEC.loader.exec_module(driver)
FIXTURE_SPEC = importlib.util.spec_from_file_location("fixture_core", Path(__file__).resolve().parents[1] / "tests" / "test_corpus_camada_a.py")
fixture_core = importlib.util.module_from_spec(FIXTURE_SPEC)
FIXTURE_SPEC.loader.exec_module(fixture_core)


def snapshot_fixture(raiz):
    referencias = fixture_core.criar_fixture(raiz)
    con = sqlite3.connect(raiz / "corpus.sqlite")
    con.row_factory = sqlite3.Row
    dados = {}
    for nome in driver.TIPOS:
        if nome == "fragmentos":
            dados[nome] = referencias
            continue
        registros = [dict(r) for r in con.execute("SELECT * FROM " + nome)]
        if nome == "blocos":
            for b in registros:
                for coluna, campo in (("paginas_json", "paginas"), ("papeis_provisorios_json", "papeis_provisorios"),
                                       ("conceitos_lexicais_json", "conceitos_lexicais")):
                    b[campo] = json.loads(b.pop(coluna))
        dados[nome] = registros
    con.close()
    textos = {o["id"]: "".join(b["texto"] for b in dados["blocos"] if b["obra_id"] == o["id"])
              for o in dados["obras"]}
    for p in dados["paginas"]:
        p["texto"] = textos[p["obra_id"]][p["inicio"]:p["fim"]]
        ss = [s for s in dados["secoes"] if s["obra_id"] == p["obra_id"] and s["pagina_inicio"] <= p["pagina_pdf"]]
        p["secao_id"] = max(ss, key=lambda s: s["pagina_inicio"])["id"]
    for nome, registros in dados.items():
        (raiz / (nome + ".jsonl")).write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in registros), encoding="utf-8")
    (raiz / "textos_obras").mkdir()
    for oid, texto in textos.items():
        (raiz / "textos_obras" / (oid + ".txt")).write_text(texto, encoding="utf-8")
    contagens = {n: len(r) for n, r in dados.items()}
    (raiz / "relatorio_qualidade.json").write_text(json.dumps({"contagens": contagens}))
    baseline = [{"arquivo": str(p.relative_to(raiz)), "bytes": p.stat().st_size,
                 "sha256": driver.hash_arquivo(p), "sha256_antes": driver.hash_arquivo(p),
                 "sha256_depois": driver.hash_arquivo(p), "conteudo_inalterado": True}
                for p in sorted(raiz.rglob("*")) if p.is_file()]
    checks = [{"nome": nome, "estado": "passou", "falhas": {}, "dados": {}}
              for nome in sorted(driver.CHECAGENS_ETAPA1)]
    next(c for c in checks if c["nome"] == "hashes_baseline_atual")["dados"] = {"arquivos_conferidos": len(baseline)}
    next(c for c in checks if c["nome"] == "contagens_e_volumes")["dados"] = {"contagens": contagens}
    audit = {"etapa": "validacao_estrutural", "estado": "concluida_com_limites", "verificacoes": checks,
             "baseline_arquivos_atual": baseline}
    return referencias, audit


class TestDriver(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.raiz = Path(self.temp.name) / "corpus"
        self.raiz.mkdir()
        self.refs, self.audit = snapshot_fixture(self.raiz)
        self.audit_path = Path(self.temp.name) / "audit.json"
        self.salvar_auditoria()

    def salvar_auditoria(self):
        self.audit_path.write_text(json.dumps(self.audit), encoding="utf-8")

    def executar(self):
        return driver.VerificacaoLeitura(self.raiz, self.audit_path).executar()

    @staticmethod
    def falhas(relatorio):
        return {f for c in relatorio["verificacoes"] for f in c["falhas"]}

    def test_leitura_todos_ids_contexto_privacidade_e_hashes(self):
        relatorio = self.executar()
        self.assertEqual(relatorio["estado"], "leitura_verificada_com_limites")
        conteudo = json.dumps(relatorio, ensure_ascii=False)
        for f in self.refs:
            self.assertNotIn(f["texto"], conteudo)
        leitura = next(c for c in relatorio["verificacoes"] if c["nome"] == "leitura_todos_fragmentos_blocos_e_fontes")
        self.assertEqual(leitura["dados"]["fragmentos_lidos"], 5)
        self.assertEqual(leitura["dados"]["blocos_lidos"], 4)
        self.assertTrue(all(f["sha256_antes"] == f["sha256_depois"] == f["sha256_baseline"] for f in relatorio["baseline_e_hashes_da_leitura"]))
        antigo = next(f for f in relatorio["fontes"] if f["obra_id"] == driver.OBRA_19_ANTIGA)
        self.assertTrue(antigo["bloqueada_nas_buscas"])
        corrigido = next(f for f in relatorio["fontes"] if f["obra_id"] == "obra-v19-corrigida")
        self.assertFalse(corrigido["bloqueada_nas_buscas"])
        alvo = next(c for c in relatorio["amostras_contextos"] if c["fragmento_id"] == self.refs[1]["id"])
        self.assertEqual(alvo["fragmentos_ids"], [f["id"] for f in self.refs[:3]])
        self.assertTrue(all(all(fid.startswith(ctx["obra_id"]) for fid in ctx["fragmentos_ids"]) for ctx in relatorio["amostras_contextos"]))
        self.assertTrue(any(b["atravessa_secoes"] for b in relatorio["amostras_blocos"]))
        with patch("componentes.corpus_camada_a.CorpusCamadaA.busca_lexical", side_effect=AssertionError("busca indevida")), \
             patch("componentes.corpus_camada_a.CorpusCamadaA.busca_semantica", side_effect=AssertionError("busca indevida")):
            self.assertEqual(self.executar()["estado"], "leitura_verificada_com_limites")

    def test_baseline_drift_bloqueia_antes_de_abrir_leitor(self):
        with (self.raiz / "fragmentos.jsonl").open("a") as f:
            f.write("\n")
        with patch("componentes.corpus_camada_a.CorpusCamadaA", side_effect=AssertionError("não pode abrir")) as leitor:
            relatorio = self.executar()
        leitor.assert_not_called()
        self.assertIn("corpus_diverge_do_baseline_etapa1", self.falhas(relatorio))

    def test_caminho_baseline_externo_e_recusado(self):
        self.audit["baseline_arquivos_atual"][0]["arquivo"] = "../segredo.txt"
        self.salvar_auditoria()
        self.assertIn("caminho_baseline_invalido", self.falhas(self.executar()))

    def test_auditoria_etapa1_nao_aprovada_e_recusada(self):
        self.audit["verificacoes"][0]["estado"] = "falhou"
        self.salvar_auditoria()
        self.assertIn("verificacao_etapa1_falhou_ou_duplicada", self.falhas(self.executar()))

    def test_baseline_resumo_etapa1_tambem_e_aceito(self):
        self.audit.update(etapa=1, situacao="concluida_com_limites_documentados",
                          contagens_confirmadas=next(c["dados"]["contagens"] for c in self.audit["verificacoes"] if c["nome"] == "contagens_e_volumes"),
                          arquivos_hashes_antes_depois=self.audit.pop("baseline_arquivos_atual"))
        self.salvar_auditoria()
        self.assertEqual(self.executar()["estado"], "leitura_verificada_com_limites")

    def test_hash_apos_leitura_detecta_mudanca(self):
        verificar = driver.VerificacaoLeitura(self.raiz, self.audit_path)
        self.assertTrue(verificar.carregar_baseline())
        self.assertTrue(verificar.conferir_hashes())
        with (self.raiz / "obras.jsonl").open("a") as f:
            f.write(" ")
        self.assertFalse(verificar.conferir_hashes(depois=True))
        self.assertTrue(any("arquivo_mudou_durante_leitura" in c.falhas for c in verificar.checagens))

    def test_contexto_com_paginas_divergentes_e_rejeitado(self):
        from componentes.corpus_camada_a import CorpusCamadaA
        original_contexto = CorpusCamadaA.contexto

        def contexto_alterado(corpus, fid, raio=1):
            ctx = original_contexto(corpus, fid, raio=raio)
            ctx["fragmentos"][0]["rastreio"]["paginas_pdf"] = [9999]
            return ctx

        with patch("componentes.corpus_camada_a.CorpusCamadaA.contexto", new=contexto_alterado):
            self.assertIn("contexto_rastreio_fontes_paginas_divergente", self.falhas(self.executar()))

    def test_saida_nova_fora_corpus_sem_sobrescrita(self):
        saida = Path(self.temp.name) / "resultado.json"
        with redirect_stdout(io.StringIO()):
            self.assertEqual(driver.main(["--corpus", str(self.raiz), "--auditoria", str(self.audit_path), "--saida", str(saida)]), 0)
        antes = saida.read_bytes()
        with redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            driver.main(["--corpus", str(self.raiz), "--auditoria", str(self.audit_path), "--saida", str(saida)])
        self.assertEqual(saida.read_bytes(), antes)
        with redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            driver.main(["--corpus", str(self.raiz), "--auditoria", str(self.audit_path), "--saida", str(self.raiz / "saida.json")])
        self.assertFalse((self.raiz / "saida.json").exists())


if __name__ == "__main__":
    unittest.main()
