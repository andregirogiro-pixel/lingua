"""Copia apenas código do projeto para um ZIP novo, sem alterar a origem."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import sys
import zipfile


EXCLUIR_DIRETORIOS = {
    ".git", ".venv", "venv", "env", "instance", "data", "dados",
    "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache",
    ".ruff_cache", "build", "dist", ".idea", ".vscode",
}
EXTENSOES = {".py", ".md", ".sh", ".html", ".css", ".js", ".toml"}
NOMES_CONFIGURACAO = {"setup.cfg", "tox.ini", "pytest.ini", "MANIFEST.in"}


def arquivos_codigo(projeto: Path):
    for nome in ("lingua", "agente_analista"):
        origem = projeto / nome
        if origem.is_symlink() or not origem.is_dir():
            raise ValueError(f"Pasta de código não encontrada: {origem}")
        for atual, pastas, arquivos in os.walk(origem, topdown=True, followlinks=False):
            pasta = Path(atual)
            pastas[:] = sorted(p for p in pastas if p not in EXCLUIR_DIRETORIOS
                               and not p.startswith("venv-")
                               and not (pasta / p).is_symlink())
            for nome_arquivo in sorted(arquivos):
                arquivo = pasta / nome_arquivo
                if arquivo.is_symlink() or not arquivo.is_file():
                    continue
                if nome_arquivo == ".env" or nome_arquivo.startswith(".env."):
                    continue
                if (arquivo.suffix.lower() in EXTENSOES
                        or nome_arquivo in NOMES_CONFIGURACAO
                        or (nome_arquivo.startswith("requirements") and arquivo.suffix == ".txt")):
                    yield arquivo


def coletar(projeto: Path, saida: Path):
    projeto = projeto.expanduser().resolve()
    saida = saida.expanduser().resolve()
    if not projeto.is_dir():
        raise ValueError("A pasta do projeto não existe.")
    if saida.is_relative_to(projeto):
        raise ValueError("O ZIP de saída deve ficar fora do projeto.")
    if not saida.parent.is_dir():
        raise ValueError("A pasta de saída não existe.")
    arquivos = list(arquivos_codigo(projeto))
    if not arquivos:
        raise ValueError("Nenhum arquivo de código foi encontrado.")
    itens = []
    grupos = Counter()
    with zipfile.ZipFile(saida, "x", compression=zipfile.ZIP_DEFLATED) as pacote:
        for arquivo in arquivos:
            relativo = arquivo.relative_to(projeto).as_posix()
            conteudo = arquivo.read_bytes()
            pacote.writestr(relativo, conteudo)
            itens.append({"arquivo": relativo, "bytes": len(conteudo),
                          "sha256": hashlib.sha256(conteudo).hexdigest()})
            grupos[relativo.split("/", 1)[0]] += 1
        pacote.writestr("COLETA_CODIGO.json", json.dumps({
            "escopo": "Código de lingua e agente_analista para inspecionar interfaces",
            "arquivos": itens, "quantidades": dict(grupos),
            "exclusoes": "ambientes, caches, dados, .env, diretórios de build e symlinks",
        }, ensure_ascii=False, indent=2) + "\n")
    return {"arquivos": len(itens), "quantidades": dict(grupos), "bytes_zip": saida.stat().st_size}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--projeto", type=Path, required=True)
    parser.add_argument("--saida", type=Path, required=True)
    args = parser.parse_args()
    try:
        resultado = coletar(args.projeto, args.saida)
    except (OSError, ValueError, zipfile.BadZipFile) as erro:
        print(f"Coleta de código não concluída: {erro}", file=sys.stderr)
        return 2
    print("Código copiado:", resultado["arquivos"], "arquivos —", resultado["bytes_zip"], "bytes")
    print("ZIP de código:", str(args.saida.expanduser().resolve()))
    return 0


if __name__ == "__main__":
    sys.exit(main())
