# Componente independente para a Camada A

`corpus_camada_a.py` prepara a ligação com o aplicativo, mas ainda não a efetua.
Ele lê um pacote **completo e finalizado** do schema `camada_a_freud.v1`. Não gera
embeddings, não baixa modelos, não modifica o pacote e não altera a busca legada.
Requer Python 3.10+ e NumPy 1.24+; é compatível com NumPy 1.26 e 2.x pelas APIs
utilizadas. A validação executada neste ambiente usou NumPy 2.3.5.

## Evidência recebida da etapa 1

A auditoria do pacote real foi executada no Mac pelo usuário e conferida neste
ambiente: **12 verificações passaram**, com 19 obras, 874 seções, 5.968 páginas,
7.754 blocos e 8.594 fragmentos. Os 28 arquivos inventariados conservaram seus
hashes SHA-256 antes e depois da auditoria. A conclusão está registrada em
`CONCLUSAO_ETAPA1.json` no pacote de auditoria; o relatório de origem tem hash
`16fc7a27a8693c76ee37e970a6fb373aa1ba1634bd444689b110b16d7a27d0f6`.

A auditoria confirmou a estrutura declarada do corpus e fixou uma referência
de integridade para a etapa 2. Não comprovou qualidade editorial integral,
inferência de cada vetor ou superioridade de recuperação. Foram identificados
779 blocos que cruzam seções; o leitor conserva essa limitação no rastreio.
O corpus auditado ainda contém a fonte antiga problemática do volume 19.

Esta cópia do leitor pertence à **etapa 2: leitura e navegação**. Seus testes
locais usam fixtures completas, mas o pacote real permanece no Mac: a execução
local do diagnóstico da etapa 2 é necessária para comprovar que este leitor
abre e navega exatamente os arquivos da referência auditada. Não houve ligação
com o aplicativo nem alteração das buscas existentes.

## O que valida ao abrir

- Modelo `intfloat/multilingual-e5-large`, revisão
  `3d7cfbdacd47fdda877c5cd8a79fbcc4f2a574f3`, 1024 dimensões, prefixos
  `passage: ` e `query: `, armazenamento float32 e normalização L2.
- Arquivos relativos dentro da raiz, inclusive ao resolver links simbólicos.
- SQLite somente leitura, integridade estrutural, referências estrangeiras e
  ausência de WAL pendente. Um corpus em uso pelo pipeline deve ser finalizado
  antes da leitura; o leitor usa `immutable=1`.
- Ordem e IDs únicos das referências JSONL contra a inserção no SQLite, hashes
  da entrada `passage: cabeçalho\ntexto`, offsets, cobertura integral de blocos e
  fragmentos, hashes do texto consolidado e vizinhos na mesma obra.
- Tabela virtual FTS5 com tokenizer `unicode61 remove_diacritics 2`, conforme o
  schema v1, e consistência do conteúdo indexado com os registros de origem.
- Contagem e sequência PDF 1..N conforme `obras.paginas`, incluindo a existência
  da página inicial de cada seção.
- Shape da matriz, dtype, finitude e norma de **todas** as linhas, em lotes.

O manifesto original não contém hash da matriz nem prova independente de que
cada embedding corresponde à entrada declarada. A etapa 1 registrou o hash da
matriz e a ordem declarada das referências; isso permite detectar mudanças
posteriores do pacote. Essas verificações continuam sem provar a inferência ou
resolver uma permutação de vetores que já estivesse presente na origem. A
correspondência semântica matriz/texto exige evidência adicional antes de
publicar uma versão integrada.

## Leitura, contexto e busca lexical

```python
from componentes.corpus_camada_a import CorpusCamadaA

with CorpusCamadaA("/caminho/camada_a") as corpus:
    resultados = corpus.busca_lexical("memória e defesa", top_k=50)
    if resultados:
        primeiro = resultados[0]
        fragmento = corpus.fragmento(primeiro["fragmento_id"])
        bloco = corpus.bloco(primeiro["bloco_id"])
        contexto = corpus.contexto(primeiro["fragmento_id"], raio=1)
```

Os resultados guardam IDs originais, método, score bruto, rank, consulta_id
opcional e o fragmento com rastreio. Scores BM25 do SQLite são ordenados de menor
para maior. A consulta lexical usa palavras literais ligadas por OR; operadores
e aspas fornecidos pelo usuário não são executados como sintaxe FTS ou SQL.

`fragmento["paginas"]` conserva o metadado original, que pode abranger todo o
bloco. `fragmento["rastreio"]["paginas_pdf"]` deriva as páginas realmente
intersectadas pelos offsets do fragmento. A paginação é PDF, 1-indexada, e não a
numeração impressa. O rastreio preserva obra, seção declarada, hash do PDF e
informa quando o recorte atravessa as seções indicadas pelo sumário. Essas seções
continuam sendo metadados do corpus, sem atribuir validação editorial.

O contexto segue os vizinhos originais entre blocos da mesma obra. Não cruza
obras e não concatena textos silenciosamente.

Use o gerenciador `with` ou chame `close()` ao encerrar a leitura. Esta versão
fecha SQLite e o mmap e esvazia os caches de textos/referências mesmo quando
o objeto fechado continua referenciado ou o construtor rejeita uma matriz.
O encerramento espera uma leitura em andamento terminar. Resultados já
devolvidos são cópias independentes e permanecem utilizáveis após `close()`.
Nenhuma API devolve arrays/views do mmap: os atributos internos que os guardam
não devem ser usados pelo aplicativo. A fonte precisa permanecer imutável
durante toda a leitura.

## Consulta E5 já gerada no Língua

```python
import json
from componentes.corpus_camada_a import (
    CorpusCamadaA, contrato_de_execucao_lingua,
)

with open("vetorizacao-17.json", encoding="utf-8") as arquivo:
    execucao = json.load(arquivo)

contrato = contrato_de_execucao_lingua(execucao)

# O aplicativo deve selecionar um artefato de uma representação individual,
# validar seus hashes/associações e passar esse vetor separadamente à busca.
# O leitor não faz a importação de artefatos nem agrega representações.
vetor = artefato_individual_validado["valores"]

with CorpusCamadaA("/caminho/camada_a") as corpus:
    resultados = corpus.busca_semantica(
        vetor, contrato=contrato, top_k=50,
        consulta_id=execucao["execucao_id"],
    )
```

`contrato_de_execucao_lingua` verifica acordo entre perfil e processamento,
modelo/tokenizador/revisões, prefixo query:, pooling mean incluindo o prefixo,
limites, float32 e ausência de truncamento/prefixo automáticos. A função foi
conferida contra o JSON 17 fornecido pelo usuário. Ela não substitui o validador
de vetores e associações do Língua. A normalização declarada `l2` ou `L2` é aceita.

Uma execução sem esses metadados é rejeitada, mesmo se o vetor tiver 1024
dimensões. Não rotule vetores externos copiando a constante de contrato: use a
proveniência da execução. O leitor verifica forma/finitude/norma não nula da
consulta e a normaliza antes do produto escalar para calcular o cosseno.

Busca lexical e semântica retornam listas separadas. A fusão RRF, os pesos entre
parágrafos/contextos/documento e a comparação com a busca atual serão definidos
na integração após inspecionar o código efetivo do aplicativo.

## Fonte antiga do volume 19

O padrão é `obras_bloqueadas={"obra-3b8627dba63512a2"}`, identificado nos scripts
de auditoria enviados. A exclusão afeta buscas, mas permite leitura/contexto
para auditoria, com `bloqueada_nas_buscas=True` no rastreio. O novo PDF não deve
reutilizar os vetores ou o ID dessa fonte. Uma versão corrigida do volume 19 com
novo ID poderá entrar depois de sua própria validação.

Para uma auditoria explícita sem filtro:

```python
CorpusCamadaA("/caminho/camada_a", obras_bloqueadas=frozenset())
```

## Verificação executada

```bash
python -m unittest discover -s tests -p test_corpus_camada_a.py -v
```

26 testes com FTS5, SQLite e NPY reais verificam leitura sem alterações, limites
entre obras, paginação, ranking BM25/cosseno, filtro específico da fonte antiga,
tratamento literal de operadores, metadados da consulta e rejeição de arquivos
inconsistentes. Também rejeitam páginas ausentes/fora da sequência e índices
lexicais com tipo ou tokenizer diferente do contrato v1, aceitando diferenças
legítimas de caixa/espaçamento no SQL de criação. As regressões da etapa 2
verificam liberação imediata de conexão/mmap/caches, falha de validação com
traceback retido e fechamento concorrente com uma leitura em andamento.

Não houve benchmark no corpus completo, execução de busca real com o aplicativo,
geração de vetores ou alteração de arquivos recebidos. A auditoria real da
etapa 1 e os testes locais do leitor são evidências diferentes; o relatório da
etapa 2 deve registrar separadamente a execução local deste leitor.
