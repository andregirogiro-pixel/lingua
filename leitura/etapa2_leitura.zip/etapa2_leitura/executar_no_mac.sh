#!/bin/bash
set -euo pipefail

PASTA_ETAPA2="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_ETAPA2="${PYTHON_ETAPA2:-/Users/rodrigodevellis/lingua-agente/instance/venv-agente-e5-intel/bin/python}"
CORPUS_ETAPA2="${1:-/Users/rodrigodevellis/Documents/Qoder/2026-10-11/a276916c/camada_a}"
PROJETO_ETAPA2="${2:-/Users/rodrigodevellis/lingua-agente}"
SAIDA_ETAPA2="${3:-$HOME/Downloads}"
IDENTIFICACAO_ETAPA2="$(date +%Y%m%d_%H%M%S)_$$"
RELATORIO_ETAPA2="$SAIDA_ETAPA2/leitura_camada_a_$IDENTIFICACAO_ETAPA2.json"
CODIGO_ETAPA2="$SAIDA_ETAPA2/lingua_codigo_$IDENTIFICACAO_ETAPA2.zip"

if [[ ! -x "$PYTHON_ETAPA2" ]]; then
  printf 'Python do projeto não encontrado: %s\n' "$PYTHON_ETAPA2" >&2
  exit 2
fi
if [[ ! -d "$SAIDA_ETAPA2" ]]; then
  printf 'Pasta de saída não encontrada: %s\n' "$SAIDA_ETAPA2" >&2
  exit 2
fi
"$PYTHON_ETAPA2" -c 'import sys; assert sys.version_info >= (3, 10), "Requer Python 3.10+"; import numpy; print("Python:", sys.executable); print("NumPy:", numpy.__version__)'

set +e
"$PYTHON_ETAPA2" "$PASTA_ETAPA2/ferramentas/verificar_leitura.py" \
  --corpus "$CORPUS_ETAPA2" \
  --auditoria "$PASTA_ETAPA2/dados/CONCLUSAO_ETAPA1.json" \
  --saida "$RELATORIO_ETAPA2"
ESTADO_LEITURA_ETAPA2=$?

"$PYTHON_ETAPA2" "$PASTA_ETAPA2/ferramentas/coletar_codigo.py" \
  --projeto "$PROJETO_ETAPA2" --saida "$CODIGO_ETAPA2"
ESTADO_CODIGO_ETAPA2=$?
set -e

if [[ -f "$RELATORIO_ETAPA2" ]]; then
  printf '\nRelatório para análise: %s\n' "$RELATORIO_ETAPA2"
fi
if [[ -f "$CODIGO_ETAPA2" ]]; then
  printf 'Código para adaptar as interfaces: %s\n' "$CODIGO_ETAPA2"
fi
if [[ "$ESTADO_LEITURA_ETAPA2" -ne 0 ]]; then
  exit "$ESTADO_LEITURA_ETAPA2"
fi
exit "$ESTADO_CODIGO_ETAPA2"
