# ETAPA 1 — decisões de qualidade textual

**Decisões documentadas para todos os 19 volumes. A auditoria estrutural real foi executada no Mac e conferida: 12 verificações passaram, zero falhas.** Veja `CONCLUSAO_ETAPA1.md`. As referências abaixo a arquivos ausentes ou auditoria pendente descrevem a coleta inicial; os arquivos foram depois conferidos no Mac pelo auditor, sem copiar o corpus inteiro para este ambiente. A preparação nova do volume 19 é aceita tecnicamente como fonte candidata; isso não aprova integralmente seu conteúdo editorial nem a transforma em corpus pronto para busca. Nenhuma correção ou integração foi aplicada.

## Critérios

- **C1** — Volume identificado por conteúdo e hash dos bytes. A identificação não prova completude editorial.
- **C2** — U+FFFD/controles/duplicações são triagem. Contextos visuais e extração independente prevalecem sobre taxa lexical ou capa legível.
- **C3** — Glifos devem ser corrigidos conforme PDF/fonte e contexto; não adotar substituições globais. Nenhuma correção foi aplicada nesta decisão.
- **C4** — Publicidade e material editorial devem ser identificados por intervalos/proveniência e política de busca, conservando originais. Não apagar automaticamente capa, sumário ou notas.
- **C5** — Texto modificado exige versão, hashes, offsets e índices/vetores correspondentes. Não trocar o texto sob os embeddings existentes.
- **C6** — Aceitação técnica da preparação nova: hashes conferidos, páginas preservadas, offsets e seleção registrados, texto nativo plausível e amostras concordantes. Não equivale a aprovação editorial integral ou corpus pronto.
- **C7** — Auditoria de IDs, SQLite e linhas vetoriais requer todos os arquivos do mesmo corpus original/versionado; protótipo, testes sintéticos e manifesto isolado não a substituem.

## Decisão por volume

| Volume | ID do TXT antigo | Decisão e fundamento |
|---|---|---|
| 1 | `obra-78489fd260ea2652` | Correção de extração por fonte/contexto necessária; fonte atual preservada, sem aprovação editorial integral. 950 ocorrências dos quatro controles e um U+0006. Amostras em afirmação, dificuldades, refletir e influência sugerem fi/fl; não permitem regra universal por código Unicode. |
| 2 | `obra-08fcc68f97f2e734` | Manter fonte inventariada; estrutura conferida no Mac, aprovação editorial integral pendente. Nenhum dos quatro controles, U+FFFD, duplicação consecutiva longa ou chamada publicitária desse padrão foi detectado. Capas/sumário/material editorial e, em parte dos volumes, marcas de paginação persistem. Ausência desses marcadores não prova fidelidade ou completude. |
| 3 | `obra-983c053e2b99ca99` | Manter fonte inventariada; estrutura conferida no Mac, aprovação editorial integral pendente. Nenhum dos quatro controles, U+FFFD, duplicação consecutiva longa ou chamada publicitária desse padrão foi detectado. Capas/sumário/material editorial e, em parte dos volumes, marcas de paginação persistem. Ausência desses marcadores não prova fidelidade ou completude. |
| 4 | `obra-d2e15be704adcec1` | Separar publicidade na futura política de corpus; não substituir ou apagar textos/vetores originais. Dez chamadas Compre agora e leia e anúncios de outras obras no final. Os limites exatos de todos os anúncios precisam ser estabelecidos contra fonte/estrutura, não apenas pela chamada. Uma repetição consecutiva de verso pode ser literária; não remover por heurística. |
| 5 | `obra-cb69c2a540a9a597` | Separar publicidade na futura política de corpus; não substituir ou apagar textos/vetores originais. Dez chamadas Compre agora e leia e anúncios de outras obras no final. Os limites exatos de todos os anúncios precisam ser estabelecidos contra fonte/estrutura, não apenas pela chamada. O TXT tem hash idêntico ao anexo anterior, portanto não demonstra limpeza nova. |
| 6 | `obra-c4bf13c571ed349c` | Correção localizada por fonte/contexto necessária; não aplicar U+009F→fl. Quatro U+009F em TRÊS ENSAIOS representam Ê; há ainda um U+001E. Evidência nas linhas LF 1874, 1949, 2181 e 3293, offsets Unicode 75020, 78572, 88559 e 140017. |
| 7 | `obra-09c5629d767f7dde` | Separar publicidade na futura política de corpus; não substituir ou apagar textos/vetores originais. Dez chamadas Compre agora e leia e anúncios de outras obras no final. Os limites exatos de todos os anúncios precisam ser estabelecidos contra fonte/estrutura, não apenas pela chamada. |
| 8 | `obra-d398eb81592ffb13` | Manter fonte inventariada; estrutura conferida no Mac, aprovação editorial integral pendente. Nenhum dos quatro controles, U+FFFD, duplicação consecutiva longa ou chamada publicitária desse padrão foi detectado. Capas/sumário/material editorial e, em parte dos volumes, marcas de paginação persistem. Ausência desses marcadores não prova fidelidade ou completude. |
| 9 | `obra-9b9b7bc6e87cd0be` | Manter fonte inventariada; estrutura conferida no Mac, aprovação editorial integral pendente. Nenhum dos quatro controles, U+FFFD, duplicação consecutiva longa ou chamada publicitária desse padrão foi detectado. Capas/sumário/material editorial e, em parte dos volumes, marcas de paginação persistem. Ausência desses marcadores não prova fidelidade ou completude. |
| 10 | `obra-bc0f8d49e6035891` | Manter fonte inventariada; estrutura conferida no Mac, aprovação editorial integral pendente. Nenhum dos quatro controles, U+FFFD, duplicação consecutiva longa ou chamada publicitária desse padrão foi detectado. Capas/sumário/material editorial e, em parte dos volumes, marcas de paginação persistem. Ausência desses marcadores não prova fidelidade ou completude. |
| 11 | `obra-372dafa958fd6772` | Manter fonte inventariada; estrutura conferida no Mac, aprovação editorial integral pendente. Nenhum dos quatro controles, U+FFFD, duplicação consecutiva longa ou chamada publicitária desse padrão foi detectado. Capas/sumário/material editorial e, em parte dos volumes, marcas de paginação persistem. Ausência desses marcadores não prova fidelidade ou completude. |
| 12 | `obra-20a3cb388cbb78cd` | Manter fonte inventariada; estrutura conferida no Mac, aprovação editorial integral pendente. Nenhum dos quatro controles, U+FFFD, duplicação consecutiva longa ou chamada publicitária desse padrão foi detectado. Capas/sumário/material editorial e, em parte dos volumes, marcas de paginação persistem. Ausência desses marcadores não prova fidelidade ou completude. |
| 13 | `obra-669b2075a44a05fc` | Manter fonte inventariada; estrutura conferida no Mac, aprovação editorial integral pendente. Nenhum dos quatro controles, U+FFFD, duplicação consecutiva longa ou chamada publicitária desse padrão foi detectado. Capas/sumário/material editorial e, em parte dos volumes, marcas de paginação persistem. Ausência desses marcadores não prova fidelidade ou completude. |
| 14 | `obra-10a534bac5d81eae` | Manter fonte inventariada; estrutura conferida no Mac, aprovação editorial integral pendente. Nenhum dos quatro controles, U+FFFD, duplicação consecutiva longa ou chamada publicitária desse padrão foi detectado. Capas/sumário/material editorial e, em parte dos volumes, marcas de paginação persistem. Ausência desses marcadores não prova fidelidade ou completude. |
| 15 | `obra-281b0b52dc9fb0af` | Manter fonte inventariada; estrutura conferida no Mac, aprovação editorial integral pendente. Nenhum dos quatro controles, U+FFFD, duplicação consecutiva longa ou chamada publicitária desse padrão foi detectado. Capas/sumário/material editorial e, em parte dos volumes, marcas de paginação persistem. Ausência desses marcadores não prova fidelidade ou completude. |
| 16 | `obra-c04f37fcf4457adc` | Manter fonte inventariada; estrutura conferida no Mac, aprovação editorial integral pendente. Nenhum dos quatro controles, U+FFFD, duplicação consecutiva longa ou chamada publicitária desse padrão foi detectado. Capas/sumário/material editorial e, em parte dos volumes, marcas de paginação persistem. Ausência desses marcadores não prova fidelidade ou completude. |
| 17 | `obra-d23f86e2828f3365` | Manter fonte inventariada; estrutura conferida no Mac, aprovação editorial integral pendente. Nenhum dos quatro controles, U+FFFD, duplicação consecutiva longa ou chamada publicitária desse padrão foi detectado. Capas/sumário/material editorial e, em parte dos volumes, marcas de paginação persistem. Ausência desses marcadores não prova fidelidade ou completude. |
| 18 | `obra-da23519f73b81594` | Manter fonte inventariada; estrutura conferida no Mac, aprovação editorial integral pendente. Nenhum dos quatro controles, U+FFFD, duplicação consecutiva longa ou chamada publicitária desse padrão foi detectado. Capas/sumário/material editorial e, em parte dos volumes, marcas de paginação persistem. Ausência desses marcadores não prova fidelidade ou completude. |
| 19 | `obra-3b8627dba63512a2` | Rejeitar TXT/fonte antiga como fonte textual aprovada; aceitar preparação nova apenas tecnicamente como candidata textual versionada. TXT antigo: corpo corrompido e 5.713 duplicações longas; 1.092.277 caracteres desde offset 343 coincidem exatamente com extração antiga das páginas 5–216. Nova fonte: 244 páginas, texto nativo legível nas amostras, 49 entradas de sumário e hashes/offsets conferidos. |

Os volumes 2, 3 e 8–18 permanecem pendentes de cotejo editorial integral; sua estrutura foi conferida no Mac. O zero nas contagens não equivale a aprovação. A única repetição longa do volume 4 pode ser um verso repetido legítimo; não há decisão de removê-lo.

## Volume 19: duas fontes distintas

- **Antiga rejeitada para uso textual aprovado:** PDF de 216 páginas, SHA256 `3b8627dba63512a241a8e135e743d882d4f0b60aad65b9caff7c204a09aba5ee`; TXT `obra-3b8627dba63512a2.txt`, SHA256 `8f99f8bf444a4fb6936083c0dd001723957759e983d7d6b46f0933ac76c0a918`. O corpo desde offset 343 é idêntico à extração antiga, sem correção de seus 1.092.277 caracteres comparados.
- **Nova preparação aceita tecnicamente:** `volume19_fonte_v2`, fonte `fonte-1b4ea213276f48f77b53349109c9d9a352ade2225de43aa50765225db5c0a3ba`, PDF SHA256 `1b4ea213276f48f77b53349109c9d9a352ade2225de43aa50765225db5c0a3ba`. Os hashes do PDF e dos cinco artefatos de preparação foram conferidos nesta consolidação.
- São 244 páginas preservadas; 223 páginas PDF 10–232 selecionadas e 21 fora da busca; 49 entradas de sumário. Offsets conferidos referem-se ao novo `texto_volume19.txt`, não ao PDF ou corpus antigo.
- As amostras de extração nova e as verificações já registradas sustentam a aceitação técnica. Conferência editorial integral e política de notas/material inicial continuam pendentes.
- A preparação declara `pronto_para_busca=false`, `vetores_gerados=false` e `indices_gerados=false`. Não há IDs de fragmentos/vetores novos aprovados. Não reutilizar páginas/seções/vetores da fonte antiga para o texto novo.

## Registro da coleta inicial de dados

As ausências descritas nesta seção referem-se à coleta inicial neste ambiente. A auditoria desses arquivos foi posteriormente executada no Mac, com o resultado registrado em `CONCLUSAO_ETAPA1.md`; não são pendências de encerramento da etapa 1.

O alvo é o conjunto **Camada A original `camada_a_freud.v1`**, com os arquivos pertencentes à mesma versão. O manifesto isolado declara 7.754 blocos, 8.594 fragmentos e matriz float32 de 8.594×1.024, modelo `intfloat/multilingual-e5-large`, revisão `3d7cfbdacd47fdda877c5cd8a79fbcc4f2a574f3`. Essas contagens ainda não foram confirmadas nos arquivos reais.

| Arquivo | Situação | Verificação necessária |
|---|---|---|
| `manifesto.json` | manifesto isolado disponível; necessário confirmar que pertence ao conjunto completo entregue | Schema, contagens, modelo/revisão, parâmetros e arquivos declarados. |
| `corpus.sqlite` | ausente | Integridade SQLite, tabelas/FTS5, texto e IDs em confronto com JSONLs. |
| `obras.jsonl` | ausente | Identidade dos 19 registros e referências de origem. |
| `paginas.jsonl` | ausente para Camada A original | Rastreabilidade de páginas e offsets. O arquivo do novo 19 é outra fonte e não o substitui. |
| `secoes.jsonl` | ausente para Camada A original | Existência, hierarquia e referências das seções. |
| `blocos.jsonl` | ausente | Identidade dos 7.754 blocos declarados, textos, hashes e relações. |
| `fragmentos.jsonl` | ausente | Identidade dos 8.594 fragmentos declarados, ordem textual original, offsets, hashes de entrada e vizinhos. |
| `vetores_e5.npy` | ausente | Conferir todas as 8.594 linhas × 1.024 dimensões declaradas, dtype float32, finitude e L2; associar posição i ao fragmento i. |

Complementos: relatório de qualidade do mesmo pacote; vínculos interobras quando forem auditados; textos/PDFs/proveniência para cotejo. O `mapeamento.json` da bancada só serve para comparar a conversão experimental.

O `obras.zip` fornece 19 TXT sem SQLite, JSONLs de referências ou matriz. Os ZIPs de revisão fornecem 21 arquivos de código/documentação/metadados; o `ab_consultas.zip` fornece ferramentas e exports de consultas, não os dados do acervo. Os JSONLs da preparação nova do 19 são de outra fonte e não completam a Camada A original.

Com os arquivos reais, a auditoria deverá conferir IDs únicos, integridade referencial, textos/hashes/offsets, FTS5 e ordem declarada de todas as linhas da matriz. Forma/L2/contagem, sozinhas, não provam a identidade vetor–texto sem mapa/hash original confiável ou proveniência de geração. Não se deve ocultar esse limite nem gerar embeddings para contorná-lo nesta etapa.

## Leitura, protótipo e validação real

- **Realizado:** inventário de todos os TXT, evidências de problemas, decisões e hashes da preparação nova do 19. A análise editorial permanece estrutural/amostral.
- **Preexistente:** ferramentas e leitor independente em `scratch/integracao_camada_a`, com testes sintéticos registrados antes desta tarefa. Não foram implementados, executados ou alterados nesta consolidação; não representam validação do aplicativo ou acervo real.
- **Concluído no Mac:** auditoria sobre SQLite, JSONLs e matriz da Camada A completa; 12 verificações passaram e o relatório foi conferido. Código/testes do aplicativo serão necessários para integração futura e regressão.

## Limite desta autorização

**Parar na ETAPA 1.** A decisão “corrigir por fonte” ou “separar publicidade” registra a necessidade e a política futura; não indica correção executada. Nenhum texto/vetor original foi substituído, nenhum adaptador foi implementado e nenhum OCR, índice, fragmento ou embedding foi gerado nesta tarefa. ETAPA 2 não iniciada nesta autorização.

Evidências neste pacote: `auditoria_obras_zip/{inventario.json,resumo.md,comparacao_exata_volume19.json}`; `qualidade_volume19_alternativo/RESULTADO.md`; `volume19_fonte_v2/{manifesto.json,fonte.json,validacao_preparacao.json}`. O JSON desta entrega registra hashes, métricas, IDs, pendências e decisões individualizadas para todos os 19 volumes. Os caminhos absolutos registrados nos metadados indicam a origem no ambiente de revisão; a cópia dos artefatos para este pacote preserva seus bytes.
