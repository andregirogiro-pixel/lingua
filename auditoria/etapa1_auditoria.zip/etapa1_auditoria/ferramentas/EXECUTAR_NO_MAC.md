# Auditoria da Camada A — etapa 1

O auditor lê o corpus existente e escreve apenas um relatório JSON fora dele.
Não altera SQLite, textos, vetores ou cache; não baixa modelos nem gera embeddings.
Use uma cópia fechada do corpus: não execute seu gerador durante a auditoria.

Na pasta do pacote extraído, execute com o mesmo Python que já funcionou no Língua:

```bash
PYTHON_LINGUA="/Users/rodrigodevellis/lingua-agente/instance/venv-agente-e5-intel/bin/python"

"$PYTHON_LINGUA" ferramentas/auditar_camada_a.py \
  --corpus "/CAMINHO/DA/PASTA/camada_a" \
  --saida "$HOME/Downloads/auditoria_camada_a_$(date +%Y%m%d_%H%M%S).json"
```

Troque somente `/CAMINHO/DA/PASTA/camada_a` pela pasta que contém `manifesto.json`,
`corpus.sqlite`, `vetores_e5.npy`, `obras.jsonl`, `secoes.jsonl`, `paginas.jsonl`,
`blocos.jsonl` e `fragmentos.jsonl`. Use a Camada A original completa, não o ZIP
reduzido de revisão nem a `bancada_camada_a`.

O contrato padrão exige 19 obras/volumes 1–19, modelo
`intfloat/multilingual-e5-large`, revisão
`3d7cfbdacd47fdda877c5cd8a79fbcc4f2a574f3` e 1024 dimensões. Esses são os
metadados declarados pelo pacote original e já verificados no ambiente do Mac.
As opções `--modelo-esperado`, `--revisao-esperada` e `--dimensao-esperada` apenas
conferem um contrato alternativo explicitamente informado; não alteram o corpus.

O relatório contém contagens, hashes completos antes/depois, IDs e diagnósticos,
sem trechos dos livros. A saída não pode existir previamente nem ficar dentro do
corpus. Código de saída `1` indica falhas encontradas; `0` indica validação
estrutural concluída com os limites declarados. Envie o JSON para interpretarmos
o resultado antes da etapa 2.

Mesmo com resultado estrutural satisfatório, uma permutação dos vetores pode
passar: faltam hashes originais confiáveis que liguem cada linha ao texto.
Não interpretamos este relatório como aprovação da fidelidade editorial ou
prova da correspondência semântica entre fragmentos e vetores.
