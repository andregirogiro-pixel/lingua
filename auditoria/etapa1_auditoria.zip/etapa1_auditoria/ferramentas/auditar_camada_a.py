#!/usr/bin/env python3
"""Auditoria local e somente leitura da Camada A Freud v1.

Não importa Torch, não consulta rede, não modifica corpus/SQLite/cache e não gera
embeddings. O relatório exclusivo deve ficar FORA do corpus. Requer apenas NumPy.
Uma matriz válida e um digest atual NÃO provam a identidade semântica de suas
linhas: o pacote original não contém hashes autenticados por linha de vetor.
"""
from __future__ import annotations

import argparse
import bisect
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import sys

SCHEMA = "camada_a_freud.v1"
MODELO_E5 = "intfloat/multilingual-e5-large"
REVISAO_E5 = "3d7cfbdacd47fdda877c5cd8a79fbcc4f2a574f3"
DIMENSAO_E5 = 1024
PACOTE_ORIGINAL_SHA = "ede6cc6f73fc49f33fb88e0face88dac114bf839eb14b4bf1a790b2f6d1c5c07"
LIMITE_AMOSTRA = 8
FORMATO_SHA = re.compile(r"^[0-9a-f]{64}$")
REQUERIDOS = {
    "obras": {"id": str, "titulo": str, "volume_sugerido": (int, type(None)),
              "pdf_original": str, "sha256_pdf": str, "paginas": int,
              "texto_sha256": str, "estado": str},
    "secoes": {"id": str, "obra_id": str, "titulo": str, "origem": str,
               "pagina_inicio": int},
    "paginas": {"obra_id": str, "pagina_pdf": int, "secao_id": str,
                "texto": str, "metodo": str, "inicio": int, "fim": int,
                "confianca_ocr": (int, float, type(None))},
    "blocos": {"id": str, "obra_id": str, "secao_id": str,
               "inicio": int, "fim": int, "texto": str, "sha256_texto": str,
               "paginas": list, "papeis_provisorios": list, "conceitos_lexicais": list},
    "fragmentos": {"id": str, "bloco_id": str, "obra_id": str, "secao_id": str,
                   "ordem": int, "inicio": int, "fim": int, "texto": str,
                   "tokens_entrada": int, "cabecalho": str, "entrada_sha256": str,
                   "anterior_id": (str, type(None)), "posterior_id": (str, type(None)),
                   "paginas": list},
}
COLUNAS_SQL = {
    "obras": [(k, k) for k in REQUERIDOS["obras"]],
    "secoes": [(k, k) for k in REQUERIDOS["secoes"]],
    "paginas": [(k, k) for k in ("obra_id", "pagina_pdf", "metodo", "confianca_ocr", "inicio", "fim")],
    "blocos": [(k, k) for k in ("id", "obra_id", "secao_id", "inicio", "fim", "texto", "sha256_texto")]
              + [("paginas_json", "paginas"), ("papeis_provisorios_json", "papeis_provisorios"),
                 ("conceitos_lexicais_json", "conceitos_lexicais")],
    "fragmentos": [(k, k) for k in ("id", "bloco_id", "obra_id", "secao_id", "ordem",
                                    "inicio", "fim", "anterior_id", "posterior_id", "cabecalho",
                                    "texto", "entrada_sha256")] + [("tokens", "tokens_entrada")],
}


def sha_texto(texto):
    return hashlib.sha256(texto.encode("utf-8")).hexdigest()


def sha_arquivo(caminho):
    h = hashlib.sha256()
    with caminho.open("rb") as entrada:
        for bloco in iter(lambda: entrada.read(8 * 1024 * 1024), b""):
            h.update(bloco)
    return h.hexdigest()


def chave(nome, registro):
    if nome == "paginas":
        return (registro["obra_id"], registro["pagina_pdf"])
    return registro["id"]


def rotulo_id(valor):
    """Relatórios contêm IDs e contagens, nunca trechos do livro."""
    if isinstance(valor, tuple):
        return [rotulo_id(v) for v in valor]
    if isinstance(valor, (int, float)):
        return valor
    return str(valor).replace("\n", " ").replace("\r", " ")[:160]


class Verificacao:
    def __init__(self, nome):
        self.nome = nome
        self.falhas = Counter()
        self.amostras = defaultdict(list)
        self.dados = {}

    def falhar(self, codigo, identificador=None):
        self.falhas[codigo] += 1
        if identificador is not None and len(self.amostras[codigo]) < LIMITE_AMOSTRA:
            self.amostras[codigo].append(rotulo_id(identificador))

    def resultado(self):
        return {"nome": self.nome, "estado": "falhou" if self.falhas else "passou",
                "falhas": dict(self.falhas), "amostra_ids": dict(self.amostras),
                "dados": self.dados}


class Auditoria:
    def __init__(self, raiz, obras_esperadas, consulta, *, modelo_esperado=MODELO_E5,
                 revisao_esperada=REVISAO_E5, dimensao_esperada=DIMENSAO_E5):
        self.raiz = raiz
        self.obras_esperadas = obras_esperadas
        self.consulta = consulta
        self.metadados_esperados = {"modelo": modelo_esperado, "revisao": revisao_esperada,
                                   "dimensao": dimensao_esperada}
        self.verificacoes = []
        self.arquivos = {}
        self.avisos = []
        self.manifesto = {}
        self.registros = {}
        self.indices = {}
        self.mapeamento_linhas = []
        self.relatorio = {
            "schema_relatorio": "auditoria_camada_a.v1", "etapa": "validacao_estrutural",
            "iniciado_em_utc": datetime.now(timezone.utc).isoformat(), "corpus": str(raiz),
            "politica": "somente leitura; sem rede, reconstrução, download ou embeddings",
            "limites": [
                "Esta auditoria não autoriza a ativação do corpus no aplicativo.",
                "Não comprova fidelidade editorial da extração nem validade das classificações lexicais.",
                "Sem hashes originais confiáveis por linha, não comprova que cada vetor corresponde "
                "ao fragmento na mesma posição. Uma permutação de vetores pode passar.",
                "Os hashes produzidos são um baseline atual, não evidência de integridade histórica.",
                "Tokens declarados são conferidos contra limites; contagens não são recalculadas "
                "sem o tokenizador. Nenhum modelo é carregado.",
            ],
        }

    def verificar(self, nome):
        v = Verificacao(nome)
        self.verificacoes.append(v)
        return v

    def caminho(self, relativo, v, obrigatorio=True):
        if not isinstance(relativo, str) or not relativo or Path(relativo).is_absolute():
            v.falhar("caminho_relativo_invalido")
            return None
        candidato = (self.raiz / relativo).resolve()
        if not candidato.is_relative_to(self.raiz):
            v.falhar("caminho_fora_do_corpus")
            return None
        if not candidato.is_file():
            if obrigatorio:
                v.falhar("arquivo_ausente", relativo)
            return None
        try:
            if candidato not in self.arquivos:
                antes = candidato.stat()
                digest = sha_arquivo(candidato)
                depois = candidato.stat()
                if (antes.st_size, antes.st_mtime_ns) != (depois.st_size, depois.st_mtime_ns):
                    v.falhar("arquivo_mudou_durante_hash_inicial", relativo)
                self.arquivos[candidato] = (depois.st_size, depois.st_mtime_ns, digest)
        except OSError as exc:
            v.falhar("arquivo_ilegivel_" + type(exc).__name__, relativo)
            return None
        return candidato

    def ler_json(self, caminho, v):
        try:
            with caminho.open("r", encoding="utf-8") as entrada:
                dados = json.load(entrada)
            if not isinstance(dados, dict):
                v.falhar("json_nao_objeto")
                return None
            return dados
        except (OSError, ValueError, UnicodeError) as exc:
            v.falhar("json_ilegivel_" + type(exc).__name__)
            return None

    def ler_jsonl(self, nome, caminho):
        v = self.verificar("jsonl_" + nome)
        registros, indices = [], {}
        if caminho is None:
            v.falhar("arquivo_ausente")
            return registros, indices
        try:
            with caminho.open("r", encoding="utf-8") as entrada:
                for linha, texto in enumerate(entrada, 1):
                    if not texto.strip():
                        v.falhar("linha_vazia", linha)
                        continue
                    try:
                        registro = json.loads(texto)
                    except ValueError:
                        v.falhar("json_invalido", linha)
                        continue
                    if not isinstance(registro, dict):
                        v.falhar("registro_nao_objeto", linha)
                        continue
                    invalidos = [campo for campo, tipo in REQUERIDOS[nome].items()
                                 if campo not in registro or
                                 type(registro[campo]) not in (tipo if isinstance(tipo, tuple) else (tipo,))]
                    if invalidos:
                        for campo in invalidos:
                            v.falhar("campo_invalido_" + campo, linha)
                        continue
                    if nome in ("blocos", "fragmentos") and any(type(p) is not int or p < 1 for p in registro["paginas"]):
                        v.falhar("pagina_invalida", linha)
                    ident = chave(nome, registro)
                    if ident in indices:
                        v.falhar("id_duplicado", ident)
                    if nome != "paginas" and not registro["id"]:
                        v.falhar("id_vazio", linha)
                    registros.append(registro)
                    indices[ident] = registro
        except (OSError, UnicodeError) as exc:
            v.falhar("leitura_falhou_" + type(exc).__name__)
        v.dados.update(registros=len(registros), ids_unicos=len(indices))
        return registros, indices

    def carregar(self):
        v = self.verificar("manifesto_e_arquivos")
        manifesto_path = self.caminho("manifesto.json", v)
        if manifesto_path:
            self.manifesto = self.ler_json(manifesto_path, v) or {}
        if self.manifesto.get("schema") != SCHEMA:
            v.falhar("schema_nao_suportado")
            v.dados["schema_suportado"] = SCHEMA
            v.dados["schema_encontrado"] = rotulo_id(self.manifesto.get("schema"))
            return False
        obrigatorios = {"fragmentos": int, "blocos": int, "dimensao": int,
                        "tokens_maximo": int, "margem_tokens": int, "modelo": str,
                        "revisao": str, "prefixo_passagens": str, "prefixo_consultas": str,
                        "tipo_vetor": str, "normalizacao": str, "vetores_arquivo": str,
                        "referencias_arquivo": str}
        for campo, tipo in obrigatorios.items():
            if type(self.manifesto.get(campo)) is not tipo:
                v.falhar("campo_manifesto_invalido_" + campo)
        if v.falhas:
            return False
        for campo in ("fragmentos", "blocos", "dimensao", "tokens_maximo"):
            if self.manifesto[campo] <= 0:
                v.falhar("limite_manifesto_invalido_" + campo)
        if not 0 <= self.manifesto["margem_tokens"] < self.manifesto["tokens_maximo"] <= 512:
            v.falhar("limite_tokens_invalido")
        if not re.fullmatch(r"[0-9a-f]{40}", self.manifesto["revisao"]):
            v.falhar("revisao_nao_fixa")
        for campo, esperado in self.metadados_esperados.items():
            if self.manifesto[campo] != esperado:
                v.falhar("metadado_divergente_do_contrato_e5_" + campo)
        v.dados["contrato_metadados_esperado"] = self.metadados_esperados
        for campo, esperado in (("prefixo_passagens", "passage: "), ("prefixo_consultas", "query: "),
                                 ("tipo_vetor", "float32"), ("normalizacao", "L2")):
            if self.manifesto[campo] != esperado:
                v.falhar("configuracao_incompativel_" + campo)
        v.dados.update(modelo=self.manifesto["modelo"], revisao=self.manifesto["revisao"],
                       dimensao=self.manifesto["dimensao"])
        self.vetores_path = self.caminho(self.manifesto["vetores_arquivo"], v)
        self.refs_path = self.caminho(self.manifesto["referencias_arquivo"], v)
        self.sql_path = self.caminho("corpus.sqlite", v)
        self.qualidade_path = self.caminho("relatorio_qualidade.json", v)
        for nome in REQUERIDOS:
            caminho = self.caminho(nome + ".jsonl", v)
            self.registros[nome], self.indices[nome] = self.ler_jsonl(nome, caminho)
        fragmentos_path = (self.raiz / "fragmentos.jsonl").resolve()
        if self.refs_path and self.refs_path != fragmentos_path:
            referencias, _ = self.ler_jsonl("fragmentos", self.refs_path)
            vr = self.verificar("referencias_do_manifesto")
            if referencias != self.registros["fragmentos"]:
                vr.falhar("referencias_diferentes_do_jsonl_fragmentos")
        return True

    def contagens(self):
        v = self.verificar("contagens_e_volumes")
        atual = {nome: len(registros) for nome, registros in self.registros.items()}
        v.dados["contagens"] = atual
        for nome in ("fragmentos", "blocos"):
            if atual[nome] != self.manifesto[nome]:
                v.falhar("contagem_manifesto_divergente_" + nome)
        original = self.manifesto.get("pdf_zip_sha256") == PACOTE_ORIGINAL_SHA
        v.dados["pacote_original_identificado_por_hash_zip"] = original
        if original:
            for nome, esperado in (("fragmentos", 8594), ("blocos", 7754)):
                if atual[nome] != esperado:
                    v.falhar("contagem_pacote_original_divergente_" + nome)
        obras = self.registros["obras"]
        if self.obras_esperadas:
            if len(obras) != self.obras_esperadas:
                v.falhar("quantidade_obras_divergente")
            volumes = Counter(o["volume_sugerido"] for o in obras)
            for volume in range(1, self.obras_esperadas + 1):
                if volumes[volume] != 1:
                    v.falhar("volume_ausente_ou_duplicado", volume)
            if any(type(volume) is not int or not 1 <= volume <= self.obras_esperadas for volume in volumes):
                v.falhar("volume_fora_do_intervalo")
        v.dados["obras_esperadas"] = self.obras_esperadas or "desabilitado"
        qualidade = self.ler_json(self.qualidade_path, v) if self.qualidade_path else None
        if qualidade:
            contagens = qualidade.get("contagens")
            if not isinstance(contagens, dict):
                v.falhar("contagens_relatorio_qualidade_invalidas")
            else:
                for nome in ("obras", "paginas", "blocos", "fragmentos"):
                    if contagens.get(nome) != atual[nome]:
                        v.falhar("contagem_relatorio_qualidade_divergente_" + nome)
            nao_indexados = qualidade.get("pdfs_nao_indexados")
            if nao_indexados is not None and type(nao_indexados) is not int:
                v.falhar("contagem_pdfs_nao_indexados_invalida")
            else:
                v.dados["pdfs_nao_indexados_declarados"] = nao_indexados
        if self.manifesto.get("corpus_completo_quanto_a_abertura_dos_pdfs") is False:
            self.avisos.append("O manifesto declara PDFs não indexados. A causa exige revisão; "
                               "esta auditoria não equipara arquivos auxiliares do macOS a volumes ausentes.")

    def textos_e_relacoes(self):
        v = self.verificar("textos_offsets_hashes_e_relacoes")
        obras, secoes, paginas, blocos, fragmentos = (self.indices[n] for n in REQUERIDOS)
        grupos_paginas, grupos_blocos, grupos_fragmentos = defaultdict(list), defaultdict(list), defaultdict(list)
        for secao in self.registros["secoes"]:
            if secao["obra_id"] not in obras:
                v.falhar("secao_obra_inexistente", secao["id"])
            if (secao["obra_id"], secao["pagina_inicio"]) not in paginas:
                v.falhar("secao_pagina_inexistente", secao["id"])
        for pagina in self.registros["paginas"]:
            identificador = chave("paginas", pagina)
            grupos_paginas[pagina["obra_id"]].append(pagina)
            if pagina["obra_id"] not in obras:
                v.falhar("pagina_obra_inexistente", identificador)
            secao = secoes.get(pagina["secao_id"])
            if secao is None or secao["obra_id"] != pagina["obra_id"]:
                v.falhar("pagina_secao_inconsistente", identificador)
        for bloco in self.registros["blocos"]:
            grupos_blocos[bloco["obra_id"]].append(bloco)
            if bloco["obra_id"] not in obras:
                v.falhar("bloco_obra_inexistente", bloco["id"])
            secao = secoes.get(bloco["secao_id"])
            if secao is None or secao["obra_id"] != bloco["obra_id"]:
                v.falhar("bloco_secao_inconsistente", bloco["id"])
            if sha_texto(bloco["texto"]) != bloco["sha256_texto"]:
                v.falhar("sha_texto_bloco_divergente", bloco["id"])
            if not FORMATO_SHA.fullmatch(bloco["sha256_texto"]):
                v.falhar("sha_texto_bloco_invalido", bloco["id"])
        limite = self.manifesto["tokens_maximo"] - self.manifesto["margem_tokens"]
        for indice, fragmento in enumerate(self.registros["fragmentos"]):
            grupos_fragmentos[fragmento["bloco_id"]].append(fragmento)
            bloco = blocos.get(fragmento["bloco_id"])
            obra = obras.get(fragmento["obra_id"])
            secao = secoes.get(fragmento["secao_id"])
            if bloco is None:
                v.falhar("fragmento_bloco_inexistente", fragmento["id"])
            elif any(fragmento[k] != bloco[k] for k in ("obra_id", "secao_id", "paginas")):
                v.falhar("fragmento_bloco_relacoes_inconsistentes", fragmento["id"])
            if obra is None or secao is None or secao["obra_id"] != fragmento["obra_id"]:
                v.falhar("fragmento_obra_secao_inconsistentes", fragmento["id"])
            if obra is not None and secao is not None:
                cabecalho = f"{obra['titulo']} — {secao['titulo']}"[:220]
                if fragmento["cabecalho"] != cabecalho:
                    v.falhar("cabecalho_divergente", fragmento["id"])
            entrada = "passage: " + fragmento["cabecalho"] + "\n" + fragmento["texto"]
            if sha_texto(entrada) != fragmento["entrada_sha256"]:
                v.falhar("sha_entrada_fragmento_divergente", fragmento["id"])
            if not FORMATO_SHA.fullmatch(fragmento["entrada_sha256"]):
                v.falhar("sha_entrada_fragmento_invalido", fragmento["id"])
            if not 0 < fragmento["tokens_entrada"] <= limite:
                v.falhar("tokens_declarados_fora_do_limite", fragmento["id"])
            self.mapeamento_linhas.append({"indice": indice, "fragmento_id": fragmento["id"],
                                            "entrada_sha256": fragmento["entrada_sha256"]})
        for bloco in self.registros["blocos"]:
            partes = sorted(grupos_fragmentos[bloco["id"]], key=lambda f: f["inicio"])
            posicao = 0
            for ordem, fragmento in enumerate(partes):
                if fragmento["ordem"] != ordem or fragmento["inicio"] != posicao:
                    v.falhar("ordem_ou_offset_fragmento_divergente", fragmento["id"])
                if not 0 <= fragmento["inicio"] < fragmento["fim"] <= len(bloco["texto"]):
                    v.falhar("intervalo_fragmento_invalido", fragmento["id"])
                if fragmento["fim"] - fragmento["inicio"] != len(fragmento["texto"]):
                    v.falhar("comprimento_fragmento_divergente", fragmento["id"])
                if bloco["texto"][fragmento["inicio"]:fragmento["fim"]] != fragmento["texto"]:
                    v.falhar("fragmento_diferente_do_texto_bloco", fragmento["id"])
                posicao = fragmento["fim"]
            if posicao != len(bloco["texto"]) or "".join(f["texto"] for f in partes) != bloco["texto"]:
                v.falhar("cobertura_fragmentos_bloco_incompleta", bloco["id"])
        blocos_cruzam_secoes = 0
        textos_obra_presentes = 0
        for obra in self.registros["obras"]:
            oid = obra["id"]
            ps = sorted(grupos_paginas[oid], key=lambda p: p["pagina_pdf"])
            if len(ps) != obra["paginas"] or any(p["pagina_pdf"] != n for n, p in enumerate(ps, 1)):
                v.falhar("sequencia_paginas_incompleta", oid)
            ss = sorted((s for s in secoes.values() if s["obra_id"] == oid), key=lambda s: s["pagina_inicio"])
            inicios_secoes = [s["pagina_inicio"] for s in ss]
            if len(set(inicios_secoes)) != len(ss):
                v.falhar("secoes_com_mesma_pagina_inicio", oid)
            for pagina in ps:
                idx_secao = bisect.bisect_right(inicios_secoes, pagina["pagina_pdf"]) - 1
                if idx_secao < 0 or pagina["secao_id"] != ss[idx_secao]["id"]:
                    v.falhar("secao_pagina_diferente_do_inicio_declarado", chave("paginas", pagina))
            global_texto = "\n\n".join(p["texto"] for p in ps)
            if sha_texto(global_texto) != obra["texto_sha256"]:
                v.falhar("sha_texto_obra_divergente", oid)
            if not FORMATO_SHA.fullmatch(obra["texto_sha256"]) or not FORMATO_SHA.fullmatch(obra["sha256_pdf"]):
                v.falhar("sha_obra_invalido", oid)
            cursor = 0
            for indice, pagina in enumerate(ps):
                if indice:
                    cursor += 2
                if pagina["inicio"] != cursor or pagina["fim"] != cursor + len(pagina["texto"]):
                    v.falhar("offset_pagina_divergente", chave("paginas", pagina))
                cursor += len(pagina["texto"])
            bs = sorted(grupos_blocos[oid], key=lambda b: b["inicio"])
            cursor = 0
            inicios = [p["inicio"] for p in ps]
            for bloco in bs:
                if bloco["inicio"] != cursor or not 0 <= bloco["inicio"] < bloco["fim"] <= len(global_texto):
                    v.falhar("intervalo_bloco_invalido", bloco["id"])
                if bloco["fim"] - bloco["inicio"] != len(bloco["texto"]):
                    v.falhar("comprimento_bloco_divergente", bloco["id"])
                if global_texto[bloco["inicio"]:bloco["fim"]] != bloco["texto"]:
                    v.falhar("bloco_diferente_do_texto_obra", bloco["id"])
                inicial = bisect.bisect_right(inicios, bloco["inicio"]) - 1
                final = bisect.bisect_right(inicios, bloco["fim"] - 1) - 1
                paginas_esperadas = list(range(inicial + 1, final + 2))
                if bloco["paginas"] != paginas_esperadas:
                    v.falhar("paginas_bloco_divergentes", bloco["id"])
                if 0 <= inicial < len(ps):
                    if bloco["secao_id"] != ps[inicial]["secao_id"]:
                        v.falhar("secao_inicial_bloco_divergente", bloco["id"])
                    if any(p["secao_id"] != bloco["secao_id"] for p in ps[inicial:final + 1]):
                        blocos_cruzam_secoes += 1
                cursor = bloco["fim"]
            if global_texto.strip() and (cursor != len(global_texto) or "".join(b["texto"] for b in bs) != global_texto):
                v.falhar("cobertura_blocos_obra_incompleta", oid)
            if not global_texto.strip():
                self.avisos.append("Obra sem texto utilizável: " + rotulo_id(oid))
            caminho_txt = self.caminho("textos_obras/" + oid + ".txt", v, obrigatorio=False)
            if caminho_txt:
                textos_obra_presentes += 1
                try:
                    with caminho_txt.open("r", encoding="utf-8", newline="") as entrada_txt:
                        texto_txt = entrada_txt.read()
                    if texto_txt != global_texto or sha_texto(texto_txt) != obra["texto_sha256"]:
                        v.falhar("arquivo_texto_obra_divergente", oid)
                except (OSError, UnicodeError) as exc:
                    v.falhar("arquivo_texto_obra_ilegivel_" + type(exc).__name__, oid)
        v.dados.update(blocos_que_cruzam_secoes=blocos_cruzam_secoes,
                       textos_obras_conferidos=textos_obra_presentes)
        if blocos_cruzam_secoes:
            self.avisos.append("Há blocos que cruzam seções: a seção atribuída é a da página inicial, "
                               "uma limitação documentada do gerador v1.")

    def vizinhanca_e_ordem(self):
        v = self.verificar("vizinhanca_e_ordem_fragmentos")
        blocos = self.indices["blocos"]
        por_obra = defaultdict(list)
        ultima_obra = None
        obras_encerradas = set()
        for fragmento in self.registros["fragmentos"]:
            oid = fragmento["obra_id"]
            if oid != ultima_obra:
                if oid in obras_encerradas:
                    v.falhar("obra_intercalada_no_jsonl", oid)
                if ultima_obra is not None:
                    obras_encerradas.add(ultima_obra)
                ultima_obra = oid
            por_obra[oid].append(fragmento)
        for obra, lista in por_obra.items():
            def ordem(f):
                bloco = blocos.get(f["bloco_id"])
                return (bloco["inicio"] if bloco else -1, f["inicio"])
            if [f["id"] for f in lista] != [f["id"] for f in sorted(lista, key=ordem)]:
                v.falhar("ordem_textual_jsonl_divergente", obra)
            for indice, fragmento in enumerate(lista):
                anterior = lista[indice - 1]["id"] if indice else None
                posterior = lista[indice + 1]["id"] if indice + 1 < len(lista) else None
                if fragmento["anterior_id"] != anterior or fragmento["posterior_id"] != posterior:
                    v.falhar("vizinhanca_nao_sequencial_ou_nao_reciproca", fragmento["id"])
                for campo in ("anterior_id", "posterior_id"):
                    ident = fragmento[campo]
                    outro = self.indices["fragmentos"].get(ident) if ident else None
                    if ident and (outro is None or outro["obra_id"] != obra):
                        v.falhar("vizinho_inexistente_ou_outra_obra", fragmento["id"])
        h = hashlib.sha256()
        for linha in self.mapeamento_linhas:
            h.update((json.dumps(linha, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8"))
        self.relatorio["ordem_linhas_declarada"] = {
            "total": len(self.mapeamento_linhas), "sha256": h.hexdigest(),
            "algoritmo": "SHA-256 das linhas JSON canônico (UTF-8, sort_keys, separators=',:') com LF; "
                         "indice começa em zero, conforme fragmentos.jsonl",
            "amostra": self.mapeamento_linhas[:LIMITE_AMOSTRA],
            "identidade_semantica_vetor_texto": "nao_comprovada",
        }

    def sqlite(self):
        v = self.verificar("sqlite_somente_leitura_e_fts")
        if self.sql_path is None:
            v.falhar("sqlite_ausente_nao_criado")
            return
        for sufixo in ("-wal", "-shm", "-journal"):
            if Path(str(self.sql_path) + sufixo).exists():
                v.falhar("sqlite_com_arquivo_transacional_exige_snapshot_fechado")
                return
        con = None
        try:
            con = sqlite3.connect(self.sql_path.as_uri() + "?mode=ro&immutable=1", uri=True)
            con.execute("PRAGMA query_only=ON")
            con.execute("PRAGMA temp_store=MEMORY")
            integridade = list(con.execute("PRAGMA integrity_check"))
            if integridade != [("ok",)]:
                v.falhar("integridade_sqlite_falhou")
                v.dados["problemas_integridade"] = len(integridade)
            for tabela, rowid, parent, fk in con.execute("PRAGMA foreign_key_check"):
                v.falhar("foreign_key_invalida", (tabela, rowid, parent, fk))
            ddl_fts = con.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name=?",
                                  ("fragmentos_fts",)).fetchone()
            # O smoke test lexical sozinho não comprova o contrato do índice:
            # FTS4 ou FTS5 com outro tokenizador podem devolver resultados.
            ddl = ddl_fts[0] if ddl_fts and isinstance(ddl_fts[0], str) else ""
            ddl = re.sub(r"/\*.*?\*/|--[^\n]*", " ", ddl, flags=re.S)
            if not (re.search(r"\bCREATE\s+VIRTUAL\s+TABLE\b", ddl, re.I)
                    and re.search(r"\bUSING\s+fts5\s*\(", ddl, re.I)):
                v.falhar("fts_modulo_incompativel_exige_fts5")
            tokenizador = re.search(r"\btokenize\s*=\s*(['\"])(.*?)\1", ddl, re.I | re.S)
            configuracao = " ".join(tokenizador.group(2).casefold().split()) if tokenizador else None
            if configuracao != "unicode61 remove_diacritics 2":
                v.falhar("fts_tokenizador_incompativel_v1")
            v.dados["fts_contrato_v1"] = {
                "modulo_esperado": "fts5", "tokenizador_esperado": "unicode61 remove_diacritics 2",
                "ddl_conferido": True,
            }
            contagens = {}
            for nome, pares in COLUNAS_SQL.items():
                colunas_presentes = {r[1] for r in con.execute("PRAGMA table_info(" + nome + ")")}
                if not {p[0] for p in pares}.issubset(colunas_presentes):
                    v.falhar("schema_sqlite_incompativel_" + nome)
                    continue
                encontrados = set()
                total = 0
                for linha in con.execute("SELECT " + ",".join(p[0] for p in pares) + " FROM " + nome):
                    total += 1
                    sql = dict(zip((p[1] for p in pares), linha))
                    ident = chave(nome, sql)
                    if ident in encontrados:
                        v.falhar("id_sqlite_duplicado_" + nome, ident)
                    encontrados.add(ident)
                    original = self.indices[nome].get(ident)
                    if original is None:
                        v.falhar("sqlite_id_sem_jsonl_" + nome, ident)
                        continue
                    for coluna, campo in pares:
                        valor = sql[campo]
                        if coluna.endswith("_json"):
                            try:
                                valor = json.loads(valor)
                            except (ValueError, TypeError):
                                v.falhar("sqlite_campo_json_invalido_" + nome, ident)
                                continue
                        if valor != original[campo]:
                            v.falhar("sqlite_jsonl_divergente_" + nome + "_" + campo, ident)
                contagens[nome] = total
                if encontrados != set(self.indices[nome]) or total != len(self.registros[nome]):
                    v.falhar("sqlite_conjunto_ids_ou_contagem_divergente_" + nome)
            ids_fts, total_fts = set(), 0
            for fid, cabecalho, texto in con.execute("SELECT fragmento_id,cabecalho,texto FROM fragmentos_fts"):
                total_fts += 1
                if fid in ids_fts:
                    v.falhar("fts_id_duplicado", fid)
                ids_fts.add(fid)
                original = self.indices["fragmentos"].get(fid)
                if original is None:
                    v.falhar("fts_id_sem_fragmento", fid)
                elif cabecalho != original["cabecalho"] or texto != original["texto"]:
                    v.falhar("fts_conteudo_divergente", fid)
            if ids_fts != set(self.indices["fragmentos"]) or total_fts != len(self.registros["fragmentos"]):
                v.falhar("fts_conjunto_ids_ou_contagem_divergente")
            contagens["fragmentos_fts"] = total_fts
            v.dados["contagens"] = contagens
            try:
                hits = list(con.execute(
                    "SELECT fragmento_id,bm25(fragmentos_fts) AS score FROM fragmentos_fts "
                    "WHERE fragmentos_fts MATCH ? ORDER BY score ASC,fragmento_id ASC LIMIT 8",
                    (self.consulta,)))
                v.dados["consulta_lexical"] = {"parametrizada": True, "ordem": "BM25 ASC",
                                              "resultados": [{"fragmento_id": rotulo_id(fid), "score": score}
                                                             for fid, score in hits]}
                if not hits:
                    self.avisos.append("A consulta lexical de diagnóstico não retornou resultados. "
                                       "Isso não demonstra falha do índice.")
            except sqlite3.Error as exc:
                v.falhar("consulta_fts_falhou_" + type(exc).__name__)
        except (sqlite3.Error, OSError, TypeError) as exc:
            v.falhar("sqlite_ilegivel_ou_incompativel_" + type(exc).__name__)
        finally:
            if con is not None:
                con.close()

    def vetores(self):
        v = self.verificar("vetores_numpy_memmap")
        if self.vetores_path is None:
            v.falhar("vetores_ausentes")
            return
        try:
            import numpy as np
        except ImportError:
            v.falhar("numpy_ausente_use_ambiente_existente")
            return
        try:
            arr = np.load(self.vetores_path, mmap_mode="r", allow_pickle=False)
            if not isinstance(arr, np.memmap):
                v.falhar("arquivo_nao_npy_memmap")
                if hasattr(arr, "close"):
                    arr.close()
                return
            v.dados.update(shape=list(arr.shape), dtype=str(arr.dtype),
                           memoria="mapeamento somente leitura; lotes de 512 linhas")
            if arr.ndim != 2 or tuple(arr.shape) != (len(self.registros["fragmentos"]), self.manifesto["dimensao"]):
                v.falhar("shape_divergente")
            if arr.dtype != np.dtype("float32"):
                v.falhar("dtype_nao_float32")
            if arr.ndim != 2 or arr.dtype.kind != "f":
                return
            minimo, maximo = float("inf"), float("-inf")
            linhas_conferidas = 0
            for inicio in range(0, len(arr), 512):
                parte = arr[inicio:inicio + 512]
                finitos = np.isfinite(parte).all(axis=1)
                for deslocamento in np.flatnonzero(~finitos):
                    v.falhar("linha_nao_finita", inicio + int(deslocamento))
                with np.errstate(over="ignore", invalid="ignore"):
                    normas = np.linalg.norm(parte.astype(np.float64), axis=1)
                corretas = np.isfinite(normas) & (np.abs(normas - 1.0) <= 3e-5)
                for deslocamento in np.flatnonzero(~corretas):
                    v.falhar("norma_l2_divergente", inicio + int(deslocamento))
                normas_finitas = normas[np.isfinite(normas)]
                if len(normas_finitas):
                    minimo = min(minimo, float(normas_finitas.min()))
                    maximo = max(maximo, float(normas_finitas.max()))
                linhas_conferidas += len(parte)
            v.dados.update(linhas_conferidas=linhas_conferidas,
                           norma_l2_minima=minimo if minimo != float("inf") else None,
                           norma_l2_maxima=maximo if maximo != float("-inf") else None,
                           tolerancia_absoluta=3e-5)
        except (OSError, ValueError, TypeError) as exc:
            v.falhar("numpy_ilegivel_" + type(exc).__name__)

    def hashes(self):
        v = self.verificar("hashes_baseline_atual")
        arquivos = []
        for caminho in sorted(self.arquivos):
            relativo = str(caminho.relative_to(self.raiz))
            try:
                antes = caminho.stat()
                digest = sha_arquivo(caminho)
                depois = caminho.stat()
                if self.arquivos[caminho][:2] != (antes.st_size, antes.st_mtime_ns):
                    v.falhar("arquivo_mudou_desde_inicio_auditoria", relativo)
                hash_inicial = self.arquivos[caminho][2]
                if hash_inicial != digest:
                    v.falhar("arquivo_conteudo_mudou_durante_auditoria", relativo)
                if (antes.st_size, antes.st_mtime_ns) != (depois.st_size, depois.st_mtime_ns):
                    v.falhar("arquivo_mudou_durante_hash", relativo)
                arquivos.append({"arquivo": relativo, "bytes": depois.st_size, "sha256": digest,
                                 "sha256_antes": hash_inicial, "sha256_depois": digest,
                                 "conteudo_inalterado": hash_inicial == digest})
            except OSError as exc:
                v.falhar("hash_falhou_" + type(exc).__name__, relativo)
        self.relatorio["baseline_arquivos_atual"] = arquivos
        v.dados["arquivos_conferidos"] = len(arquivos)

    def executar(self):
        if self.carregar():
            for nome, etapa in (("contagens", self.contagens), ("textos", self.textos_e_relacoes),
                                ("vizinhanca", self.vizinhanca_e_ordem), ("sqlite", self.sqlite),
                                ("vetores", self.vetores)):
                try:
                    etapa()
                except (OSError, ValueError, TypeError, KeyError, IndexError) as exc:
                    # Dados malformados não impedem a verificação das outras partes.
                    self.verificar("etapa_" + nome).falhar("dados_invalidos_" + type(exc).__name__)
        self.hashes()
        self.relatorio["verificacoes"] = [v.resultado() for v in self.verificacoes]
        self.relatorio["avisos"] = self.avisos
        self.relatorio["concluido_em_utc"] = datetime.now(timezone.utc).isoformat()
        self.relatorio["estado"] = "falhou" if any(v.falhas for v in self.verificacoes) else "concluida_com_limites"
        return self.relatorio


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus", type=Path, required=True, help="Diretório da Camada A v1 (não será alterado).")
    parser.add_argument("--saida", type=Path, required=True, help="Novo JSON fora do corpus; recusa sobrescrever.")
    parser.add_argument("--obras-esperadas", type=int, default=19,
                        help="Quantidade e volumes 1..N esperados (padrão 19); 0 desabilita em fixtures/subconjuntos.")
    parser.add_argument("--consulta", default="inconsciente", help="Consulta FTS5 parametrizada de diagnóstico.")
    parser.add_argument("--modelo-esperado", default=MODELO_E5,
                        help="Identificação esperada (padrão: E5 multilingual large validado).")
    parser.add_argument("--revisao-esperada", default=REVISAO_E5,
                        help="SHA da revisão esperada; padrão é a revisão já validada no Mac.")
    parser.add_argument("--dimensao-esperada", type=int, default=DIMENSAO_E5,
                        help="Dimensão esperada (padrão: 1024). Não altera a matriz.")
    args = parser.parse_args(argv)
    raiz = args.corpus.expanduser().resolve()
    saida = args.saida.expanduser().resolve()
    if not raiz.is_dir():
        parser.error("--corpus deve ser um diretório existente; nenhum diretório será criado.")
    if saida.is_relative_to(raiz):
        parser.error("--saida deve ficar fora do corpus para preservar a política somente leitura.")
    if saida.exists() or args.saida.expanduser().is_symlink():
        parser.error("--saida já existe: escolha outro nome; o relatório nunca é sobrescrito.")
    if not saida.parent.is_dir():
        parser.error("O diretório pai de --saida deve existir.")
    if args.obras_esperadas < 0:
        parser.error("--obras-esperadas deve ser zero ou positivo.")
    if args.dimensao_esperada <= 0 or not re.fullmatch(r"[0-9a-f]{40}", args.revisao_esperada):
        parser.error("Contrato esperado inválido: dimensão positiva e revisão SHA de 40 caracteres são obrigatórias.")
    audit = Auditoria(raiz, args.obras_esperadas, args.consulta,
                      modelo_esperado=args.modelo_esperado, revisao_esperada=args.revisao_esperada,
                      dimensao_esperada=args.dimensao_esperada)
    relatorio = audit.executar()
    try:
        with saida.open("x", encoding="utf-8") as arquivo:
            json.dump(relatorio, arquivo, ensure_ascii=False, indent=2, allow_nan=False)
            arquivo.write("\n")
    except FileExistsError:
        parser.error("--saida foi criado por outro processo: não sobrescrito.")
    falhas = sum(sum(v.falhas.values()) for v in audit.verificacoes)
    print("Validação estrutural:", relatorio["estado"], "— ocorrências de falha:", falhas)
    print("Relatório:", str(saida))
    print("A correspondência semântica entre linhas de vetores e textos permanece não comprovada.")
    return 1 if falhas else 0


if __name__ == "__main__":
    sys.exit(main())
