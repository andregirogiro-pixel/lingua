"""Testes de falhas reais do auditor, sem modelos nem corpus de livros."""
from contextlib import redirect_stderr, redirect_stdout
import importlib.util
import io
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import unittest

import numpy as np

SPEC = importlib.util.spec_from_file_location("auditor", Path(__file__).with_name("auditar_camada_a.py"))
auditor = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(auditor)


def salvar_json(path, dados):
    path.write_text(json.dumps(dados, ensure_ascii=False), encoding="utf-8")


def fixture(raiz):
    """Duas obras, dois blocos e três fragmentos com vizinhança dentro da obra."""
    raiz.mkdir()
    (raiz / "textos_obras").mkdir()
    manifesto = {"schema": auditor.SCHEMA, "fragmentos": 3, "blocos": 2, "dimensao": 3,
                 "tokens_maximo": 512, "margem_tokens": 8,
                 "modelo": "intfloat/multilingual-e5-large", "revisao": "a" * 40,
                 "prefixo_passagens": "passage: ", "prefixo_consultas": "query: ",
                 "tipo_vetor": "float32", "normalizacao": "L2",
                 "vetores_arquivo": "vetores_e5.npy", "referencias_arquivo": "fragmentos.jsonl",
                 "pdf_zip_sha256": "b" * 64}
    salvar_json(raiz / "manifesto.json", manifesto)
    listas = {nome: [] for nome in auditor.REQUERIDOS}
    for n in range(1, 3):
        oid, sid, bid = f"obra-{n}", f"obra-{n}-sec-1", f"obra-{n}-b0"
        texto = "inconsciente início. Fim preservado." if n == 1 else "inconsciente segunda obra."
        titulo, titulo_secao = f"Obra {n}", "Seção"
        cabecalho = f"{titulo} — {titulo_secao}"
        obra = {"id": oid, "titulo": titulo, "volume_sugerido": n, "pdf_original": f"vol-{n}.pdf",
                "sha256_pdf": str(n) * 64, "paginas": 1, "texto_sha256": auditor.sha_texto(texto),
                "estado": "extraido_requer_conferencia_visual"}
        secao = {"id": sid, "obra_id": oid, "titulo": titulo_secao, "origem": "sumario_pdf_nao_conferido",
                 "pagina_inicio": 1}
        pagina = {"obra_id": oid, "pagina_pdf": 1, "texto": texto, "metodo": "pdf_texto",
                  "confianca_ocr": None, "inicio": 0, "fim": len(texto), "secao_id": sid}
        bloco = {"id": bid, "obra_id": oid, "secao_id": sid, "inicio": 0, "fim": len(texto),
                 "texto": texto, "sha256_texto": auditor.sha_texto(texto), "paginas": [1],
                 "papeis_provisorios": [], "conceitos_lexicais": []}
        for nome, registro in (("obras", obra), ("secoes", secao), ("paginas", pagina), ("blocos", bloco)):
            listas[nome].append(registro)
        partes = [texto[:14], texto[14:]] if n == 1 else [texto]
        pos = 0
        for indice, parte in enumerate(partes):
            fid = f"{bid}-f{indice}"
            fragmento = {"id": fid, "bloco_id": bid, "obra_id": oid, "secao_id": sid,
                         "ordem": indice, "inicio": pos, "fim": pos + len(parte), "texto": parte,
                         "tokens_entrada": 20, "cabecalho": cabecalho,
                         "entrada_sha256": auditor.sha_texto("passage: " + cabecalho + "\n" + parte),
                         "anterior_id": f"{bid}-f{indice - 1}" if indice else None,
                         "posterior_id": f"{bid}-f{indice + 1}" if indice + 1 < len(partes) else None,
                         "paginas": [1]}
            pos += len(parte)
            listas["fragmentos"].append(fragmento)
        (raiz / "textos_obras" / f"{oid}.txt").write_text(texto, encoding="utf-8")
    for nome, registros in listas.items():
        (raiz / f"{nome}.jsonl").write_text(
            "".join(json.dumps(r, ensure_ascii=False) + "\n" for r in registros), encoding="utf-8")
    salvar_json(raiz / "relatorio_qualidade.json", {"contagens": {k: len(v) for k, v in listas.items()}})
    np.save(raiz / "vetores_e5.npy", np.eye(3, dtype=np.float32))
    con = sqlite3.connect(raiz / "corpus.sqlite")
    con.executescript("""
    CREATE TABLE obras(id TEXT PRIMARY KEY,titulo TEXT,volume_sugerido INTEGER,pdf_original TEXT,
      sha256_pdf TEXT,paginas INTEGER,texto_sha256 TEXT,estado TEXT);
    CREATE TABLE secoes(id TEXT PRIMARY KEY,obra_id TEXT REFERENCES obras(id),titulo TEXT,
      origem TEXT,pagina_inicio INTEGER);
    CREATE TABLE paginas(obra_id TEXT REFERENCES obras(id),pagina_pdf INTEGER,metodo TEXT,
      confianca_ocr REAL,inicio INTEGER,fim INTEGER,PRIMARY KEY(obra_id,pagina_pdf));
    CREATE TABLE blocos(id TEXT PRIMARY KEY,obra_id TEXT REFERENCES obras(id),secao_id TEXT REFERENCES secoes(id),
      inicio INTEGER,fim INTEGER,texto TEXT,sha256_texto TEXT,paginas_json TEXT,
      papeis_provisorios_json TEXT,conceitos_lexicais_json TEXT);
    CREATE TABLE fragmentos(id TEXT PRIMARY KEY,bloco_id TEXT REFERENCES blocos(id),
      obra_id TEXT REFERENCES obras(id),secao_id TEXT REFERENCES secoes(id),ordem INTEGER,
      inicio INTEGER,fim INTEGER,anterior_id TEXT,posterior_id TEXT,cabecalho TEXT,texto TEXT,
      entrada_sha256 TEXT,tokens INTEGER);
    CREATE VIRTUAL TABLE fragmentos_fts USING fts5(fragmento_id UNINDEXED,cabecalho,texto,
      tokenize='unicode61 remove_diacritics 2');
    """)
    for nome, colunas in auditor.COLUNAS_SQL.items():
        for registro in listas[nome]:
            valores = [json.dumps(registro[campo], ensure_ascii=False) if coluna.endswith("_json") else registro[campo]
                       for coluna, campo in colunas]
            con.execute("INSERT INTO " + nome + "(" + ",".join(c for c, _ in colunas) + ") VALUES ("
                        + ",".join("?" for _ in valores) + ")", valores)
    for f in listas["fragmentos"]:
        con.execute("INSERT INTO fragmentos_fts VALUES (?,?,?)", (f["id"], f["cabecalho"], f["texto"]))
    con.commit()
    con.close()
    return listas


class TestAuditor(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.raiz = Path(self.temp.name) / "corpus"
        self.listas = fixture(self.raiz)

    def tearDown(self):
        self.temp.cleanup()

    def executar(self):
        return auditor.Auditoria(self.raiz, 0, "inconsciente", revisao_esperada="a" * 40,
                                  dimensao_esperada=3).executar()

    @staticmethod
    def falhas(relatorio):
        return {codigo for v in relatorio["verificacoes"] for codigo in v["falhas"]}

    def test_fixture_valida_e_corpus_intocado(self):
        antes = {str(p): auditor.sha_arquivo(p) for p in self.raiz.rglob("*") if p.is_file()}
        relatorio = self.executar()
        depois = {str(p): auditor.sha_arquivo(p) for p in self.raiz.rglob("*") if p.is_file()}
        self.assertEqual(relatorio["estado"], "concluida_com_limites")
        self.assertEqual(relatorio["etapa"], "validacao_estrutural")
        self.assertEqual(antes, depois)
        self.assertEqual(relatorio["ordem_linhas_declarada"]["amostra"][0]["indice"], 0)
        serialized = json.dumps(relatorio)
        self.assertNotIn(self.listas["blocos"][0]["texto"], serialized)
        self.assertTrue(all(a["conteudo_inalterado"] and a["sha256_antes"] == a["sha256_depois"]
                            for a in relatorio["baseline_arquivos_atual"]))

    def test_metadados_e5_divergentes_do_contrato_sao_rejeitados(self):
        manifesto_path = self.raiz / "manifesto.json"
        original = json.loads(manifesto_path.read_text())
        for campo, valor in (("modelo", "outro/modelo"), ("revisao", "b" * 40), ("dimensao", 4)):
            with self.subTest(campo=campo):
                manifesto = dict(original)
                manifesto[campo] = valor
                salvar_json(manifesto_path, manifesto)
                self.assertIn("metadado_divergente_do_contrato_e5_" + campo, self.falhas(self.executar()))

    def test_cli_aceita_contrato_e5_padrao_com_fixture_estrutural_valida(self):
        manifesto_path = self.raiz / "manifesto.json"
        manifesto = json.loads(manifesto_path.read_text())
        manifesto.update(revisao=auditor.REVISAO_E5, dimensao=auditor.DIMENSAO_E5)
        salvar_json(manifesto_path, manifesto)
        np.save(self.raiz / "vetores_e5.npy", np.eye(3, auditor.DIMENSAO_E5, dtype=np.float32))
        saida = Path(self.temp.name) / "cli_contrato_e5.json"
        with redirect_stdout(io.StringIO()):
            status = auditor.main(["--corpus", str(self.raiz), "--saida", str(saida), "--obras-esperadas", "0"])
        self.assertEqual(status, 0)
        self.assertEqual(json.loads(saida.read_text())["estado"], "concluida_com_limites")

    def test_hash_completo_detecta_mudanca_mesmo_com_tamanho_e_mtime_preservados(self):
        aud = auditor.Auditoria(self.raiz, 0, "inconsciente", revisao_esperada="a" * 40, dimensao_esperada=3)
        self.assertTrue(aud.carregar())
        arquivo = self.raiz / "blocos.jsonl"
        antes = arquivo.stat()
        conteudo = arquivo.read_text()
        trocado = conteudo.replace(self.listas["blocos"][0]["sha256_texto"], "0" * 64)
        self.assertEqual(len(conteudo), len(trocado))
        arquivo.write_text(trocado, encoding="utf-8")
        os.utime(arquivo, ns=(antes.st_atime_ns, antes.st_mtime_ns))
        self.assertEqual(arquivo.stat().st_size, antes.st_size)
        self.assertEqual(arquivo.stat().st_mtime_ns, antes.st_mtime_ns)
        aud.hashes()
        self.assertTrue(any("arquivo_conteudo_mudou_durante_auditoria" in v.falhas for v in aud.verificacoes))

    def test_paginacao_de_obra_deve_corresponder_a_quantidade_de_paginas(self):
        self.listas["obras"][0]["paginas"] = 2
        (self.raiz / "obras.jsonl").write_text(
            "".join(json.dumps(r) + "\n" for r in self.listas["obras"]), encoding="utf-8")
        self.assertIn("sequencia_paginas_incompleta", self.falhas(self.executar()))

    def test_secao_deve_comecar_em_pagina_existente(self):
        self.listas["secoes"][0]["pagina_inicio"] = 2
        (self.raiz / "secoes.jsonl").write_text(
            "".join(json.dumps(r) + "\n" for r in self.listas["secoes"]), encoding="utf-8")
        self.assertIn("secao_pagina_inexistente", self.falhas(self.executar()))

    def test_vetores_permutados_nao_fingem_identidade_semantica(self):
        np.save(self.raiz / "vetores_e5.npy", np.eye(3, dtype=np.float32)[::-1])
        relatorio = self.executar()
        self.assertEqual(relatorio["estado"], "concluida_com_limites")
        self.assertEqual(relatorio["ordem_linhas_declarada"]["identidade_semantica_vetor_texto"], "nao_comprovada")
        self.assertTrue(any("permutação" in limite for limite in relatorio["limites"]))

    def test_hash_textual_trocado_e_detectado(self):
        self.listas["blocos"][0]["sha256_texto"] = "0" * 64
        (self.raiz / "blocos.jsonl").write_text(
            "".join(json.dumps(r) + "\n" for r in self.listas["blocos"]), encoding="utf-8")
        self.assertIn("sha_texto_bloco_divergente", self.falhas(self.executar()))

    def test_normas_e_finitude_em_todas_as_linhas(self):
        vetores = np.eye(3, dtype=np.float32)
        vetores[-1] *= 2
        vetores[1, 1] = np.nan
        np.save(self.raiz / "vetores_e5.npy", vetores)
        falhas = self.falhas(self.executar())
        self.assertIn("norma_l2_divergente", falhas)
        self.assertIn("linha_nao_finita", falhas)

    def test_norma_invalidada_apos_primeiro_lote_e_detectada(self):
        # A contagem da matriz também está errada. Mesmo assim, verifica o último
        # lote e detecta a norma; não limita a inspeção às primeiras 300 linhas.
        vetores = np.zeros((600, 3), dtype=np.float32)
        vetores[:, 0] = 1
        vetores[-1, 0] = 2
        np.save(self.raiz / "vetores_e5.npy", vetores)
        relatorio = self.executar()
        falhas = self.falhas(relatorio)
        self.assertIn("shape_divergente", falhas)
        self.assertIn("norma_l2_divergente", falhas)
        verificado = next(v for v in relatorio["verificacoes"] if v["nome"] == "vetores_numpy_memmap")
        self.assertEqual(verificado["dados"]["linhas_conferidas"], 600)
        self.assertEqual(verificado["amostra_ids"]["norma_l2_divergente"], [599])

    def test_foreign_key_quebrada_e_detectada(self):
        con = sqlite3.connect(self.raiz / "corpus.sqlite")
        con.execute("UPDATE fragmentos SET bloco_id='ausente' WHERE id=?", (self.listas["fragmentos"][0]["id"],))
        con.commit()
        con.close()
        self.assertIn("foreign_key_invalida", self.falhas(self.executar()))

    def test_sqlite_ausente_nao_e_criado(self):
        (self.raiz / "corpus.sqlite").unlink()
        self.assertIn("sqlite_ausente_nao_criado", self.falhas(self.executar()))
        self.assertFalse((self.raiz / "corpus.sqlite").exists())

    def test_fts_conteudo_ou_ids_divergentes(self):
        con = sqlite3.connect(self.raiz / "corpus.sqlite")
        con.execute("UPDATE fragmentos_fts SET texto='trocado' WHERE fragmento_id=?", (self.listas["fragmentos"][0]["id"],))
        con.commit()
        con.close()
        self.assertIn("fts_conteudo_divergente", self.falhas(self.executar()))

    def test_fts5_com_tokenizador_diferente_do_contrato_e_rejeitado(self):
        con = sqlite3.connect(self.raiz / "corpus.sqlite")
        linhas = list(con.execute("SELECT fragmento_id,cabecalho,texto FROM fragmentos_fts"))
        con.execute("DROP TABLE fragmentos_fts")
        con.execute("CREATE VIRTUAL TABLE fragmentos_fts USING fts5("
                    "fragmento_id UNINDEXED,cabecalho,texto, tokenize='unicode61 remove_diacritics 0')")
        con.executemany("INSERT INTO fragmentos_fts VALUES (?,?,?)", linhas)
        con.commit()
        con.close()
        relatorio = self.executar()
        self.assertIn("fts_tokenizador_incompativel_v1", self.falhas(relatorio))
        # A consulta sem acento funciona apesar do tokenizador incorreto.
        verificado = next(v for v in relatorio["verificacoes"] if v["nome"] == "sqlite_somente_leitura_e_fts")
        self.assertTrue(verificado["dados"]["consulta_lexical"]["resultados"])

    def test_fts5_ddl_aceita_case_e_espacos_no_contrato(self):
        con = sqlite3.connect(self.raiz / "corpus.sqlite")
        linhas = list(con.execute("SELECT fragmento_id,cabecalho,texto FROM fragmentos_fts"))
        con.execute("DROP TABLE fragmentos_fts")
        con.execute("create VIRTUAL table fragmentos_fts using FTS5("
                    "fragmento_id UNINDEXED,cabecalho,texto, tokenize = 'unicode61   remove_diacritics  2')")
        con.executemany("INSERT INTO fragmentos_fts VALUES (?,?,?)", linhas)
        con.commit()
        con.close()
        self.assertEqual(self.executar()["estado"], "concluida_com_limites")

    def test_vizinho_de_outra_obra(self):
        self.listas["fragmentos"][0]["posterior_id"] = self.listas["fragmentos"][-1]["id"]
        (self.raiz / "fragmentos.jsonl").write_text(
            "".join(json.dumps(r) + "\n" for r in self.listas["fragmentos"]), encoding="utf-8")
        self.assertIn("vizinho_inexistente_ou_outra_obra", self.falhas(self.executar()))

    def test_offset_fragmento_com_lacuna_e_detectado(self):
        self.listas["fragmentos"][1]["inicio"] += 1
        (self.raiz / "fragmentos.jsonl").write_text(
            "".join(json.dumps(r) + "\n" for r in self.listas["fragmentos"]), encoding="utf-8")
        self.assertIn("ordem_ou_offset_fragmento_divergente", self.falhas(self.executar()))

    def test_jsonl_ausente_e_registrado_sem_criar(self):
        (self.raiz / "obras.jsonl").unlink()
        self.assertIn("arquivo_ausente", self.falhas(self.executar()))
        self.assertFalse((self.raiz / "obras.jsonl").exists())

    def test_id_jsonl_duplicado_e_detectado(self):
        with (self.raiz / "fragmentos.jsonl").open("a", encoding="utf-8") as destino:
            destino.write(json.dumps(self.listas["fragmentos"][0]) + "\n")
        self.assertIn("id_duplicado", self.falhas(self.executar()))

    def test_caminho_manifesto_fora_raiz_e_recusado(self):
        manifesto = json.loads((self.raiz / "manifesto.json").read_text())
        manifesto["vetores_arquivo"] = "../vetores.npy"
        salvar_json(self.raiz / "manifesto.json", manifesto)
        self.assertIn("caminho_fora_do_corpus", self.falhas(self.executar()))

    def test_schema_incompativel_fail_explicito(self):
        manifesto = json.loads((self.raiz / "manifesto.json").read_text())
        manifesto["schema"] = "camada_a_freud.v2"
        salvar_json(self.raiz / "manifesto.json", manifesto)
        self.assertIn("schema_nao_suportado", self.falhas(self.executar()))

    def test_contagens_fixas_apenas_no_original(self):
        manifesto = json.loads((self.raiz / "manifesto.json").read_text())
        manifesto["pdf_zip_sha256"] = auditor.PACOTE_ORIGINAL_SHA
        salvar_json(self.raiz / "manifesto.json", manifesto)
        self.assertIn("contagem_pacote_original_divergente_fragmentos", self.falhas(self.executar()))

    def test_saida_exclusiva_fora_corpus_e_exit_nonzero(self):
        saida = Path(self.temp.name) / "relatorio.json"
        (self.raiz / "corpus.sqlite").unlink()
        with redirect_stdout(io.StringIO()):
            status = auditor.main(["--corpus", str(self.raiz), "--saida", str(saida), "--obras-esperadas", "0"])
        self.assertEqual(status, 1)
        original = saida.read_bytes()
        with redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            auditor.main(["--corpus", str(self.raiz), "--saida", str(saida), "--obras-esperadas", "0"])
        self.assertEqual(saida.read_bytes(), original)
        with redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            auditor.main(["--corpus", str(self.raiz), "--saida", str(self.raiz / "saida.json")])
        self.assertFalse((self.raiz / "saida.json").exists())


if __name__ == "__main__":
    unittest.main()
