# Etapa 1 — auditoria do acervo e registro das fontes

Este pacote contém somente o trabalho da etapa 1. O exame dos textos recebidos foi concluído e as decisões foram registradas. A validação estrutural do corpus real ainda depende da execução local: o SQLite, os JSONLs completos e a matriz E5 não estão disponíveis neste ambiente. A etapa 1 permanece **pendente de validação estrutural**, antes de conversar sobre a etapa 2.

## O que está verificado

- O `obras.zip` representa os volumes 1–19; os 19 arquivos `__MACOSX/._*` são auxiliares do macOS.
- O TXT antigo do volume 19 continua defeituoso: as páginas 5–216 correspondem exatamente à extração nativa antiga, incluindo duplicações e caracteres trocados.
- O PDF alternativo do volume 19 tem extração tecnicamente consistente nas amostras. Sua preparação textual preserva 244 páginas, 49 entradas do sumário e seleciona as páginas PDF 10–232 para a futura busca. A conferência editorial integral ainda não foi feita.
- Os volumes 1 e 6 exigem tratamento de caracteres por fonte. `U+009F` corresponde a `fl` em exemplos do volume 1 e a `Ê` em quatro cabeçalhos do volume 6.
- Os volumes 4, 5 e 7 contêm publicidade de outros livros. Ela deve ser identificada para a busca, preservando o material original.
- Os outros volumes não têm aprovação editorial integral apenas por não apresentarem esses marcadores.

Consulte `DECISOES_TEXTUAIS.md` e `auditoria_obras_zip/`. A preparação separada da fonte nova está em `volume19_fonte_v2/`; a avaliação técnica do PDF está em `qualidade_volume19_alternativo/`. Nenhuma correção textual foi aplicada ao corpus existente. Nenhum novo embedding foi produzido.

## Execução no Mac

Descompacte o pacote em Downloads. Para abrir o ZIP pelo terminal, se o Safari apenas salvou o arquivo sem descompactar:

```bash
unzip "$HOME/Downloads/etapa1_auditoria.zip" -d "$HOME/Downloads"
```

Depois execute:

```bash
bash "$HOME/Downloads/etapa1_auditoria/auditar_no_mac.sh"
```

O script usa explicitamente o Python já validado:

`/Users/rodrigodevellis/lingua-agente/instance/venv-agente-e5-intel/bin/python`

O caminho padrão do corpus é o indicado anteriormente:

`/Users/rodrigodevellis/Documents/Qoder/2026-10-11/a276916c/camada_a`

Se a pasta original estiver em outro lugar, informe seu caminho:

```bash
bash "$HOME/Downloads/etapa1_auditoria/auditar_no_mac.sh" \
  "/caminho/da/pasta/original/camada_a"
```

O alvo é o corpus original de esquema `camada_a_freud.v1`. A conversão experimental `bancada_camada_a` e a preparação textual nova do volume 19 não substituem esse alvo.

Não é necessário ativar outra `.venv` nem configurar o cache E5: a auditoria importa apenas NumPy, não carrega modelos. Se a verificação inicial falhar, preserve o erro para diagnóstico em vez de atualizar todas as dependências.

O relatório `auditoria_camada_a_*.json` será criado em Downloads. A saída deve ficar fora do corpus; arquivos existentes não são sobrescritos. O processo lê SQLite e vetores, confere todas as linhas e não modifica o acervo.

Envie somente esse JSON para analisar os resultados e fechar a etapa 1. Um código de saída 1 significa que foram encontradas falhas de auditoria; o relatório continua sendo necessário para entender quais. Um erro de caminho ou ambiente pode impedir a criação do relatório.

## Critérios para encerramento

Conferir contagens, volumes, IDs, cobertura de texto, offsets, páginas, seções, vizinhos, hashes, correspondência entre JSONLs e SQLite, contrato FTS5, configuração E5 e formato/finitude/norma L2 de todas as linhas da matriz. Explicar as diferenças encontradas e registrar as decisões de qualidade textual.

Os hashes atuais registram o estado observado. Sem evidência confiável da geração original, esses testes não provam historicamente que cada vetor foi calculado sobre o texto da sua linha. Esse limite permanecerá no parecer final, mesmo se a auditoria estrutural passar.

Uma conclusão de auditoria pode conter fontes rejeitadas e correções futuras registradas. O corpus inteiro não deve ser apresentado como aprovado apenas porque a estrutura passa. A etapa 1 não gera a nova versão vetorial do volume 19 nem conecta o aplicativo; essas ações pertencem às etapas seguintes.

## Ferramentas verificadas

O auditor revisado passou em 23 testes com corpora sintéticos. O lançador foi conferido quanto ao Python explícito, caminhos com espaços, criação do relatório com retorno de falhas, preservação dos arquivos do corpus, recusa de sobrescrita e diagnóstico de pasta ausente. Esses resultados estão em `VALIDACAO_FERRAMENTAS.json` e não substituem a execução sobre o acervo real.
