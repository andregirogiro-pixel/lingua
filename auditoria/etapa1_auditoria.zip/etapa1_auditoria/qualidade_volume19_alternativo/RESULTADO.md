# Qualidade da nova versão do volume 19

Arquivo recebido: `Freud 19 - Moisés e o monoteísmo, Compêndio de psicanálise e -- Freud, Sigmund -- 2018 -- Companhia das Letras -- 90b2a0b91e4e4f1edd0113c64e58ccb7 -- Anna’s Archive.pdf`.

SHA256: `1b4ea213276f48f77b53349109c9d9a352ade2225de43aa50765225db5c0a3ba`.

## Parecer

Esta versão tem qualidade técnica de extração substancialmente superior à do PDF anterior. O corpo do livro é extraível como texto nativo legível. Recomenda-se utilizá-la como candidata para uma nova versão do volume 19 no corpus, após a validação de conteúdo e referências. Nenhum corpus foi substituído nesta análise.

## Evidência

| Item | Anterior | Nova versão |
| --- | --- | --- |
| Páginas PDF | 216 | 244 |
| Tamanho | 5.390.214 bytes | 2.393.669 bytes |
| Fontes | 381 fontes anônimas/subconjuntos | 7 fontes nomeadas |
| Extração examinada | Caracteres incorretos e desenhos duplicados | Texto português legível |
| Sumário navegável | Ausente | 49 entradas hierárquicas |

Foi extraído texto de todas as páginas da nova versão. Não apareceram caracteres de substituição U+FFFD nem controles inadequados U+009E, U+0085, U+009F ou U+0086. A mediana da triagem por palavras frequentes portuguesas foi 475,61 ocorrências por mil tokens em páginas com ao menos 50 palavras; no anterior, foi zero. Essa métrica evidencia plausibilidade linguística, não integridade editorial.

PyMuPDF e pypdf concordaram na sequência de caracteres das páginas 5, 11, 12, 30, 80, 120, 159, 180, 200, 219, 234 e 244 após desconsiderar espaços e quebras de linha. Nas mesmas 12 amostras não foram detectados caracteres duplicados por desenho sobreposto.

As imagens das páginas 1, 11, 216 e 234 foram conferidas. A página 1 é capa em imagem, a página 11 apresenta prosa legível, a página 216 confirma o título “A cisão do eu no processo de defesa” e a página 234 inicia publicidade de outro volume. Texto visual e extraído são coerentes nessas amostras.

## Limites e referências

- Páginas 1–4 sem texto nativo. A capa em imagem foi confirmada na página 1; ausência de extração nessas páginas não indica perda do corpo do livro.
- Conteúdo do volume até a página PDF 232; créditos/ficha na 233 e publicidade nas 234–244. O material publicitário precisa ficar identificado separadamente e fora da busca de passagens do volume 19.
- A paginação mudou. “A cisão do eu no processo de defesa” está na página 216, em lugar da página 200 no arquivo anterior. Não copiar os intervalos de seção/página anteriores.
- A extração nativa do corpo não requer OCR nem o decifrador experimental. Isso não comprova ausência absoluta de erros editoriais, passagens faltantes ou problemas de ordenação em todas as páginas; a conferência foi estrutural e amostral.
- A versão possui outra identidade de arquivo. Qualquer integração deve preservar proveniência e versões anteriores. Embeddings vinculados ao texto defeituoso do PDF anterior não podem ser apresentados como embeddings deste novo texto. Uma incorporação posterior exige índices e vetores correspondentes à fonte correta.

Não foram executados OCR, embeddings, alterações do PDF ou aplicação de mudanças ao projeto.
