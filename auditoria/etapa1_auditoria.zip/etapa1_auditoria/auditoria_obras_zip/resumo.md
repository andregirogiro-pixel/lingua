# Auditoria estática de obras.zip

**O ZIP contém os 19 volumes, mas os textos não estão suficientemente limpos para aprovação integral.** O volume 19 permanece corrompido e duplicado; os volumes 1 e 6 conservam 954 ocorrências dos quatro controles Unicode já sinalizados; os volumes 4, 5 e 7 conservam anúncios de outras obras.

- Conteúdo: 19 TXT UTF-8 e 19 AppleDouble do macOS. Nenhum volume 1..19 falta; nenhuma identificação repetida.
- Tamanho descompactado dos TXT: 12,813,897 bytes. A representação dos 19 volumes não certifica que cada obra esteja completa.
- Nenhum U+FFFD foi encontrado. Isso não demonstra ausência de corrupção: o volume 19 não tem U+FFFD nem os quatro controles sinalizados, mas o corpo apresenta texto cifrado/ininteligível.
- Volume 1: U+009E=743, U+0085=15, U+009F=189, U+0086=3: 950 ocorrências desses controles. Há também um U+0006.
- Volume 6: quatro U+009F, além de um U+001E. As quatro ocorrências U+009F estão em “TR\u009fS ENSAIOS” e representam **Ê, não fl**. A substituição depende da fonte/contexto; não aplicar troca global por ligaduras. Total nos 19 TXT: 954 ocorrências desses controles e 2 outros controles não usuais.
- Volume 19 (`obra-3b8627dba63512a2.txt`): 5.713 repetições de linhas consecutivas não vazias iguais, de pelo menos 20 caracteres. A capa está legível; o corpo contém cabeçalhos e prosa corrompidos. O indicador não foi usado para remover texto.
- Volumes 4, 5 e 7: dez ocorrências de “Compre agora e leia” em cada volume (30 no total), acompanhadas de anúncios alheios a Freud no fim dos arquivos.
- Capas/folhas de rosto, sumários, edição, créditos e links editoriais permanecem. O rótulo “limpo” precisa especificar quais dessas partes deveriam ter sido retiradas.
- O SHA256 do volume 5 coincide com o hash do anexo anterior fornecido pela auditoria principal: não houve alteração nesse TXT.
- O pacote contém texto, sem manifesto e sem metadados estruturados de páginas/fragmentos/vetores. Alguns volumes têm marcas n/total no texto; isso não constitui mapa verificável de páginas PDF ou impressas.

## Inventário por conteúdo

| Volume | Arquivo / ID | Título | Controles Unicode | Linhas iguais consecutivas ≥20 | Chamadas publicitárias | Marcas n/total |
|---|---|---|---:|---:|---:|---:|
| 1 | `obra-78489fd260ea2652` | Textos pré-psicanalíticos (1886–1896) | 950 | 0 | 0 | 0 |
| 2 | `obra-08fcc68f97f2e734` | Estudos sobre a histeria (1893–1895), em coautoria com Josef Breuer | 0 | 0 | 0 | 0 |
| 3 | `obra-983c053e2b99ca99` | Primeiros escritos psicanalíticos (1893–1899) | 0 | 0 | 0 | 0 |
| 4 | `obra-d2e15be704adcec1` | A interpretação dos sonhos (1900) | 0 | 1 | 10 | 0 |
| 5 | `obra-cb69c2a540a9a597` | Psicopatologia da vida cotidiana e Sobre os sonhos (1901) | 0 | 0 | 10 | 0 |
| 6 | `obra-c4bf13c571ed349c` | Três ensaios sobre a teoria da sexualidade, Análise fragmentária de uma histeria (O caso Dora) e outros textos (1901–1905) | 4 | 0 | 0 | 0 |
| 7 | `obra-09c5629d767f7dde` | O chiste e sua relação com o inconsciente (1905) | 0 | 0 | 10 | 0 |
| 8 | `obra-d398eb81592ffb13` | O delírio e os sonhos na Gradiva, Análise da fobia de um garoto de cinco anos e outros textos (1906–1909) | 0 | 0 | 0 | 0 |
| 9 | `obra-9b9b7bc6e87cd0be` | Observações sobre um caso de neurose obsessiva (O homem dos ratos), Uma recordação de infância de Leonardo da Vinci e outros textos (1909–1910) | 0 | 0 | 0 | 298 |
| 10 | `obra-bc0f8d49e6035891` | Observações psicanalíticas sobre um caso de paranoia relatado em autobiografia (O caso Schreber), Artigos sobre técnica e outros textos (1911–1913) | 0 | 0 | 0 | 227 |
| 11 | `obra-372dafa958fd6772` | Totem e tabu, Contribuição à história do movimento psicanalítico e outros textos (1912–1914) | 0 | 0 | 0 | 289 |
| 12 | `obra-20a3cb388cbb78cd` | Introdução ao narcisismo, Ensaios de metapsicologia e outros textos (1914–1916) | 0 | 0 | 0 | 193 |
| 13 | `obra-669b2075a44a05fc` | Conferências introdutórias à psicanálise (1916–1917) | 0 | 0 | 0 | 484 |
| 14 | `obra-10a534bac5d81eae` | História de uma neurose infantil (O homem dos lobos), Além do princípio do prazer e outros textos (1917–1920) | 0 | 0 | 0 | 277 |
| 15 | `obra-281b0b52dc9fb0af` | Psicologia das massas e análise do Eu e outros textos (1920–1923) | 0 | 0 | 0 | 276 |
| 16 | `obra-c04f37fcf4457adc` | O Eu e o Id, Autobiografia e outros textos (1923–1925) | 0 | 0 | 0 | 286 |
| 17 | `obra-d23f86e2828f3365` | Inibição, sintoma e angústia, O futuro de uma ilusão e outros textos (1926–1929) | 0 | 0 | 0 | 285 |
| 18 | `obra-da23519f73b81594` | O mal-estar na civilização, Novas conferências introdutórias e outros textos (1930–1936) | 0 | 0 | 0 | 247 |
| 19 | `obra-3b8627dba63512a2` | Moisés e o monoteísmo, Compêndio de psicanálise e outros textos (1937–1939) | 0 | 5713 | 0 | 0 |

## Limites da análise

Leitura estática e contagens automáticas com amostras curtas. Nenhum livro foi certificado linha a linha; nenhuma comparação integral com PDF foi feita nesta auditoria independente. A única repetição longa encontrada no volume 4 pode ser repetição literária legítima. Os demais 18 textos precisam ser verificados; a ausência de marcadores não equivale à aprovação.

Os arquivos originais não foram alterados e nenhum script do ZIP, OCR ou geração de embeddings foi executado. O inventário inclui hashes, contagens, referências de linhas/offsets em caracteres e amostras breves para conferência.

Parecer: reutilização é possível após auditoria e reparação versionada; este ZIP não demonstra limpeza concluída e não substitui o corpus estruturado da Camada A.
