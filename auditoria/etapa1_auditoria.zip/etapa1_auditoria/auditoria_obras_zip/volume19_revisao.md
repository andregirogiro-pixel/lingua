# Revisão do TXT do volume 19 em obras.zip

## Resultado

**O volume 19 deste ZIP continua com o corpo ilegível e duplicado. Não foi decifrado nem substituído pelo texto da fonte nova.** As duas capas legíveis no início não representam a qualidade do restante do arquivo.

Esta revisão foi somente de leitura dos originais. Não executou OCR, não gerou embeddings, não modificou o PDF, os TXT originais ou o corpus, e não implementou integração. O único arquivo criado foi este relatório.

## Arquivos examinados

| Item | Identificação |
|---|---|
| Pacote enviado | `/workspace/attachments/8f61e3ba-e89c-4ff0-9310-bb875e3dbe7f/obras.zip` |
| TXT analisado | Entrada `obra-3b8627dba63512a2.txt`, 1.134.082 bytes, UTF-8 |
| SHA-256 do TXT | `8f99f8bf444a4fb6936083c0dd001723957759e983d7d6b46f0933ac76c0a918` |
| Fonte PDF anterior | `/workspace/attachments/54ab49a8-354c-46ef-ae8a-7faff735e46b/Freud-Obras-Completas-Volume-19.pdf`, 216 páginas |
| SHA-256 do PDF anterior | `3b8627dba63512a241a8e135e743d882d4f0b60aad65b9caff7c204a09aba5ee` |
| Fonte PDF nova | PDF de 244 páginas enviado em `/workspace/attachments/948a37ee-e743-4a15-aaa8-577e1a99cc6b/` |
| SHA-256 do PDF novo | `1b4ea213276f48f77b53349109c9d9a352ade2225de43aa50765225db5c0a3ba` |
| Texto preparado da fonte nova | `/workspace/scratch/integracao_camada_a/volume19_fonte_v2/texto_volume19.txt` |
| SHA-256 do texto preparado | `ab3e323c1fbcd5a89b9e8de7669d6a7e0948558f995cdee11b671ff960be4606` |

A entrada `__MACOSX/._obra-3b8627dba63512a2.txt` possui 305 bytes e é metadado AppleDouble; não foi tratada como texto da obra.

## Prova direta da origem e da ausência de limpeza do corpo

Foi reconstruída, somente em memória, a extração nativa do PDF anterior. Em cada página, o método utilizado foi:

```python
blocos = pagina.get_text("blocks", sort=True)
texto_pagina = "\n\n".join(
    bloco[4].rstrip("\n") for bloco in blocos if bloco[6] == 0
)
```

As páginas PDF 5–216 foram concatenadas com `"\n\n"`. O início desse resultado ocorre no **offset 343**, contado em pontos de código Unicode Python, no TXT do ZIP. A comparação seguinte retornou **True**:

```python
texto_zip[343:] == "\n\n".join(textos_paginas[4:])
```

São **1.092.277 caracteres iguais, incluindo espaços, quebras e duplicações**. O SHA-256 desse corpo reconstruído é `8d70b9846617384bb44322764db0bfa2a036fc7b395b319a41ca542efbb6345a`.

Assim, todo o restante do TXT após os 343 caracteres iniciais corresponde exatamente à extração nativa defeituosa do PDF antigo. Esta prova é mais forte do que inferir a origem pelo nome `obra-3b8627dba63512a2` ou pela taxa lexical. O prefixo contém duas versões da capa legível; esta revisão não reexecutou o OCR que pode ter produzido esse prefixo.

## Métricas comparativas

| Métrica | TXT do ZIP | Texto preparado da fonte nova |
|---|---:|---:|
| Bytes UTF-8 | 1.134.082 | 557.922 |
| Caracteres Unicode | 1.092.620 | 537.994 |
| Tokens de letras | 196.096 | 86.930 |
| Tokens pertencentes à lista lexical de referência | 180 | 40.958 |
| Ocorrências da lista por 1.000 tokens | 0,918 | 471,161 |
| Linhas não vazias | 16.185 | 7.680 |
| Pares consecutivos de linhas idênticas | 5.902 | 0 |
| Caracteres de substituição `U+FFFD` | 0 | 0 |

Método lexical: tokens obtidos com `r"[^\W\d_]+"`, convertidos com `casefold()`, e comparados à lista `FUNCTION_WORDS` de `ab_consultas/auditoria_obras.py` do pacote de revisão anterior. A lista contém palavras frequentes do português, incluindo algumas palavras de conteúdo. A taxa é um indicador de plausibilidade, não prova de integridade editorial. Foram incluídos tokens de uma letra. A mediana por bloco relatada na auditoria antiga é uma métrica diferente da taxa global acima.

Método de duplicação: retirar linhas vazias, reduzir espaços internos e comparar cada linha com a seguinte. As 5.902 ocorrências são **pares consecutivos**, não uma contagem de parágrafos ou páginas duplicados. Esse teste também deixa de contar cópias sobrepostas que a extração divide de maneira diferente.

Os tokens mais frequentes do TXT defeituoso são `g`, `ki`, `j`, `qui`, `i`, `kj`, `si`, `màj`, `kg` e `ì`; no texto preparado, são `de`, `a`, `que`, `o`, `e`, `se`, `do`, `não`, `da` e `é`. A ausência de `U+FFFD` em ambos mostra por que uma verificação limitada a caracteres Unicode inválidos não detecta este problema.

## Exemplos curtos e cotejo

Na página 11 do PDF anterior, e duas vezes no TXT do ZIP, aparece:

> `Qrlvgr uc pjvj kj ejcic`

Na página 11 do PDF novo, e uma vez no texto preparado, a passagem começa:

> `Privar um povo do homem`

Contagens no TXT enviado: `Qrlvgr uc pjvj` = 2; `Privar um povo` = 0; `Moisés` = 2, apenas no material inicial legível. No texto preparado: `Qrlvgr uc pjvj` = 0; `Privar um povo` = 1; `Moisés` = 234.

O sumário do TXT do ZIP começa com `PYCÇ_L` / `PYCÇ_LJ`, enquanto a página 5 do PDF novo extrai `SUMÁRIO`. A página 216 da fonte nova apresenta corretamente **A CISÃO DO EU NO PROCESSO DE DEFESA**. O ZIP continua contendo o título cifrado, inclusive nas ocorrências do sumário; ele não fornece uma correção textual desse título.

Como conferência adicional, os textos integrais das páginas antigas 5, 11, 12, 110, 159, 189, 200 e 216 foram localizados no TXT depois de retirar espaços. A comparação exata do corpo completo, descrita acima, já confirma essas correspondências sem depender desta normalização adicional.

## Limites

- Foi examinado somente o volume 19 neste relatório; ele não classifica os outros 18 TXT do ZIP.
- A fonte nova e o texto preparado possuem paginação e recorte diferentes. O preparado reúne texto nativo das páginas PDF **10–232**, preservando o texto retornado pela biblioteca; não inclui capas, sumário ou publicidade das páginas 234–244. Por isso os totais de tamanho/tokens não devem ser interpretados como prova de igualdade editorial entre os arquivos.
- O texto preparado ainda tem `pronto_para_busca: false`, `vetores_gerados: false` e `indices_gerados: false` em seu manifesto. Sua melhor qualidade lexical não significa integração pronta.
- Não foi feita conferência editorial integral nem comparação visual de cada passagem. A revisão anterior da fonte nova comprovou, em 12 amostras, concordância dos caracteres entre PyMuPDF e pypdf e ausência de duplicação sobreposta; isso não exclui omissões que já existam na própria fonte.
- Nenhum embedding foi recalculado ou removido. Vetores da fonte anterior não passam a representar a fonte nova por renomear ou substituir um TXT.

## Recomendação

**Não usar o volume 19 deste ZIP como texto limpo nem como entrada de novos embeddings.** Preservá-lo como artefato da extração antiga, identificado pelo hash acima. Para uma futura atualização, utilizar a preparação versionada da fonte nova, conferir seções/páginas e referências com a nova paginação e gerar os artefatos específicos dessa versão em etapa própria. Preservar as versões anteriores e os embeddings existentes enquanto a nova versão é validada.

Não é necessário tentar decifrar este TXT para demonstrar o problema: a igualdade exata com a extração antiga estabelece que o corpo ainda não recebeu a correção esperada.
