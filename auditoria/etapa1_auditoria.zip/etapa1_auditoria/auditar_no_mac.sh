#!/bin/bash
# Auditoria estrutural com o Python que já funcionou no Mac do projeto.
set -euo pipefail

PASTA_AUDITOR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_AUDITOR="${PYTHON_AUDITOR:-/Users/rodrigodevellis/lingua-agente/instance/venv-agente-e5-intel/bin/python}"
CORPUS_AUDITOR="${1:-/Users/rodrigodevellis/Documents/Qoder/2026-10-11/a276916c/camada_a}"
RELATORIO_AUDITOR="${2:-$HOME/Downloads/auditoria_camada_a_$(date +%Y%m%d_%H%M%S)_$$.json}"

if [[ ! -x "$PYTHON_AUDITOR" ]]; then
  printf 'Python não encontrado ou sem permissão de execução: %s\n' "$PYTHON_AUDITOR" >&2
  exit 2
fi
if [[ ! -d "$CORPUS_AUDITOR" ]]; then
  printf 'Pasta do corpus não encontrada: %s\n' "$CORPUS_AUDITOR" >&2
  printf 'Informe o caminho da pasta original camada_a como primeiro argumento.\n' >&2
  exit 2
fi

"$PYTHON_AUDITOR" -c 'import sys; assert sys.version_info >= (3, 10), "Requer Python 3.10+"; import numpy; print("Python:", sys.executable); print("NumPy:", numpy.__version__)'

set +e
"$PYTHON_AUDITOR" "$PASTA_AUDITOR/ferramentas/auditar_camada_a.py" \
  --corpus "$CORPUS_AUDITOR" \
  --saida "$RELATORIO_AUDITOR"
CODIGO_AUDITOR=$?
set -e

if [[ -f "$RELATORIO_AUDITOR" ]]; then
  printf '\nEnvie o relatório JSON para concluir a etapa 1: %s\n' "$RELATORIO_AUDITOR"
fi
exit "$CODIGO_AUDITOR"
