"""Contrato de leitura da Camada A com o Agente Analista, sem busca ou rede."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

import numpy as np

from agente_analista.camada_a import (
    CorpusCamadaA, ErroContratoCamadaA, OBRA_19_ANTIGA, abrir_camada_a,
)
from agente_analista.corpus import ErroCorpus
from agente_analista.entrada import validar_relato
from agente_analista.importacao import conferir_compatibilidade
from agente_analista.ligacoes import _fontes, _validar_ligacao
from agente_analista.tests.test_agente_analista_camada_a_core import criar_fixture


class AdaptadorCamadaATests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.pasta = Path(self.tmp.name)
        self.originais = criar_fixture(self.pasta)

    def abrir(self):
        corpus = abrir_camada_a(self.pasta)
        self.addCleanup(corpus.close)
        return corpus

    def test_conserva_todos_ids_ordem_linhas_e_matriz_original(self):
        esperado = np.load(self.pasta / "vetores_e5.npy")
        corpus = self.abrir()
        self.assertIsInstance(corpus, CorpusCamadaA)
        self.assertIsInstance(corpus.vetores, np.memmap)
        self.assertFalse(corpus.vetores.flags.writeable)
        self.assertEqual(corpus.vetores.mode, "r")
        self.assertEqual(corpus.vetores.shape, (len(self.originais), 1024))
        np.testing.assert_array_equal(corpus.vetores, esperado)
        self.assertEqual([f["id"] for f in corpus.fragmentos], [f["id"] for f in self.originais])
        self.assertEqual(corpus.indice_por_id, {f["id"]: i for i, f in enumerate(self.originais)})
        for f in corpus.fragmentos:
            self.assertIs(corpus.por_id[f["id"]], f)

    def test_fragmentos_preservam_cabecalho_texto_hashes_offsets_e_vizinhos(self):
        corpus = self.abrir()
        for original, f in zip(self.originais, corpus.fragmentos):
            self.assertEqual(f["original"], original)
            for campo in ("id", "bloco_id", "obra_id", "secao_id", "cabecalho", "texto",
                          "inicio", "fim", "tokens_entrada", "entrada_sha256", "anterior_id", "posterior_id"):
                self.assertEqual(f[campo], original[campo])
            self.assertEqual(f["obra"], original["obra_id"])
            self.assertEqual(f["fragmento_no_bloco"], original["ordem"])
            self.assertEqual(f["texto_origem_sha256"], corpus.blocos[f["bloco_id"]]["sha256_texto"])
            entrada = "passage: " + f["cabecalho"] + "\n" + f["texto"]
            self.assertEqual(hashlib.sha256(entrada.encode()).hexdigest(), f["entrada_sha256"])
            self.assertEqual(corpus.blocos[f["bloco_id"]]["texto"][f["inicio"]:f["fim"]], f["texto"])

    def test_paginas_precisas_sao_separadas_dos_metadados_originais(self):
        corpus = self.abrir()
        primeiro, segundo = corpus.fragmentos[:2]
        self.assertEqual(primeiro["paginas"], [1])
        self.assertEqual(segundo["paginas"], [2])
        self.assertEqual(primeiro["paginas_origem"], [1, 2])
        self.assertEqual(segundo["original"]["paginas"], [1, 2])
        bloco = corpus.blocos[primeiro["bloco_id"]]
        self.assertEqual(bloco["referencia"]["paginas"], [1, 2])
        self.assertTrue(bloco["referencia"]["atravessa_secoes"])
        self.assertIn("numeração impressa não conferida", bloco["referencia"]["nota_paginas"])

    def test_titulo_referencia_vem_da_obra_e_nao_do_cabecalho_truncado(self):
        titulo_completo = "Título completo que não cabe no cabeçalho " * 8
        con = sqlite3.connect(self.pasta / "corpus.sqlite")
        con.execute("UPDATE obras SET titulo=? WHERE id=?", (titulo_completo, "obra-a"))
        con.commit()
        con.close()
        corpus = self.abrir()
        bloco = corpus.blocos[self.originais[0]["bloco_id"]]
        self.assertEqual(bloco["referencia"]["obra"], titulo_completo)
        self.assertEqual(corpus.fragmentos[0]["cabecalho"], self.originais[0]["cabecalho"])

    def test_volume19_antigo_e_marcado_sem_excluir_qualquer_linha(self):
        corpus = self.abrir()
        antigos = [f for f in corpus.fragmentos if f["obra_id"] == OBRA_19_ANTIGA]
        corrigidos = [f for f in corpus.fragmentos if f["obra_id"] == "obra-v19-corrigida"]
        self.assertEqual(len(corpus.fragmentos), len(self.originais))
        self.assertEqual(len(antigos), 1)
        self.assertTrue(antigos[0]["bloqueada_para_busca"])
        self.assertTrue(corpus.blocos[antigos[0]["bloco_id"]]["bloqueada_para_busca"])
        self.assertFalse(corrigidos[0]["bloqueada_para_busca"])
        self.assertEqual(antigos[0]["volume"], corrigidos[0]["volume"])
        # O adaptador não oferece busca; ligar o Buscador antigo exigirá fase 3.
        self.assertFalse(hasattr(corpus, "buscar"))
        self.assertFalse(hasattr(corpus, "busca_semantica"))

    def test_leitura_contexto_devolve_copias_e_limita_vizinhos_a_obra(self):
        corpus = self.abrir()
        contexto = corpus.contexto(self.originais[1]["id"], raio=2)
        self.assertEqual([f["id"] for f in contexto["fragmentos"]], [f["id"] for f in self.originais[:3]])
        self.assertEqual({f["obra"] for f in contexto["fragmentos"]}, {"obra-a"})
        self.assertTrue(all("texto_origem_sha256" in f for f in contexto["fragmentos"]))
        f = corpus.fragmento(self.originais[0]["id"])
        f["texto"] = "alteração na cópia"
        self.assertEqual(corpus.por_id[f["id"]]["texto"], self.originais[0]["texto"])
        bloco = corpus.bloco(f["bloco_id"])
        bloco["referencia"]["paginas"].clear()
        self.assertEqual(corpus.blocos[f["bloco_id"]]["referencia"]["paginas"], [1, 2])

    def test_blocos_passam_contrato_literal_existente_sem_chamada_de_provedor(self):
        corpus = self.abrir()
        relato = validar_relato("Um relato com memória e sonho.")
        bloco = deepcopy(corpus.blocos[self.originais[0]["bloco_id"]])
        paragrafos, blocos = _fontes(relato, {"candidatos": [bloco]})
        fronteira = self.originais[0]["fim"]
        inicio, fim = fronteira - 3, fronteira + 4
        proposta = {"paragrafo": "P1", "bloco_id": bloco["bloco_id"],
                    "relato": {k: relato["paragrafos"][0][k] for k in ("inicio", "fim", "texto")},
                    "freud": {"inicio": inicio, "fim": fim, "texto": bloco["texto"][inicio:fim]},
                    "fragmentos_ids": bloco["fragmentos_ids"], "situacao": "parcial",
                    "observacao": "Recorte sintético para testar literalidade.", "conceito": "",
                    "ligacao": "Teste de contrato.", "justificativa": "Teste de cobertura entre fragmentos.",
                    "limites": "Sem avaliação interpretativa.", "alternativas": []}
        validada, motivo = _validar_ligacao(proposta, relato, paragrafos, blocos)
        self.assertIsNone(motivo)
        self.assertEqual(validada["freud"]["texto"], bloco["texto"][inicio:fim])
        self.assertEqual(validada["referencia"]["obra_id"], "obra-a")
        json.dumps(validada, ensure_ascii=False, allow_nan=False)
        json.dumps(deepcopy(corpus.fragmentos), ensure_ascii=False, allow_nan=False)

    def test_bloco_com_inicio_global_preserva_offsets_locais_para_citacao(self):
        corpus = self.abrir()
        bloco = corpus.blocos[self.originais[2]["bloco_id"]]
        self.assertGreater(bloco["original"]["inicio"], 0)
        self.assertEqual(bloco["fragmentos"][0]["inicio"], 0)
        self.assertEqual(bloco["fragmentos"][0]["fim"], len(bloco["texto"]))
        self.assertEqual(bloco["fragmentos_ids"], [self.originais[2]["id"]])

    def test_manifesto_dict_preservado_passa_compatibilidade_importacao(self):
        corpus = self.abrir()
        m = corpus.manifesto
        fonte = {"modelo": m["modelo"], "revisao": m["revisao"],
                 "tokenizador": {"identificacao": m["modelo"], "revisao": m["revisao"]},
                 "dimensao": m["dimensao"], "pooling": "mean", "normalizacao": "l2",
                 "formato_vetor": "float32", "prefixo": "query: "}
        self.assertIs(type(m), dict)
        conferir_compatibilidade({"fonte": fonte}, m)
        m["revisao"] = "main"
        self.assertNotEqual(corpus.manifesto["revisao"], "main")

    def test_fechamento_libera_mmap_mas_copias_publicas_continuam_validas(self):
        corpus = self.abrir()
        mapa = corpus.vetores._mmap
        preservado = corpus.fragmento(self.originais[0]["id"])
        corpus.close()
        self.assertTrue(mapa.closed)
        self.assertEqual(corpus.fragmentos, [])
        self.assertEqual(corpus.por_id, {})
        self.assertEqual(corpus.blocos, {})
        for operacao in (lambda: corpus.vetores, lambda: corpus.manifesto,
                         lambda: corpus.fragmento(preservado["id"]),
                         lambda: corpus.contexto(preservado["id"]),
                         lambda: corpus.bloco(preservado["bloco_id"])):
            with self.assertRaises(ErroCorpus):
                operacao()
        self.assertEqual(preservado["texto"], self.originais[0]["texto"])
        corpus.close()

    def test_erros_de_leitura_corrupta_ou_ids_sao_erros_corpus(self):
        corpus = self.abrir()
        for operacao in (lambda: corpus.fragmento("ausente"), lambda: corpus.bloco("ausente"),
                         lambda: corpus.contexto("ausente"), lambda: corpus.contexto(self.originais[0]["id"], raio=-1)):
            with self.assertRaises(ErroCorpus):
                operacao()
        self.assertTrue(issubclass(ErroContratoCamadaA, ErroCorpus))
        p = self.pasta / "manifesto.json"
        m = json.loads(p.read_text())
        p.write_text(json.dumps({**m, "revisao": "main"}))
        with self.assertRaises(ErroCorpus):
            abrir_camada_a(self.pasta)

    def test_abertura_leitura_e_fechamento_nao_modificam_a_fonte(self):
        antes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in self.pasta.iterdir()}
        with abrir_camada_a(self.pasta) as corpus:
            corpus.contexto(self.originais[1]["id"], raio=2)
            corpus.bloco(self.originais[0]["bloco_id"])
            json.dumps(corpus.fragmentos, ensure_ascii=False)
        depois = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in self.pasta.iterdir()}
        self.assertEqual(antes, depois)


if __name__ == "__main__":
    unittest.main()
