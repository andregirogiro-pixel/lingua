"""Leitura opcional da Camada A no contrato do Agente Analista, sem ativação.

Dependências: biblioteca padrão e NumPy. Não baixa modelos, gera embeddings,
altera o corpus nem escolhe a fusão de resultados do aplicativo. O núcleo
``LeitorCamadaA`` incorpora o leitor validado na etapa 2; ``CorpusCamadaA``
acrescenta os campos de leitura exigidos pelo contrato existente de ``Corpus``.
Use ``abrir_camada_a(pasta)`` explicitamente. Este módulo não modifica o serviço,
rotas ou backend padrão e não instancia ``Buscador``.

Todos os IDs, fragmentos e linhas da matriz são conservados. O volume 19 antigo
é marcado para a etapa 3, sem remoção de linhas. O Buscador existente não lê
essa marca: não deve ser conectado a este adaptador antes dessa etapa.

A matriz original não tem hash no manifesto v1: validar a ordem dos registros,
os hashes das entradas e a matriz não prova que um embedding foi calculado
daquele texto. Essa prova requer o pacote completo e auditoria de proveniência.
Só abra versões finalizadas e imutáveis; não use este leitor durante uma escrita
do pipeline. A conexão usa ``mode=ro&immutable=1`` e o NPY usa mmap ``r``.
"""

from __future__ import annotations

import copy
import functools
import hashlib
import json
import re
import sqlite3
import threading
from pathlib import Path
from typing import Any, Mapping

import numpy as np

from .corpus import ErroCorpus


MODELO_E5 = "intfloat/multilingual-e5-large"
REVISAO_E5 = "3d7cfbdacd47fdda877c5cd8a79fbcc4f2a574f3"
OBRA_19_ANTIGA = "obra-3b8627dba63512a2"
OBRAS_BLOQUEADAS_PADRAO = frozenset({OBRA_19_ANTIGA})

# O chamador deve obter estes campos da execução que realmente gerou a
# consulta. Copiar esta constante para rotular um vetor arbitrário não comprova
# compatibilidade. Dimensão igual, isoladamente, nunca é suficiente.
CONTRATO_CONSULTA_E5 = {
    "modelo": MODELO_E5,
    "revisao": REVISAO_E5,
    "tokenizador": MODELO_E5,
    "tokenizador_revisao": REVISAO_E5,
    "dimensao": 1024,
    "prefixo_consultas": "query: ",
    "prefixo_passagens": "passage: ",
    "pooling": "mean",
    "normalizacao": "L2",
    "tipo_vetor": "float32",
    "tokens_maximo": 512,
}


class ErroContratoCamadaA(ErroCorpus):
    """O corpus ou a consulta não satisfaz o contrato aceito pelo leitor."""


def _objeto_sem_duplicatas(pares: list[tuple[str, Any]]) -> dict[str, Any]:
    obj: dict[str, Any] = {}
    for chave, valor in pares:
        if chave in obj:
            raise ErroContratoCamadaA(f"Chave JSON duplicada: {chave!r}")
        obj[chave] = valor
    return obj


def _ler_json(texto: str, origem: str) -> dict[str, Any]:
    try:
        valor = json.loads(texto, object_pairs_hook=_objeto_sem_duplicatas,
                           parse_constant=lambda x: (_ for _ in ()).throw(
                               ErroContratoCamadaA(f"Número JSON inválido: {x}")))
    except (json.JSONDecodeError, UnicodeError) as exc:
        raise ErroContratoCamadaA(f"JSON inválido em {origem}: {exc}") from exc
    if not isinstance(valor, dict):
        raise ErroContratoCamadaA(f"Objeto JSON esperado em {origem}")
    return valor


def _inteiro(valor: Any, campo: str, minimo: int = 0) -> int:
    if type(valor) is not int or valor < minimo:
        raise ErroContratoCamadaA(f"{campo}: inteiro >= {minimo} esperado")
    return valor


def _sha(texto: str) -> str:
    return hashlib.sha256(texto.encode("utf-8")).hexdigest()


def _durante_leitura(metodo):
    """Não deixa close() liberar caches/mmap enquanto uma leitura os utiliza."""
    @functools.wraps(metodo)
    def executar(self, *args, **kwargs):
        with self._lock:
            self._aberto()
            return metodo(self, *args, **kwargs)
    return executar


def _validar_contrato_consulta(contrato: Mapping[str, Any]) -> None:
    if not isinstance(contrato, Mapping):
        raise ErroContratoCamadaA("Contrato da consulta obrigatório")
    for campo, esperado in CONTRATO_CONSULTA_E5.items():
        recebido = contrato.get(campo)
        igual = recebido == esperado
        if campo == "normalizacao" and isinstance(recebido, str):
            igual = recebido.casefold() == esperado.casefold()
        if not igual or type(recebido) is not type(esperado):
            raise ErroContratoCamadaA(f"Consulta incompatível em {campo}: {recebido!r}")


def contrato_de_execucao_lingua(execucao: Mapping[str, Any]) -> dict[str, Any]:
    """Converte metadados da etapa 09 do Língua, sem importar seus vetores.

    Exige acordo entre perfil e processamento. Isso valida os metadados
    declarados, não substitui o validador de artefatos/hashes do aplicativo.
    A origem da matriz continua sendo o pipeline v1, com prefixo passage:.
    """
    try:
        perfil = execucao["perfil"]
        processamento = execucao["processamento"]
        adaptador = processamento["adaptador"]
        for campo in ("modelo", "tokenizador"):
            if perfil[campo] != processamento[campo] or perfil[campo] != adaptador[campo]:
                raise ErroContratoCamadaA(f"Perfil/processamento divergem em {campo}")
        if perfil["finalidade"] != "consulta" or perfil["agregacao"] != "nenhuma":
            raise ErroContratoCamadaA("Use consultas individuais, sem agregação de embeddings")
        if perfil["precisao_inferencia"] != "float32":
            raise ErroContratoCamadaA("Consulta exige inferência float32")
        if processamento["precisao_inferencia"] != "float32":
            raise ErroContratoCamadaA("Processamento exige inferência float32")
        for obj in (processamento, adaptador):
            if obj["truncamento_automatico"] is not False or obj["prefixo_automatico"] is not False:
                raise ErroContratoCamadaA("Prefixo ou truncamento automático incompatível")
            if obj["pooling"] != "mean" or obj["dimensao"] != 1024:
                raise ErroContratoCamadaA("Pooling/dimensão incompatível no processamento")
            configs = obj["pooling_configuracao"]
            if not isinstance(configs, list) or len(configs) != 1:
                raise ErroContratoCamadaA("Uma configuração de mean pooling esperada")
            config = configs[0]
            if config.get("include_prompt") is not True or config.get("pooling_mode_mean_tokens") is not True:
                raise ErroContratoCamadaA("Mean pooling deve incluir o prefixo query:")
            if any(config.get(k) is not False for k in (
                    "pooling_mode_cls_token", "pooling_mode_lasttoken", "pooling_mode_max_tokens",
                    "pooling_mode_mean_sqrt_len_tokens", "pooling_mode_weightedmean_tokens")):
                raise ErroContratoCamadaA("Pooling combinado incompatível")
        limite = _inteiro(perfil["limite_tokens"], "limite_tokens", 1)
        if limite > 512 or processamento["limite_tokens_selecionado"] != limite:
            raise ErroContratoCamadaA("Limite de tokens inconsistente")
        contrato = {
            "modelo": perfil["modelo"]["identificacao"],
            "revisao": perfil["modelo"]["revisao"],
            "tokenizador": perfil["tokenizador"]["identificacao"],
            "tokenizador_revisao": perfil["tokenizador"]["revisao"],
            "dimensao": processamento["dimensao"],
            "prefixo_consultas": perfil["prefixo"],
            "prefixo_passagens": "passage: ",
            "pooling": perfil["pooling"],
            "normalizacao": perfil["normalizacao"],
            "tipo_vetor": perfil["formato_armazenamento"],
            "tokens_maximo": processamento["limite_modelo_tokens"],
        }
        _validar_contrato_consulta(contrato)
        return contrato
    except (KeyError, TypeError, AttributeError) as exc:
        raise ErroContratoCamadaA("Execução Língua sem metadados suficientes para compatibilidade") from exc


class LeitorCamadaA:
    """Abre um corpus v1 finalizado e valida todos os registros e vetores.

    ``raiz`` aponta para a pasta com manifesto.json, corpus.sqlite, o NPY e as
    referências JSONL. Apenas o ID da fonte antiga do volume 19 é excluído das
    buscas por padrão; não se bloqueia indiscriminadamente todo volume 19.
    Passe ``obras_bloqueadas=frozenset()`` para auditoria explícita de tudo.

    Leitura de fragmento/bloco/contexto continua possível para obras bloqueadas,
    marcada em ``rastreio.bloqueada_nas_buscas``. A exclusão afeta as buscas.
    ``raio`` conta fragmentos vizinhos na mesma obra, inclusive entre blocos.
    Os campos originais são preservados; páginas exatas aparecem em rastreio.
    """

    def __init__(self, raiz: str | Path, obras_bloqueadas=None):
        self.raiz = Path(raiz).expanduser().resolve()
        if not self.raiz.is_dir():
            raise ErroContratoCamadaA(f"Pasta do corpus inexistente: {self.raiz}")
        bloqueadas = (OBRAS_BLOQUEADAS_PADRAO if obras_bloqueadas is None
                      else obras_bloqueadas)
        if isinstance(bloqueadas, (str, bytes)):
            raise ErroContratoCamadaA("obras_bloqueadas deve ser uma coleção de IDs")
        self.obras_bloqueadas = frozenset(bloqueadas)
        if any(not isinstance(x, str) or not x for x in self.obras_bloqueadas):
            raise ErroContratoCamadaA("IDs de obras bloqueadas devem ser textos não vazios")
        self._lock = threading.RLock()
        self._con = None
        self._vetores = None
        self._fechado = False
        self._manifesto = _ler_json(self._arquivo("manifesto.json").read_text(
            encoding="utf-8"), "manifesto.json")
        self._validar_manifesto()
        try:
            caminho_db = self._arquivo("corpus.sqlite")
            # immutable ignora WAL; rejeitar uma base ainda em escrita é
            # preferível a validar silenciosamente uma versão incompleta.
            caminho_wal = Path(str(caminho_db) + "-wal")
            if caminho_wal.exists() and caminho_wal.stat().st_size:
                raise ErroContratoCamadaA("SQLite tem WAL pendente; finalize o corpus antes de abri-lo")
            self._con = sqlite3.connect(caminho_db.as_uri() + "?mode=ro&immutable=1",
                                        uri=True, check_same_thread=False)
            self._con.row_factory = sqlite3.Row
            self._con.execute("PRAGMA query_only=ON")
            self._validar_registros()
            self._vetores = np.load(self._arquivo(self._manifesto["vetores_arquivo"]),
                                    mmap_mode="r", allow_pickle=False)
            self._validar_vetores()
        except Exception:
            self.close()
            raise

    @property
    def manifesto(self) -> dict[str, Any]:
        return copy.deepcopy(self._manifesto)

    @property
    def contrato_consulta(self) -> dict[str, Any]:
        return copy.deepcopy(CONTRATO_CONSULTA_E5)

    def _arquivo(self, relativo: Any) -> Path:
        if not isinstance(relativo, str) or not relativo:
            raise ErroContratoCamadaA("Nome de arquivo inválido no manifesto")
        caminho = Path(relativo)
        if caminho.is_absolute():
            raise ErroContratoCamadaA("O manifesto deve usar caminhos relativos à raiz")
        caminho = (self.raiz / caminho).resolve()
        if not caminho.is_relative_to(self.raiz):
            raise ErroContratoCamadaA(f"Caminho sai da raiz do corpus: {relativo!r}")
        if not caminho.is_file():
            raise ErroContratoCamadaA(f"Arquivo obrigatório ausente: {caminho}")
        return caminho

    def _validar_manifesto(self) -> None:
        esperado = {"schema": "camada_a_freud.v1", "modelo": MODELO_E5,
                    "revisao": REVISAO_E5, "dimensao": 1024,
                    "tokens_maximo": 512, "prefixo_passagens": "passage: ",
                    "prefixo_consultas": "query: ", "tipo_vetor": "float32",
                    "normalizacao": "L2"}
        for campo, valor in esperado.items():
            recebido = self._manifesto.get(campo)
            if recebido != valor or type(recebido) is not type(valor):
                raise ErroContratoCamadaA(f"Manifesto incompatível em {campo}: {recebido!r}; esperado {valor!r}")
        self._n = _inteiro(self._manifesto.get("fragmentos"), "fragmentos", 1)
        self._n_blocos = _inteiro(self._manifesto.get("blocos"), "blocos", 1)
        margem = _inteiro(self._manifesto.get("margem_tokens"), "margem_tokens")
        if margem >= 512:
            raise ErroContratoCamadaA("margem_tokens deve ser menor que 512")
        self._tokens_entrada_max = 512 - margem
        for campo in ("vetores_arquivo", "referencias_arquivo"):
            self._arquivo(self._manifesto.get(campo))

    def _sql(self, sql: str, parametros=()) -> list[sqlite3.Row]:
        with self._lock:
            self._aberto()
            return self._con.execute(sql, parametros).fetchall()

    def _validar_registros(self) -> None:
        if [r[0] for r in self._sql("PRAGMA quick_check")] != ["ok"]:
            raise ErroContratoCamadaA("SQLite falhou em quick_check")
        if self._sql("PRAGMA foreign_key_check"):
            raise ErroContratoCamadaA("SQLite tem referências estrangeiras inválidas")
        self._obras = {r["id"]: dict(r) for r in self._sql("SELECT * FROM obras")}
        self._secoes = {r["id"]: dict(r) for r in self._sql("SELECT * FROM secoes")}
        self._blocos = {r["id"]: dict(r) for r in self._sql("SELECT * FROM blocos")}
        if len(self._blocos) != self._n_blocos:
            raise ErroContratoCamadaA("Contagem de blocos diferente do manifesto")
        self._paginas: dict[str, list[dict]] = {}
        for r in self._sql("SELECT * FROM paginas ORDER BY obra_id,pagina_pdf"):
            p = dict(r)
            _inteiro(p["pagina_pdf"], "pagina_pdf", 1)
            _inteiro(p["inicio"], "pagina.inicio")
            _inteiro(p["fim"], "pagina.fim")
            if p["fim"] < p["inicio"] or p["obra_id"] not in self._obras:
                raise ErroContratoCamadaA("Intervalo ou obra de página inválido")
            paginas = self._paginas.setdefault(p["obra_id"], [])
            if paginas and (p["pagina_pdf"] <= paginas[-1]["pagina_pdf"] or
                            p["inicio"] < paginas[-1]["fim"]):
                raise ErroContratoCamadaA("Páginas sobrepostas ou fora de ordem")
            paginas.append(p)
        for obra_id, obra in self._obras.items():
            quantidade = _inteiro(obra["paginas"], "obra.paginas", 1)
            paginas = self._paginas.get(obra_id, [])
            if len(paginas) != quantidade:
                raise ErroContratoCamadaA(f"Contagem de páginas diverge da obra {obra_id}")
            if any(p["pagina_pdf"] != numero for numero, p in enumerate(paginas, 1)):
                raise ErroContratoCamadaA(f"Páginas PDF devem formar a sequência 1..{quantidade} na obra {obra_id}")
        for sec in self._secoes.values():
            if sec["obra_id"] not in self._obras:
                raise ErroContratoCamadaA("Seção sem obra")
            _inteiro(sec["pagina_inicio"], "secao.pagina_inicio", 1)
            if sec["pagina_inicio"] > self._obras[sec["obra_id"]]["paginas"]:
                raise ErroContratoCamadaA(f"Página inicial da seção {sec['id']} não existe na obra")
        for b in self._blocos.values():
            _inteiro(b["inicio"], "bloco.inicio")
            _inteiro(b["fim"], "bloco.fim", 1)
            sec = self._secoes.get(b["secao_id"])
            if b["obra_id"] not in self._obras or not sec or sec["obra_id"] != b["obra_id"]:
                raise ErroContratoCamadaA(f"Obra/seção inconsistente no bloco {b['id']}")
            if not isinstance(b["texto"], str) or b["fim"] - b["inicio"] != len(b["texto"]):
                raise ErroContratoCamadaA(f"Offsets inválidos no bloco {b['id']}")
            if _sha(b["texto"]) != b["sha256_texto"]:
                raise ErroContratoCamadaA(f"Hash de texto inválido no bloco {b['id']}")
            for original, novo in (("paginas_json", "paginas"),
                                   ("papeis_provisorios_json", "papeis_provisorios"),
                                   ("conceitos_lexicais_json", "conceitos_lexicais")):
                try:
                    b[novo] = json.loads(b[original])
                except (TypeError, json.JSONDecodeError) as exc:
                    raise ErroContratoCamadaA(f"Metadado inválido em {b['id']}.{original}") from exc
                if not isinstance(b[novo], list):
                    raise ErroContratoCamadaA(f"Lista esperada em {b['id']}.{original}")

        self._referencias: list[dict[str, Any]] = []
        self._por_id: dict[str, dict[str, Any]] = {}
        with self._arquivo(self._manifesto["referencias_arquivo"]).open(encoding="utf-8") as entrada:
            for numero, linha in enumerate(entrada, 1):
                if not linha.strip():
                    raise ErroContratoCamadaA(f"Linha vazia nas referências: {numero}")
                f = _ler_json(linha, f"referências:{numero}")
                fid = f.get("id")
                if not isinstance(fid, str) or not fid or fid in self._por_id:
                    raise ErroContratoCamadaA(f"ID vazio, inválido ou duplicado nas referências: {fid!r}")
                self._referencias.append(f)
                self._por_id[fid] = f
        linhas_sql = self._sql("SELECT * FROM fragmentos ORDER BY rowid")
        if len(self._referencias) != self._n or len(linhas_sql) != self._n:
            raise ErroContratoCamadaA("Contagem de referências/SQLite diferente do manifesto")
        campos = ("id", "bloco_id", "obra_id", "secao_id", "ordem", "inicio", "fim",
                  "anterior_id", "posterior_id", "cabecalho", "texto", "entrada_sha256")
        self._por_obra: dict[str, list[str]] = {}
        fragmentos_bloco: dict[str, list[dict]] = {}
        for f, sql in zip(self._referencias, linhas_sql):
            for campo in campos:
                if campo not in f or f[campo] != sql[campo] or type(f[campo]) is not type(sql[campo]):
                    raise ErroContratoCamadaA(f"Referência/ordem SQLite diverge em {f['id']}.{campo}")
            tokens = _inteiro(f.get("tokens_entrada"), "tokens_entrada", 1)
            if tokens != sql["tokens"] or tokens > self._tokens_entrada_max:
                raise ErroContratoCamadaA(f"Contagem de tokens inválida em {f['id']}")
            for campo in ("ordem", "inicio", "fim"):
                _inteiro(f[campo], f"fragmento.{campo}")
            b = self._blocos.get(f["bloco_id"])
            if not b or b["obra_id"] != f["obra_id"] or b["secao_id"] != f["secao_id"]:
                raise ErroContratoCamadaA(f"Obra/seção/bloco inconsistente em {f['id']}")
            if not isinstance(f["texto"], str) or not isinstance(f["cabecalho"], str):
                raise ErroContratoCamadaA(f"Texto/cabeçalho inválido em {f['id']}")
            if not 0 <= f["inicio"] < f["fim"] <= len(b["texto"]):
                raise ErroContratoCamadaA(f"Offsets inválidos em {f['id']}")
            if b["texto"][f["inicio"]:f["fim"]] != f["texto"]:
                raise ErroContratoCamadaA(f"Texto do fragmento diverge do bloco: {f['id']}")
            if _sha("passage: " + f["cabecalho"] + "\n" + f["texto"]) != f["entrada_sha256"]:
                raise ErroContratoCamadaA(f"Hash da entrada E5 inválido em {f['id']}")
            if f.get("paginas") != b["paginas"]:
                raise ErroContratoCamadaA(f"Metadado original de páginas diverge em {f['id']}")
            self._por_obra.setdefault(f["obra_id"], []).append(f["id"])
            fragmentos_bloco.setdefault(f["bloco_id"], []).append(f)
        self._posicao_obra: dict[str, int] = {}
        for obra, ids in self._por_obra.items():
            for pos, fid in enumerate(ids):
                f = self._por_id[fid]
                if f["anterior_id"] != (ids[pos - 1] if pos else None) or \
                   f["posterior_id"] != (ids[pos + 1] if pos + 1 < len(ids) else None):
                    raise ErroContratoCamadaA(f"Vizinhança fora de ordem ou cruzando obras: {fid}")
                self._posicao_obra[fid] = pos
        for bid, b in self._blocos.items():
            lista = fragmentos_bloco.get(bid, [])
            cursor = 0
            for ordem, f in enumerate(lista):
                if f["ordem"] != ordem or f["inicio"] != cursor:
                    raise ErroContratoCamadaA(f"Fragmentos com lacuna/sobreposição no bloco {bid}")
                cursor = f["fim"]
            if cursor != len(b["texto"]):
                raise ErroContratoCamadaA(f"Fragmentos não cobrem o bloco {bid}")
        for obra, registro in self._obras.items():
            blocos = sorted((b for b in self._blocos.values() if b["obra_id"] == obra),
                            key=lambda b: b["inicio"])
            cursor = 0
            h = hashlib.sha256()
            for b in blocos:
                if b["inicio"] != cursor:
                    raise ErroContratoCamadaA(f"Blocos com lacuna/sobreposição na obra {obra}")
                h.update(b["texto"].encode("utf-8"))
                cursor = b["fim"]
            if h.hexdigest() != registro["texto_sha256"]:
                raise ErroContratoCamadaA(f"Hash de texto consolidado inválido na obra {obra}")
            for p in self._paginas.get(obra, []):
                if p["fim"] > cursor:
                    raise ErroContratoCamadaA(f"Página além dos offsets da obra {obra}")
        self._validar_fts()

    def _validar_fts(self) -> None:
        definicoes = self._sql("SELECT sql FROM sqlite_master WHERE type='table' AND name=?",
                               ("fragmentos_fts",))
        sql_criacao = definicoes[0]["sql"] if len(definicoes) == 1 else None
        nome_tabela = r'(?:fragmentos_fts|"fragmentos_fts"|`fragmentos_fts`|\[fragmentos_fts\])'
        modulo_fts5 = r'^\s*CREATE\s+VIRTUAL\s+TABLE\s+' + nome_tabela + r'\s+USING\s+fts5\s*\('
        if not isinstance(sql_criacao, str) or not re.search(modulo_fts5, sql_criacao, re.IGNORECASE):
            raise ErroContratoCamadaA("fragmentos_fts deve ser uma tabela virtual FTS5")
        configuracoes = re.findall(r'''(?:,|\()\s*tokenize\s*=\s*(['"])(.*?)\1\s*(?=,|\))''',
                                   sql_criacao, re.IGNORECASE | re.DOTALL)
        if len(configuracoes) != 1 or " ".join(configuracoes[0][1].split()).casefold() != "unicode61 remove_diacritics 2":
            raise ErroContratoCamadaA("FTS5 exige tokenize='unicode61 remove_diacritics 2' do contrato v1")
        # Evita indexar outro texto com o ID correto. O índice deve conter uma
        # linha para cada referência, sem extras nem IDs repetidos.
        vistos = set()
        for linha in self._sql("SELECT fragmento_id,cabecalho,texto FROM fragmentos_fts"):
            fid = linha["fragmento_id"]
            f = self._por_id.get(fid)
            if not f or fid in vistos or linha["cabecalho"] != f["cabecalho"] or linha["texto"] != f["texto"]:
                raise ErroContratoCamadaA(f"FTS inconsistente em {fid!r}")
            vistos.add(fid)
        if len(vistos) != self._n:
            raise ErroContratoCamadaA("FTS não cobre todas as referências")

    def _validar_vetores(self) -> None:
        v = self._vetores
        lote = None
        try:
            if not isinstance(v, np.memmap) or v.ndim != 2 or v.shape != (self._n, 1024):
                raise ErroContratoCamadaA(f"Shape da matriz incompatível: {getattr(v, 'shape', None)}")
            if v.dtype != np.dtype("float32") or v.flags.writeable:
                raise ErroContratoCamadaA("Matriz deve ser float32 e somente leitura")
            for inicio in range(0, self._n, 1024):
                lote = v[inicio:inicio + 1024]
                if not np.isfinite(lote).all():
                    raise ErroContratoCamadaA(f"Matriz contém NaN/infinito a partir da linha {inicio}")
                normas = np.linalg.norm(lote, axis=1)
                if not np.allclose(normas, 1.0, rtol=0.0, atol=3e-5):
                    raise ErroContratoCamadaA(f"Matriz sem normalização L2 a partir da linha {inicio}")
        finally:
            # Um traceback mantido pelo chamador não deve reter views do mmap
            # que o construtor fecha ao rejeitar uma matriz inválida.
            lote = None
            v = None

    def _rastreio(self, f: Mapping[str, Any], inicio: int, fim: int) -> dict:
        obra = self._obras[f["obra_id"]]
        secao = self._secoes[f["secao_id"]]
        paginas = [p for p in self._paginas.get(f["obra_id"], [])
                   if p["inicio"] < fim and p["fim"] > inicio and p["fim"] > p["inicio"]]
        secoes = sorted((s for s in self._secoes.values() if s["obra_id"] == f["obra_id"]),
                        key=lambda s: (s["pagina_inicio"], s["id"]))
        paginas_secoes = []
        for p in paginas:
            candidatas = [s for s in secoes if s["pagina_inicio"] <= p["pagina_pdf"]]
            s = candidatas[-1] if candidatas else None
            paginas_secoes.append({"pagina_pdf": p["pagina_pdf"],
                                   "secao_id": s["id"] if s else None})
        return {"obra_id": obra["id"], "titulo_obra": obra["titulo"],
                "volume_sugerido": obra["volume_sugerido"],
                "pdf_original": obra["pdf_original"], "sha256_pdf": obra["sha256_pdf"],
                "estado_obra": obra["estado"], "secao_id": secao["id"],
                "titulo_secao": secao["titulo"], "origem_secao": secao["origem"],
                "inicio_obra": inicio, "fim_obra": fim,
                "paginas_pdf": [p["pagina_pdf"] for p in paginas],
                "origem_paginas": "intervalos de caracteres em paginas SQLite; PDF 1-indexado",
                "paginas_metadado_origem": copy.deepcopy(f["paginas"]),
                "secoes_por_pagina": paginas_secoes,
                "atravessa_secoes": len({p["secao_id"] for p in paginas_secoes}) > 1,
                "bloqueada_nas_buscas": f["obra_id"] in self.obras_bloqueadas}

    @_durante_leitura
    def fragmento(self, fragmento_id: str) -> dict[str, Any]:
        self._aberto()
        f = self._por_id.get(fragmento_id)
        if f is None:
            raise KeyError(fragmento_id)
        b = self._blocos[f["bloco_id"]]
        resultado = copy.deepcopy(f)
        resultado["rastreio"] = self._rastreio(f, b["inicio"] + f["inicio"], b["inicio"] + f["fim"])
        return resultado

    @_durante_leitura
    def bloco(self, bloco_id: str) -> dict[str, Any]:
        self._aberto()
        b = self._blocos.get(bloco_id)
        if b is None:
            raise KeyError(bloco_id)
        resultado = copy.deepcopy(b)
        resultado["rastreio"] = self._rastreio(b, b["inicio"], b["fim"])
        resultado["fragmentos_ids"] = [f["id"] for f in self._referencias if f["bloco_id"] == bloco_id]
        return resultado

    @_durante_leitura
    def contexto(self, fragmento_id: str, raio: int = 1) -> dict[str, Any]:
        _inteiro(raio, "raio")
        if raio > 100:
            raise ErroContratoCamadaA("raio máximo: 100 fragmentos")
        foco = self.fragmento(fragmento_id)
        ids = self._por_obra[foco["obra_id"]]
        pos = self._posicao_obra[fragmento_id]
        escolhidos = ids[max(0, pos - raio):min(len(ids), pos + raio + 1)]
        return {"fragmento_id": fragmento_id, "obra_id": foco["obra_id"], "raio": raio,
                "fragmentos": [self.fragmento(fid) for fid in escolhidos]}

    @staticmethod
    def _top_k(top_k: int) -> int:
        return _inteiro(top_k, "top_k", 1)

    def _resultado(self, fid: str, metodo: str, score: float, rank: int,
                   consulta_id: str | None) -> dict:
        f = self.fragmento(fid)
        return {"fragmento_id": fid, "bloco_id": f["bloco_id"], "obra_id": f["obra_id"],
                "secao_id": f["secao_id"], "metodo": metodo, "score": score,
                "rank": rank, "consulta_id": consulta_id, "fragmento": f}

    @_durante_leitura
    def busca_lexical(self, texto: str, *, top_k: int = 50,
                      consulta_id: str | None = None) -> list[dict]:
        """BM25 do FTS5; menor score primeiro, tokens literais ligados por OR.

        Operadores, aspas e pontuação do usuário não viram expressão FTS/SQL.
        Esta tokenização difere da busca legada; não compara scores entre elas.
        """
        top_k = self._top_k(top_k)
        if not isinstance(texto, str):
            raise ErroContratoCamadaA("Consulta lexical deve ser texto")
        self._aberto()
        termos = list(dict.fromkeys(t.casefold() for t in re.findall(r"[^\W_]+", texto, re.UNICODE)))
        if not termos:
            return []
        expressao = " OR ".join('"' + termo + '"' for termo in termos)
        sql = """SELECT fragmentos_fts.fragmento_id AS id,
                 bm25(fragmentos_fts) AS score
                 FROM fragmentos_fts JOIN fragmentos f ON f.id=fragmentos_fts.fragmento_id
                 WHERE fragmentos_fts MATCH ?"""
        parametros: list[Any] = [expressao]
        if self.obras_bloqueadas:
            bloqueadas = sorted(self.obras_bloqueadas)
            sql += " AND f.obra_id NOT IN (" + ",".join("?" for _ in bloqueadas) + ")"
            parametros.extend(bloqueadas)
        sql += " ORDER BY score ASC, fragmentos_fts.rowid ASC LIMIT ?"
        parametros.append(top_k)
        linhas = self._sql(sql, parametros)
        return [self._resultado(r["id"], "sqlite_fts5_bm25", float(r["score"]), pos, consulta_id)
                for pos, r in enumerate(linhas, 1)]

    @_durante_leitura
    def busca_semantica(self, vetor_consulta, *, contrato: Mapping[str, Any],
                        top_k: int = 50, consulta_id: str | None = None) -> list[dict]:
        """Cosseno com E5 compatível; não gera consulta, não baixa nenhum modelo.

        O contrato deve descrever a execução de origem do vetor, inclusive
        prefixo query:, modelo/tokenizador e suas revisões, pooling e L2.
        O vetor recebido é normalizado para eliminar erro numérico de norma.
        A responsabilidade pela autenticidade dos metadados é do chamador.
        """
        top_k = self._top_k(top_k)
        self._aberto()
        _validar_contrato_consulta(contrato)
        try:
            recebido = np.asarray(vetor_consulta)
            if recebido.dtype.kind not in "fiu" or recebido.shape != (1024,):
                raise ErroContratoCamadaA("Consulta deve ter shape (1024,) e valores numéricos reais")
            q64 = recebido.astype(np.float64)
        except (ValueError, TypeError, OverflowError) as exc:
            raise ErroContratoCamadaA("Vetor de consulta inválido") from exc
        if not np.isfinite(q64).all():
            raise ErroContratoCamadaA("Consulta contém NaN/infinito")
        norma = float(np.linalg.norm(q64))
        if not np.isfinite(norma) or norma <= 0:
            raise ErroContratoCamadaA("Consulta tem norma zero ou inválida")
        q = (q64 / norma).astype(np.float32)
        with self._lock:
            self._aberto()
            scores = np.asarray(self._vetores @ q)
        ordem = np.argsort(-scores, kind="stable")
        resultados = []
        for indice in ordem:
            f = self._referencias[int(indice)]
            if f["obra_id"] in self.obras_bloqueadas:
                continue
            resultados.append(self._resultado(f["id"], "e5_cosseno", float(scores[indice]),
                                               len(resultados) + 1, consulta_id))
            if len(resultados) >= top_k:
                break
        return resultados

    def _aberto(self) -> None:
        if self._fechado:
            raise RuntimeError("LeitorCamadaA já foi fechado")

    def close(self) -> None:
        with self._lock:
            self._fechado = True
            try:
                if self._con is not None:
                    self._con.close()
            finally:
                self._con = None
                try:
                    if isinstance(self._vetores, np.memmap):
                        # NumPy não expõe close() no memmap. O mapeamento é
                        # privado ao leitor e nenhuma API devolve suas views;
                        # fechar o mmap evita esperar por GC/tracebacks.
                        self._vetores._mmap.close()
                    elif hasattr(self._vetores, "close"):
                        self._vetores.close()
                finally:
                    self._vetores = None
                    for nome in ("_referencias", "_por_id", "_obras", "_secoes", "_blocos",
                                 "_paginas", "_por_obra", "_posicao_obra"):
                        cache = getattr(self, nome, None)
                        if cache is not None:
                            cache.clear()

    def __enter__(self):
        self._aberto()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


class CorpusCamadaA:
    """Adaptador explícito de leitura; mantém a matriz e IDs na ordem original.

    ``fragmentos``, ``por_id``, ``indice_por_id`` e ``blocos`` seguem o contrato
    de leitura do Corpus legado, sem converter arquivos ou sintetizar vetores.
    Os registros são dicts/listas comuns, compatíveis com deepcopy e JSON.
    ``original`` preserva os campos do registro Camada A sem alterações;
    ``paginas_origem`` preserva o metadado amplo do bloco e ``paginas`` contém
    as páginas PDF derivadas dos offsets daquele fragmento.

    Os offsets de cada fragmento/citação permanecem relativos ao bloco,
    Unicode base zero e fim exclusivo. O início/fim do bloco original são
    globais à obra e ficam identificados em ``rastreio`` e ``original``.

    ``vetores`` expõe o mmap original somente leitura enquanto o corpus está
    aberto. Não retenha ou utilize o array/views após close(): o mapeamento é
    liberado. A fonte deve permanecer finalizada e imutável durante a leitura.
    """

    def __init__(self, pasta: str | Path):
        self._lock = threading.RLock()
        self._leitor = None
        self._fechado = False
        self.fragmentos = []
        self.por_id = {}
        self.indice_por_id = {}
        self.blocos = {}
        try:
            self._leitor = LeitorCamadaA(pasta)
            self.pasta = self._leitor.raiz
            for indice, original in enumerate(self._leitor._referencias):
                completo = self._leitor.fragmento(original["id"])
                bloco = self._leitor._blocos[completo["bloco_id"]]
                rastreio = completo["rastreio"]
                volume = self._volume(rastreio["volume_sugerido"], completo["obra_id"])
                secao = rastreio["titulo_secao"]
                if not isinstance(secao, str):
                    raise ErroCorpus(f"A seção de {completo['id']} não possui título textual.")
                fragmento = copy.deepcopy(completo)
                fragmento.update({
                    "obra": completo["obra_id"], "volume": volume, "secao": secao,
                    "fragmento_no_bloco": completo["ordem"],
                    "texto_origem_sha256": bloco["sha256_texto"],
                    "paginas_origem": copy.deepcopy(original["paginas"]),
                    "paginas": list(rastreio["paginas_pdf"]),
                    "original": copy.deepcopy(original),
                    "bloqueada_para_busca": completo["obra_id"] == OBRA_19_ANTIGA,
                })
                self.fragmentos.append(fragmento)
                self.por_id[fragmento["id"]] = fragmento
                self.indice_por_id[fragmento["id"]] = indice
            for bloco_id in self._leitor._blocos:
                self.blocos[bloco_id] = self._adaptar_bloco(bloco_id)
        except ErroCorpus:
            self.close()
            raise
        except (OSError, ValueError, TypeError, KeyError, sqlite3.DatabaseError) as exc:
            self.close()
            raise ErroCorpus("Não foi possível abrir a Camada A. Confira o pacote finalizado "
                             "com manifesto.json, corpus.sqlite, fragmentos.jsonl e os vetores.") from exc

    @staticmethod
    def _volume(valor: Any, obra_id: str) -> int:
        if type(valor) is not int or valor <= 0:
            raise ErroCorpus(f"A obra {obra_id} precisa de volume_sugerido inteiro positivo para o contrato de leitura.")
        return valor

    def _adaptar_bloco(self, bloco_id: str) -> dict[str, Any]:
        original = self._leitor._blocos[bloco_id]
        completo = self._leitor.bloco(bloco_id)
        rastreio = completo["rastreio"]
        fragmentos = [self.por_id[fid] for fid in completo["fragmentos_ids"]]
        pendencias = ["edição", "tradutor", "editora", "ano da edição",
                      "correspondência entre páginas do PDF e impressas"]
        if not rastreio["titulo_secao"]:
            pendencias.append("seção")
        if not rastreio["paginas_pdf"]:
            pendencias.append("páginas")
        if rastreio["atravessa_secoes"]:
            pendencias.append("bloco atravessa seções; seção declarada é a do início do bloco")
        referencia = {
            "obra": rastreio["titulo_obra"], "obra_id": original["obra_id"],
            "volume": self._volume(rastreio["volume_sugerido"], original["obra_id"]),
            "secao": rastreio["titulo_secao"], "secao_id": original["secao_id"],
            "paginas": list(rastreio["paginas_pdf"]),
            "paginas_origem": copy.deepcopy(original["paginas"]),
            "nota_paginas": "páginas PDF derivadas dos offsets; numeração impressa não conferida",
            "pendencias": pendencias, "pdf_original": rastreio["pdf_original"],
            "sha256_pdf": rastreio["sha256_pdf"], "origem_secao": rastreio["origem_secao"],
            "atravessa_secoes": rastreio["atravessa_secoes"],
        }
        completo.update({
            "bloco_id": bloco_id, "texto_origem_sha256": original["sha256_texto"],
            "fragmentos": [{"id": f["id"], "inicio": f["inicio"], "fim": f["fim"]}
                            for f in fragmentos],
            "referencia": referencia, "original": copy.deepcopy(original),
            "paginas_origem": copy.deepcopy(original["paginas"]),
            "paginas": list(rastreio["paginas_pdf"]),
            "bloqueada_para_busca": original["obra_id"] == OBRA_19_ANTIGA,
        })
        return completo

    @property
    def manifesto(self) -> dict[str, Any]:
        self._aberto()
        return self._leitor.manifesto

    @property
    def vetores(self) -> np.memmap:
        self._aberto()
        return self._leitor._vetores

    def _aberto(self) -> None:
        if self._fechado:
            raise ErroCorpus("O adaptador da Camada A já foi fechado.")

    def fragmento(self, fragmento_id: str) -> dict[str, Any]:
        with self._lock:
            self._aberto()
            try:
                return copy.deepcopy(self.por_id[fragmento_id])
            except (KeyError, TypeError) as exc:
                raise ErroCorpus("O fragmento solicitado não pertence à Camada A aberta.") from exc

    def bloco(self, bloco_id: str) -> dict[str, Any]:
        with self._lock:
            self._aberto()
            try:
                return copy.deepcopy(self.blocos[bloco_id])
            except (KeyError, TypeError) as exc:
                raise ErroCorpus("O bloco solicitado não pertence à Camada A aberta.") from exc

    def contexto(self, fragmento_id: str, raio: int = 1) -> dict[str, Any]:
        with self._lock:
            self._aberto()
            try:
                contexto = self._leitor.contexto(fragmento_id, raio)
            except (KeyError, TypeError, ValueError, RuntimeError) as exc:
                raise ErroCorpus("Não foi possível ler o contexto. Confira o ID e o raio solicitado.") from exc
            return {**contexto,
                    "fragmentos": [self.fragmento(f["id"]) for f in contexto["fragmentos"]]}

    def close(self) -> None:
        with self._lock:
            self._fechado = True
            try:
                if self._leitor is not None:
                    self._leitor.close()
            finally:
                self.fragmentos.clear()
                self.por_id.clear()
                self.indice_por_id.clear()
                self.blocos.clear()

    def __enter__(self):
        self._aberto()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


def abrir_camada_a(pasta: str | Path) -> CorpusCamadaA:
    """Abre explicitamente a Camada A para leitura; não escolhe backend do app."""
    return CorpusCamadaA(pasta)
