#!/bin/bash
set -euo pipefail

PACOTE_ADAPTADOR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_ADAPTADOR="${PYTHON_ADAPTADOR:-/Users/rodrigodevellis/lingua-agente/instance/venv-agente-e5-intel/bin/python}"
PROJETO_ADAPTADOR="${1:-/Users/rodrigodevellis/lingua-agente}"
CORPUS_ADAPTADOR="${2:-/Users/rodrigodevellis/Documents/Qoder/2026-10-11/a276916c/camada_a}"
SAIDA_ADAPTADOR="${3:-$HOME/Downloads}"
EXECUCAO_ADAPTADOR="$(date +%Y%m%d_%H%M%S)_$$"
REGISTRO_ADAPTADOR="$SAIDA_ADAPTADOR/instalacao_adaptador_$EXECUCAO_ADAPTADOR.json"
RELATORIO_ADAPTADOR="$SAIDA_ADAPTADOR/adaptador_camada_a_$EXECUCAO_ADAPTADOR.json"

"$PYTHON_ADAPTADOR" -c 'import sys; assert sys.version_info >= (3, 10), "Requer Python 3.10+"; import numpy; print("Python:", sys.executable); print("NumPy:", numpy.__version__)'

"$PYTHON_ADAPTADOR" "$PACOTE_ADAPTADOR/ferramentas/aplicar_adaptador.py" \
  --projeto "$PROJETO_ADAPTADOR" --registro "$REGISTRO_ADAPTADOR"

"$PYTHON_ADAPTADOR" "$PACOTE_ADAPTADOR/ferramentas/verificar_adaptador.py" \
  --projeto "$PROJETO_ADAPTADOR" --corpus "$CORPUS_ADAPTADOR" \
  --baseline "$PACOTE_ADAPTADOR/dados/CONCLUSAO_ETAPA1.json" \
  --saida "$RELATORIO_ADAPTADOR"

printf '\nEnvie o relatório do adaptador: %s\n' "$RELATORIO_ADAPTADOR"
printf 'Guarde o registro da instalação: %s\n' "$REGISTRO_ADAPTADOR"
