"""Instala somente arquivos novos da etapa 2, preservando o código existente."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile

PACOTE = Path(__file__).resolve().parents[1]


def digest(caminho):
    return hashlib.sha256(caminho.read_bytes()).hexdigest()


def dentro(raiz, relativo):
    rel = Path(relativo)
    if rel.is_absolute() or ".." in rel.parts:
        raise ValueError("Caminho relativo inválido no manifesto de instalação.")
    caminho = raiz / rel
    if caminho.is_symlink() or not caminho.resolve().is_relative_to(raiz):
        raise ValueError("O destino contém um symlink ou sai do projeto.")
    return caminho


def instalar(projeto, registro):
    projeto = projeto.expanduser().resolve()
    registro_original = registro.expanduser()
    if registro_original.is_symlink():
        raise ValueError("O registro de instalação não pode ser um symlink.")
    registro = registro_original.resolve()
    if not projeto.is_dir() or not registro.parent.is_dir():
        raise ValueError("Projeto e diretório de saída devem existir.")
    if registro.is_relative_to(projeto) or registro.exists():
        raise ValueError("Escolha um registro novo fora do projeto.")
    manifesto = json.loads((PACOTE / "INSTALACAO.json").read_text(encoding="utf-8"))
    for nome, esperado in manifesto["base"].items():
        caminho = dentro(projeto, nome)
        if not caminho.is_file() or digest(caminho) != esperado:
            raise ValueError(f"O arquivo {nome} difere da versão revisada; instalação não iniciada.")
    novos, existentes = [], []
    for nome, esperado in manifesto["novos"].items():
        origem = dentro(PACOTE / "arquivos", nome)
        destino = dentro(projeto, nome)
        if not origem.is_file() or digest(origem) != esperado:
            raise ValueError(f"Arquivo do pacote inconsistente: {nome}.")
        if not destino.parent.is_dir():
            raise ValueError(f"Diretório de destino ausente: {destino.parent}.")
        if destino.exists():
            if not destino.is_file() or digest(destino) != esperado:
                raise ValueError(f"O arquivo {nome} já existe com outro conteúdo; não será sobrescrito.")
            existentes.append(nome)
        else:
            novos.append((nome, origem, destino, esperado))
    criados = []
    recibo_criado = False
    try:
        with registro.open("x", encoding="utf-8") as recibo:
            recibo_criado = True
            for nome, origem, destino, esperado in novos:
                conteudo = origem.read_bytes()
                if hashlib.sha256(conteudo).hexdigest() != esperado:
                    raise ValueError(f"Arquivo mudou antes da cópia: {nome}.")
                temporario = None
                try:
                    with tempfile.NamedTemporaryFile(dir=destino.parent,
                                                     prefix=".etapa2_", delete=False) as arquivo:
                        temporario = Path(arquivo.name)
                        arquivo.write(conteudo)
                    # O hard link só é criado se o destino ainda não existir;
                    # o conteúdo completo fica visível de uma vez.
                    os.link(temporario, destino)
                    criados.append((nome, destino, esperado))
                finally:
                    if temporario is not None:
                        temporario.unlink(missing_ok=True)
                if digest(destino) != esperado:
                    raise ValueError(f"A cópia de {nome} não corresponde ao pacote.")
            resultado = {
                "etapa": 2, "estado": "arquivos_opcionais_instalados",
                "projeto": str(projeto), "criado_em_utc": datetime.now(timezone.utc).isoformat(),
                "novos_criados": [{"arquivo": n, "sha256": h} for n, _, h in criados],
                "ja_presentes_iguais": existentes, "arquivos_preexistentes_alterados": [],
                "busca_ativada": False, "modelo_baixado": False,
            }
            json.dump(resultado, recibo, ensure_ascii=False, indent=2)
            recibo.write("\n")
    except Exception:
        for _, caminho, esperado in reversed(criados):
            if caminho.is_file() and digest(caminho) == esperado:
                caminho.unlink()
        # Um recibo vazio/incompleto criado por esta operação não representa
        # uma instalação concluída. Não remove arquivo de outra execução.
        if recibo_criado and registro.is_file() and registro.stat().st_size == 0:
            registro.unlink()
        raise
    return resultado


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--projeto", required=True, type=Path)
    parser.add_argument("--registro", required=True, type=Path)
    args = parser.parse_args()
    try:
        resultado = instalar(args.projeto, args.registro)
    except (OSError, ValueError, KeyError, TypeError) as erro:
        print(f"Instalação não concluída: {erro}", file=sys.stderr)
        return 2
    print("Arquivos novos adicionados:", len(resultado["novos_criados"]))
    print("Arquivos já presentes com conteúdo igual:", len(resultado["ja_presentes_iguais"]))
    print("Registro:", args.registro.expanduser().resolve())
    print("Adaptador opcional instalado; a busca atual continua sem seleção da Camada A.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
