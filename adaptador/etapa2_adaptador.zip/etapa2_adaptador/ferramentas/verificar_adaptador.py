#!/usr/bin/env python3
"""Conferência local do adaptador real do Agente Analista, somente leitura."""
from __future__ import annotations

import argparse
from collections import defaultdict
import hashlib
import importlib
import json
from pathlib import Path
import sys

# Importar o projeto para leitura não deve criar __pycache__ dentro dele.
sys.dont_write_bytecode = True
from verificar_leitura_base import VerificacaoLeitura, hash_arquivo, hash_texto, ler_objeto, OBRA_19_ANTIGA

RAIZ_PACOTE = Path(__file__).resolve().parents[1]
SHA_ETAPA1 = "c6e43bc1d4d7b83825d22f1b44607f3f693772336e72970620f44c272f5af496"
# Cópia derivada: apenas o caminho local em "corpus" foi removido. O relatório
# original tem SHA 5a22f7cf6714efac74e322c4a9aa17e6e0b3ee9130c4b791c2bc30fa71b13f76;
# a equivalência dos outros campos está em dados/PROVENIENCIA_LEITURA_ETAPA2.json.
SHA_LEITOR_MAC = "21d7ebfefd9851f84f1c9f9a37fe44869beabd970b4b5044be1c0a881f7f45b0"
CHECKS_LEITOR = {"baseline_etapa1_concluido", "hashes_antes_de_abrir_leitor", "ids_e_contagens_jsonl",
                 "leitura_todos_fragmentos_blocos_e_fontes", "contextos_raio1_amostrados_sem_cruzar_obras",
                 "hashes_apos_leitura"}
MODULOS = ("__init__.py", "camada_a.py", "corpus.py", "entrada.py", "ligacoes.py", "transporte.py")


class VerificarAdaptador(VerificacaoLeitura):
    def __init__(self, projeto, corpus, baseline, *, evidencia=None,
                 sha_etapa1=SHA_ETAPA1, sha_leitor=SHA_LEITOR_MAC):
        super().__init__(corpus, baseline)
        self.projeto = projeto.resolve()
        self.evidencia = evidencia or RAIZ_PACOTE / "dados" / "LEITURA_ETAPA2_MAC.json"
        self.sha_etapa1_esperado, self.sha_leitor_esperado = sha_etapa1, sha_leitor
        self.hashes_projeto = {}
        self.relatorio.update(schema_relatorio="verificacao_adaptador_agente_analista.v1",
                              escopo="adaptador real opcional de leitura; sem ativação de backend ou rotas",
                              projeto=str(self.projeto), adaptador_importado_do_projeto=False,
                              backend_ativado=False, buscador_instanciado=False,
                              chamadas_api_executadas=False)
        self.relatorio["limites"] = [
            "Importa o adaptador real e os validadores locais do projeto; não inicia Flask, rotas ou serviço.",
            "O backend de busca permanece separado desta conferência de leitura.",
            "A marca da fonte antiga do volume 19 não é consumida pelo Buscador legado; não conectar "
            "este adaptador ao Buscador antes da etapa de busca com a política de exclusão implementada.",
            "Igualdade de todas as linhas com o NPY comprova preservação do arquivo auditado, "
            "não comprova a origem semântica de cada embedding.",
            "Citações são recortes técnicos locais por amostragem, sem avaliação interpretativa ou provedor.",
            "Páginas são do PDF; bibliografia completa e numeração impressa permanecem pendentes.",
        ]

    def carregar_baseline(self):
        if not super().carregar_baseline():
            return False
        c = self.checar("continuidade_com_leitura_real_mac")
        if self.sha_etapa1_esperado and self.relatorio["auditoria_etapa1_sha256"] != self.sha_etapa1_esperado:
            c.falhar("baseline_etapa1_diferente_da_versao_concluida")
        try:
            dados = self.evidencia.read_bytes()
            digest = hashlib.sha256(dados).hexdigest()
            self.relatorio["leitura_mac_sha256"] = digest
            if self.sha_leitor_esperado and digest != self.sha_leitor_esperado:
                c.falhar("relatorio_leitor_mac_diferente_do_conferido")
            r = ler_objeto(dados.decode("utf-8"))
            checks = r["verificacoes"]
            por_nome = {v["nome"]: v for v in checks}
            if set(por_nome) != CHECKS_LEITOR or len(por_nome) != len(checks) or any(v["estado"] != "passou" or v["falhas"] != {} for v in checks):
                c.falhar("seis_verificacoes_leitor_mac_nao_aprovadas")
            if r["estado"] != "leitura_verificada_com_limites" or r["etapa"] != 2:
                c.falhar("leitura_mac_nao_concluida")
            if r["auditoria_etapa1_sha256"] != self.relatorio["auditoria_etapa1_sha256"]:
                c.falhar("leitura_mac_nao_corresponde_ao_baseline_etapa1")
            entradas = r["baseline_e_hashes_da_leitura"]
            mapa = {x["arquivo"]: x for x in entradas}
            if len(mapa) != len(entradas) or set(mapa) != set(self.baseline):
                c.falhar("arquivos_leitura_mac_divergem_do_baseline")
            else:
                for nome, item in mapa.items():
                    esperado = self.baseline[nome]
                    if any(item.get(k) != esperado["sha256"] for k in ("sha256_baseline", "sha256_antes", "sha256_depois")) or item.get("bytes") != esperado["bytes"] or item.get("conteudo_inalterado") is not True:
                        c.falhar("hash_leitura_mac_divergente", nome)
            if por_nome["ids_e_contagens_jsonl"]["dados"]["contagens_lidas"] != self.contagens_esperadas:
                c.falhar("contagens_leitor_mac_divergentes")
            lidos = por_nome["leitura_todos_fragmentos_blocos_e_fontes"]["dados"]
            if any(lidos[campo] != self.contagens_esperadas[nome] for campo, nome in
                   (("fragmentos_lidos", "fragmentos"), ("blocos_lidos", "blocos"), ("fontes_conferidas", "obras"))):
                c.falhar("leitura_mac_incompleta")
            c.dados.update(verificacoes_leitor=6, arquivos_baseline=len(self.baseline))
        except (OSError, ValueError, TypeError, KeyError, UnicodeError) as exc:
            c.falhar("evidencia_leitor_ilegivel_" + type(exc).__name__)
        return not c.falhas

    def conferir_projeto(self, depois=False):
        c = self.checar("modulos_projeto_apos_leitura" if depois else "modulos_projeto_antes_importacao")
        registros = []
        for nome in MODULOS:
            relativo = "agente_analista/" + nome
            arquivo = (self.projeto / relativo).resolve()
            if not arquivo.is_relative_to(self.projeto) or not arquivo.is_file():
                c.falhar("modulo_projeto_ausente_ou_externo", relativo)
                continue
            atual = hash_arquivo(arquivo)
            if depois and self.hashes_projeto.get(relativo) != atual:
                c.falhar("modulo_projeto_alterado", relativo)
            if not depois:
                self.hashes_projeto[relativo] = atual
            registros.append({"arquivo": relativo, "sha256_antes": self.hashes_projeto.get(relativo),
                              **({"sha256_depois": atual, "conteudo_inalterado": atual == self.hashes_projeto.get(relativo)} if depois else {})})
        if depois:
            self.relatorio["hashes_modulos_projeto"] = registros
        return not c.falhas

    def _validar_fragmento_adaptado(self, f, original, check):
        bid, oid = original["bloco_id"], original["obra_id"]
        bloco, obra = self.indices["blocos"][bid], self.indices["obras"][oid]
        if f.get("original") != original or any(f.get(k) != v for k, v in original.items() if k != "paginas"):
            check.falhar("fragmento_original_nao_preservado", original["id"])
        esperado = self.rastreio_esperado(original, bloco["inicio"] + original["inicio"], bloco["inicio"] + original["fim"])
        aliases = {"obra": oid, "volume": obra["volume_sugerido"],
                   "secao": self.indices["secoes"][original["secao_id"]]["titulo"],
                   "fragmento_no_bloco": original["ordem"], "texto_origem_sha256": bloco["sha256_texto"],
                   "paginas_origem": original["paginas"], "paginas": esperado["paginas_pdf"],
                   "bloqueada_para_busca": oid == OBRA_19_ANTIGA}
        if any(f.get(k) != v for k, v in aliases.items()) or any(f["rastreio"].get(k) != v for k, v in esperado.items()):
            check.falhar("fragmento_aliases_fontes_paginas_divergentes", original["id"])

    def ler_componente(self):
        if not self.conferir_projeto():
            return
        sys.path.insert(0, str(self.projeto))
        modulo = importlib.import_module("agente_analista.camada_a")
        if Path(modulo.__file__).resolve() != (self.projeto / "agente_analista/camada_a.py").resolve():
            self.checar("origem_modulo_adaptador").falhar("modulo_importado_de_outro_projeto")
            return
        import numpy as np
        from agente_analista.entrada import validar_relato
        from agente_analista.ligacoes import _fontes, _validar_ligacao
        self.relatorio["adaptador_importado_do_projeto"] = True
        ids = [f["id"] for f in self.registros["fragmentos"]]
        por_obra, por_bloco = defaultdict(list), defaultdict(list)
        for f in self.registros["fragmentos"]:
            por_obra[f["obra_id"]].append(f["id"])
            por_bloco[f["bloco_id"]].append(f["id"])
        escolhidos = {fid for lista in por_obra.values() for fid in (lista[0], lista[len(lista)//2], lista[-1])}
        blocos_amostrados = {self.indices["fragmentos"][fid]["bloco_id"] for fid in escolhidos}
        c = self.checar("contrato_real_ids_indices_originais_aliases")
        matriz_check = self.checar("matriz_original_mmap_sem_copia_ou_remocao")
        contextos_check = self.checar("contextos_reais_amostrados_raio1")
        citacoes_check = self.checar("citacoes_tecnicas_validadores_locais")
        amostras, contextos, citacoes = [], [], []
        try:
            with modulo.abrir_camada_a(self.raiz) as corpus:
                if [f["id"] for f in corpus.fragmentos] != ids or corpus.indice_por_id != {fid: i for i, fid in enumerate(ids)} or set(corpus.por_id) != set(ids) or set(corpus.blocos) != set(self.indices["blocos"]):
                    c.falhar("ids_ou_mapeamento_indices_divergentes")
                matriz = corpus.vetores
                mesmo_mmap = (matriz is corpus.vetores and matriz is corpus._leitor._vetores)
                if not isinstance(matriz, np.memmap) or not mesmo_mmap or matriz.mode != "r" or matriz.flags.writeable or Path(matriz.filename).resolve() != self.caminhos["vetores_e5.npy"]:
                    matriz_check.falhar("matriz_nao_e_mmap_original_somente_leitura")
                if not isinstance(matriz, np.memmap):
                    return
                original_npy = np.load(self.caminhos["vetores_e5.npy"], mmap_mode="r", allow_pickle=False)
                try:
                    if matriz.shape != original_npy.shape or matriz.dtype != original_npy.dtype or matriz.offset != original_npy.offset or matriz.strides != original_npy.strides:
                        matriz_check.falhar("estrutura_matriz_original_divergente")
                    linhas = 0
                    for inicio in range(0, len(ids), 512):
                        if not np.array_equal(matriz[inicio:inicio+512], original_npy[inicio:inicio+512]):
                            matriz_check.falhar("valores_matriz_divergentes", inicio)
                        linhas += len(original_npy[inicio:inicio+512])
                    matriz_check.dados.update(linhas_comparadas=linhas, shape=list(matriz.shape), dtype=str(matriz.dtype),
                                              mesmo_objeto_mmap_do_leitor=mesmo_mmap, modo_mmap=matriz.mode)
                finally:
                    original_npy._mmap.close()
                for indice, original in enumerate(self.registros["fragmentos"]):
                    f = corpus.fragmentos[indice]
                    self._validar_fragmento_adaptado(f, original, c)
                    if corpus.por_id.get(original["id"]) is not f or corpus.fragmento(original["id"]) != f:
                        c.falhar("alias_por_id_ou_copia_fragmento_divergente", original["id"])
                    if original["id"] in escolhidos:
                        amostras.append({**self.resumo_registro(f), "paginas_metadado_origem": f["paginas_origem"], "indice_vetor": indice,
                                         "sha256_entrada": f["entrada_sha256"], "bloqueada_para_busca": f["bloqueada_para_busca"]})
                for bid, original in self.indices["blocos"].items():
                    b = corpus.bloco(bid)
                    esperado = self.rastreio_esperado(original, original["inicio"], original["fim"])
                    referencia = b["referencia"]
                    obra = self.indices["obras"][original["obra_id"]]
                    fragmentos = [{k: self.indices["fragmentos"][fid][k] for k in ("id", "inicio", "fim")} for fid in por_bloco[bid]]
                    if any(b["original"].get(k) != v for k, v in original.items()) or b["bloco_id"] != bid or b["fragmentos_ids"] != por_bloco[bid] or b["fragmentos"] != fragmentos or b["texto_origem_sha256"] != original["sha256_texto"] or b["paginas_origem"] != original["paginas"] or b["paginas"] != esperado["paginas_pdf"]:
                        c.falhar("bloco_original_ou_offsets_locais_divergentes", bid)
                    referencias = {"obra": obra["titulo"], "obra_id": original["obra_id"], "volume": obra["volume_sugerido"],
                                   "secao": esperado["titulo_secao"], "secao_id": original["secao_id"],
                                   "paginas": esperado["paginas_pdf"], "paginas_origem": original["paginas"],
                                   "sha256_pdf": obra["sha256_pdf"], "pdf_original": obra["pdf_original"],
                                   "origem_secao": esperado["origem_secao"], "atravessa_secoes": esperado["atravessa_secoes"]}
                    if any(referencia.get(k) != v for k, v in referencias.items()) or any(b["rastreio"].get(k) != v for k, v in esperado.items()) or b["bloqueada_para_busca"] != (original["obra_id"] == OBRA_19_ANTIGA):
                        c.falhar("bloco_referencia_ou_marca_fonte_divergente", bid)
                    if bid not in blocos_amostrados:
                        continue
                    texto = b["texto"]
                    if not texto.strip():
                        citacoes_check.dados["blocos_sem_citacao_literal_na_amostra"] = citacoes_check.dados.get("blocos_sem_citacao_literal_na_amostra", 0) + 1
                        continue
                    limite = fragmentos[0]["fim"]
                    inicio, fim = (max(0, limite-8), min(len(texto), limite+8)) if len(fragmentos) > 1 else (0, min(len(texto), 32))
                    if not texto[inicio:fim].strip():
                        inicio = next(i for i, char in enumerate(texto) if not char.isspace())
                        fim = min(len(texto), inicio+32)
                    cobrem = [f["id"] for f in fragmentos if f["inicio"] < fim and f["fim"] > inicio]
                    relato = validar_relato("Relato sintético para conferir o contrato de leitura.\n\n"
                                             "Segundo parágrafo sintético, sem dados pessoais.")
                    paragrafos, fontes = _fontes(relato, {"candidatos": [b]})
                    proposta = {"paragrafo": "P1", "bloco_id": bid, "relato": {k: relato["paragrafos"][0][k] for k in ("inicio", "fim", "texto")},
                                "freud": {"inicio": inicio, "fim": fim, "texto": texto[inicio:fim]}, "fragmentos_ids": cobrem,
                                "situacao": "parcial", "observacao": "Conferência técnica de literalidade.", "conceito": "",
                                "ligacao": "Conferência técnica, sem interpretação.", "justificativa": "Conferência local de offsets e cobertura.",
                                "limites": "Sem avaliação interpretativa.", "alternativas": []}
                    validada, motivo = _validar_ligacao(proposta, relato, paragrafos, fontes)
                    if validada is None or motivo is not None or validada["freud"]["texto"] != texto[inicio:fim] or validada["referencia"] != referencia:
                        citacoes_check.falhar("citacao_literal_ou_referencia_rejeitada", bid)
                    citacoes.append({"bloco_id": bid, "obra_id": original["obra_id"], "fragmentos_ids": cobrem,
                                     "inicio_local": inicio, "fim_local": fim, "sha256_citacao": hash_texto(texto[inicio:fim]),
                                     "literal_validada": validada is not None and motivo is None})
                for oid, lista in por_obra.items():
                    for pos, fid in enumerate(lista):
                        if fid not in escolhidos:
                            continue
                        ctx = corpus.contexto(fid, raio=1)
                        partes = ctx["fragmentos"]
                        if ctx["fragmento_id"] != fid or ctx["obra_id"] != oid or [f["id"] for f in partes] != lista[max(0,pos-1):pos+2] or any(f["obra_id"] != oid for f in partes):
                            contextos_check.falhar("contexto_cruza_obra_ou_vizinhos_divergem", fid)
                        for f in partes:
                            self._validar_fragmento_adaptado(f, self.indices["fragmentos"][f["id"]], contextos_check)
                        contextos.append({"fragmento_id": fid, "obra_id": oid, "fragmentos_ids": [f["id"] for f in partes],
                                          "paginas_pdf": [f["paginas"] for f in partes]})
                c.dados.update(fragmentos_conferidos=len(ids), blocos_conferidos=len(corpus.blocos), fontes_conferidas=len(por_obra),
                               fragmentos_marcados_fonte_antiga=len(por_obra.get(OBRA_19_ANTIGA, [])))
                contextos_check.dados["contextos_conferidos"] = len(contextos)
                citacoes_check.dados["citacoes_conferidas"] = len(citacoes)
                self.relatorio.update(amostras_fragmentos=amostras, amostras_contextos=contextos, amostras_citacoes=citacoes)
        finally:
            self.conferir_projeto(depois=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--projeto", type=Path, required=True)
    parser.add_argument("--corpus", type=Path, required=True)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--saida", type=Path, required=True)
    a = parser.parse_args(argv)
    projeto, corpus, baseline, saida = (p.expanduser().resolve() for p in (a.projeto, a.corpus, a.baseline, a.saida))
    if not projeto.is_dir() or not corpus.is_dir() or not baseline.is_file():
        parser.error("Projeto, corpus e baseline devem existir.")
    if saida.exists() or a.saida.expanduser().is_symlink() or saida.is_relative_to(projeto) or saida.is_relative_to(corpus) or not saida.parent.is_dir():
        parser.error("Escolha saída nova fora do projeto e do corpus, em diretório existente.")
    verificador = VerificarAdaptador(projeto, corpus, baseline)
    r = verificador.executar()
    if r["estado"] != "falhou":
        r["estado"] = "adaptador_real_leitura_verificado_com_limites"
    with saida.open("x", encoding="utf-8") as arquivo:
        json.dump(r, arquivo, ensure_ascii=False, indent=2, allow_nan=False)
        arquivo.write("\n")
    print("Adaptador real:", r["estado"])
    print("Relatório:", saida)
    print("Conferência de leitura; backend de busca e rotas permanecem separados.")
    return 1 if r["estado"] == "falhou" else 0


if __name__ == "__main__":
    sys.exit(main())
