"""Testes próprios do driver, sem repetir as baterias do núcleo/adaptador."""
from contextlib import redirect_stderr
import importlib.util
import io
import json
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.dont_write_bytecode = True
from verificar_adaptador import VerificarAdaptador, CHECKS_LEITOR, main
from verificar_leitura_base import CHECAGENS_ETAPA1, TIPOS, hash_arquivo

PROJETO = Path(os.environ.get("PROJETO_TESTE_CAMADA_A", "/workspace/projeto_lingua")).resolve()
sys.path.insert(0, str(PROJETO))
from agente_analista.camada_a import CorpusCamadaA
from agente_analista.tests.test_agente_analista_camada_a_core import criar_fixture


def criar_baseline(raiz, externo):
    refs = criar_fixture(raiz)
    con = sqlite3.connect(raiz / "corpus.sqlite")
    con.row_factory = sqlite3.Row
    registros = {n: [dict(r) for r in con.execute("SELECT * FROM " + n)] for n in TIPOS if n != "fragmentos"}
    con.close()
    registros["fragmentos"] = refs
    for bloco in registros["blocos"]:
        for origem, destino in (("paginas_json", "paginas"), ("papeis_provisorios_json", "papeis_provisorios"), ("conceitos_lexicais_json", "conceitos_lexicais")):
            bloco[destino] = json.loads(bloco.pop(origem))
    textos = {o["id"]: "".join(b["texto"] for b in registros["blocos"] if b["obra_id"] == o["id"]) for o in registros["obras"]}
    for p in registros["paginas"]:
        p["texto"] = textos[p["obra_id"]][p["inicio"]:p["fim"]]
        p["secao_id"] = max((s for s in registros["secoes"] if s["obra_id"] == p["obra_id"] and s["pagina_inicio"] <= p["pagina_pdf"]), key=lambda s: s["pagina_inicio"])["id"]
    for nome, lista in registros.items():
        (raiz / (nome + ".jsonl")).write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in lista), encoding="utf-8")
    (raiz / "textos_obras").mkdir()
    for oid, texto in textos.items():
        (raiz / "textos_obras" / (oid + ".txt")).write_text(texto, encoding="utf-8")
    contagens = {n: len(rs) for n, rs in registros.items()}
    (raiz / "relatorio_qualidade.json").write_text(json.dumps({"contagens": contagens}))
    arquivos = [{"arquivo": str(p.relative_to(raiz)), "bytes": p.stat().st_size, "sha256": hash_arquivo(p),
                 "sha256_antes": hash_arquivo(p), "sha256_depois": hash_arquivo(p), "conteudo_inalterado": True}
                for p in sorted(raiz.rglob("*")) if p.is_file()]
    checks = [{"nome": nome, "estado": "passou", "falhas": {}, "dados": {}} for nome in sorted(CHECAGENS_ETAPA1)]
    next(c for c in checks if c["nome"] == "contagens_e_volumes")["dados"] = {"contagens": contagens}
    next(c for c in checks if c["nome"] == "hashes_baseline_atual")["dados"] = {"arquivos_conferidos": len(arquivos)}
    documento = {"etapa": "validacao_estrutural", "estado": "concluida_com_limites", "verificacoes": checks, "baseline_arquivos_atual": arquivos}
    baseline = externo / "baseline.json"
    baseline.write_text(json.dumps(documento), encoding="utf-8")
    checks2 = [{"nome": nome, "estado": "passou", "falhas": {}, "dados": {}} for nome in sorted(CHECKS_LEITOR)]
    next(c for c in checks2 if c["nome"] == "ids_e_contagens_jsonl")["dados"] = {"contagens_lidas": contagens}
    next(c for c in checks2 if c["nome"] == "leitura_todos_fragmentos_blocos_e_fontes")["dados"] = {
        "fragmentos_lidos": len(refs), "blocos_lidos": contagens["blocos"], "fontes_conferidas": contagens["obras"]}
    evidencia = externo / "leitor.json"
    evidencia.write_text(json.dumps({"estado": "leitura_verificada_com_limites", "etapa": 2,
                                    "auditoria_etapa1_sha256": hash_arquivo(baseline), "verificacoes": checks2,
                                    "baseline_e_hashes_da_leitura": [{**a, "sha256_baseline": a["sha256"]} for a in arquivos]}))
    return refs, baseline, evidencia


class DriverAdaptadorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.externo = Path(self.temp.name)
        self.corpus = self.externo / "corpus"
        self.corpus.mkdir()
        self.refs, self.baseline, self.evidencia = criar_baseline(self.corpus, self.externo)

    def verificar(self):
        return VerificarAdaptador(PROJETO, self.corpus, self.baseline, evidencia=self.evidencia,
                                 sha_etapa1=hash_arquivo(self.baseline), sha_leitor=hash_arquivo(self.evidencia)).executar()

    @staticmethod
    def falhas(r):
        return {codigo for c in r["verificacoes"] for codigo in c["falhas"]}

    def test_adaptador_real_mmap_ids_citacoes_sem_rede_e_privacidade(self):
        with patch("agente_analista.ligacoes._enviar_mensagens", side_effect=AssertionError("rede indevida")), \
             patch("agente_analista.ligacoes._obter_chave_api", side_effect=AssertionError("chave indevida")):
            r = self.verificar()
        self.assertEqual(r["estado"], "leitura_verificada_com_limites")
        self.assertTrue(r["adaptador_importado_do_projeto"])
        self.assertTrue(all(c["literal_validada"] for c in r["amostras_citacoes"]))
        matriz = next(c for c in r["verificacoes"] if c["nome"] == "matriz_original_mmap_sem_copia_ou_remocao")
        self.assertEqual(matriz["dados"]["linhas_comparadas"], 5)
        self.assertTrue(matriz["dados"]["mesmo_objeto_mmap_do_leitor"])
        encoded = json.dumps(r, ensure_ascii=False)
        for f in self.refs:
            self.assertNotIn(f["texto"], encoded)
        self.assertFalse(r["backend_ativado"])
        self.assertFalse(r["chamadas_api_executadas"])
        self.assertTrue(all(h["conteudo_inalterado"] for h in r["hashes_modulos_projeto"]))
        self.assertTrue(all(h["conteudo_inalterado"] for h in r["baseline_e_hashes_da_leitura"]))
        self.assertNotIn("agente_analista.app", sys.modules)

    def test_indice_por_id_trocado_e_detectado(self):
        original_init = CorpusCamadaA.__init__

        def init_trocado(corpus, pasta):
            original_init(corpus, pasta)
            corpus.indice_por_id[self.refs[0]["id"]] = 4

        with patch.object(CorpusCamadaA, "__init__", new=init_trocado):
            self.assertIn("ids_ou_mapeamento_indices_divergentes", self.falhas(self.verificar()))

    def test_matriz_copiada_e_detectada(self):
        with patch.object(CorpusCamadaA, "vetores", new=property(lambda corpus: corpus._leitor._vetores.copy())):
            self.assertIn("matriz_nao_e_mmap_original_somente_leitura", self.falhas(self.verificar()))

    def test_drift_corpus_bloqueia_abertura_e_evidencia_nao_aprovada(self):
        with (self.corpus / "fragmentos.jsonl").open("a") as arquivo:
            arquivo.write("\n")
        with patch("agente_analista.camada_a.abrir_camada_a", side_effect=AssertionError("não pode abrir")) as abrir:
            r = self.verificar()
        abrir.assert_not_called()
        self.assertIn("corpus_diverge_do_baseline_etapa1", self.falhas(r))
        evidencia = json.loads(self.evidencia.read_text())
        evidencia["verificacoes"][0]["estado"] = "falhou"
        self.evidencia.write_text(json.dumps(evidencia))
        self.assertIn("seis_verificacoes_leitor_mac_nao_aprovadas", self.falhas(self.verificar()))

    def test_saida_fora_projeto_corpus_e_exclusiva(self):
        saida = self.externo / "existente.json"
        saida.write_text("preservado")
        for destino in (saida, self.corpus / "saida.json", PROJETO / "saida.json"):
            with redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                main(["--projeto", str(PROJETO), "--corpus", str(self.corpus), "--baseline", str(self.baseline), "--saida", str(destino)])
        self.assertEqual(saida.read_text(), "preservado")


if __name__ == "__main__":
    unittest.main()
